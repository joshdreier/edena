<?php

/**
 * Fired during plugin activation
 *
 * @link       http://little-neko.com/
 * @since      1.0.0
 *
 * @package    Neko_Slider
 * @subpackage Neko_Slider/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Neko_Slider
 * @subpackage Neko_Slider/includes
 * @author     Thomas bechier
 */
class Neko_Slider_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
