<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://little-neko.com/
 * @since      1.0.0
 *
 * @package    Neko_Slider
 * @subpackage Neko_Slider/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Neko_Slider
 * @subpackage Neko_Slider/admin
 * @author     Thomas bechier
 */
class Neko_Slider_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/neko-slider-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/neko-slider-admin.js', array( 'jquery' ), $this->version, false );

	}

	/**
	 * Add Neko slider custom post type.
	 *
	 * @since    1.0.0
	 */
	public function create_slider_posttype(){

		$labels = array( 
			'name'               => esc_html__( 'Neko Slide', 'neko-slider' ),
			'singular_name'      => esc_html__( 'Slide', 'neko-slider' ),
			'all_items'          => esc_html__( 'Slides', 'neko-slider' ),
			'add_new'            => esc_html__( 'Add a slide', 'neko-slider' ),
			'add_new_item'       => esc_html__( 'Add slide', 'neko-slider' ),
			'edit_item'          => esc_html__( 'Edit slide', 'neko-slider' ),
			'new_item'           => esc_html__( 'New slide', 'neko-slider' ),
			'view_item'          => esc_html__( 'View slides', 'neko-slider' ),
			'search_items'       => esc_html__( 'Search slides', 'neko-slider' ),
			'not_found'          => esc_html__( 'No slide found', 'neko-slider' ),
			'not_found_in_trash' => esc_html__( 'No slide found in Trash', 'neko-slider' ),
			'parent_item_colon'  => esc_html__( 'Parent slide:', 'neko-slider' ),
			'menu_name'          => esc_html__( 'Neko Slider', 'neko-slider' ),
			);

		$args = array( 
			'labels'              => $labels,
			'menu_icon'           => 'dashicons-images-alt2',
			'hierarchical'        => false,  
			'supports'            => array( 'title', 'editor', 'thumbnail', 'comments', 'excerpt' ),
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'menu_position'       => 31,
			'show_in_nav_menus'   => false,
			'publicly_queryable'  => false,
			'exclude_from_search' => false,
			'has_archive'         => false,
			'query_var'           => true,
			'can_export'          => true,
			'capability_type'     => 'post',
			'rewrite'             => array('slug' => 'neko-slider-item')
			);

		register_post_type( 'neko-slides', $args );

	}

	/**
	 * Add Neko slider custom taxonomy.
	 *
	 * @since    1.0.0
	 */
	public function create_slider_taxonomytype(){

		$labels = array(
			'name'                       => esc_html__( 'Neko Sliders', 'neko-slider' ),
			'singular_name'              => esc_html__( 'Slider', 'neko-slider' ),
			'menu_name'                  => esc_html__( 'Sliders', 'neko-slider' ),
			'name_admin_bar'             => esc_html__( 'Slider', 'neko-slider' ),
			'search_items'               => esc_html__( 'Search sliders', 'neko-slider' ),
			'popular_items'              => esc_html__( 'Popular sliders', 'neko-slider' ),
			'all_items'                  => esc_html__( 'All sliders', 'neko-slider' ),
			'edit_item'                  => esc_html__( 'Edit slider', 'neko-slider' ),
			'view_item'                  => esc_html__( 'View slider', 'neko-slider' ),
			'update_item'                => esc_html__( 'Update slider', 'neko-slider' ),
			'add_new_item'               => esc_html__( 'Add a new slider', 'neko-slider' ),
			'new_item_name'              => esc_html__( 'New slider Name', 'neko-slider' ),
			);    

			$args = array(
				'labels'              => $labels,
				'public'              => false,
				'show_ui'             => true,
				'show_admin_column'   => true,
				'show_in_nav_menus'	  => false,
				'show_tagcloud'       => false,
				'query_var'           => true,
				'hierarchical'        => false,
				'rewrite'             => array( 
					'slug' => 'portfolio',
					'with_front'   => false,
					'hierarchical' => false,
					'ep_mask'      => EP_NONE
					)
				);
			register_taxonomy( 'neko-sliders', array( 'neko-slides' ), $args );
	}

	/**
	 * Add Neko slider slide type metabox.
	 *
	 * @since    1.0.0
	 */
	public function create_slideposttype_metabox(){

		$config = array(
			'id'             => 'neko_slidetype_meta_box', 
			'title'          => 'slide type',
			'pages'          => array('neko-slides'), 
			'context'        => 'normal',  
			'priority'       => 'high',                         
			'fields'         => array(),                     
			'local_images'   => false,                        
			'use_with_theme' => plugins_url() . '/neko-slider/includes/libs/neko-metabox-generator/engine'
		);

		$my_meta =  new Neko_Slider_Meta_extends_Class( $config );

		$prefix = 'neko_slides_';

		/* Link to post (for post slider type) */
		$title_postlink = esc_html__( 'Link a post to the current slide', 'neko-slider' );
		$desc_postlink  = esc_html__( 'If you link a post to your slide the featured image and the text will come from the post itself', 'neko-slider' );
		$my_meta->addPosts(
			$prefix.'posts_field_id',
			array(
				'post_type'  => 'post'
				),
			array(
				'name'=> $title_postlink,
				'desc'=> $desc_postlink,
				)
			);

		$my_meta->Finish();
	}


	/**
	 * Add Neko slider slide link metabox.
	 *
	 * @since    1.0.0
	 */
	public function create_slidepostlink_metabox(){

		$config = array(
			'id'             => 'neko_slidelink_meta_box', 
			'title'          => 'slide link',
			'pages'          => array('neko-slides'), 
			'context'        => 'normal',  
			'priority'       => 'high',                         
			'fields'         => array(),                     
			'local_images'   => false,                        
			'use_with_theme' => plugins_url() . '/neko-slider/includes/libs/neko-metabox-generator/engine'
		);

		$prefix = 'neko_slides_';

		$my_meta =  new Neko_Slider_Meta_extends_Class( $config );

		/* Link */
		$title_slide_link = esc_html__('URL', 'neko-slider');
		$desc_slide_link = esc_html__('(i.e. http://www.little-neko.com). Leave blank if you dont want link.', 'neko-slider');
		$my_meta->addText(
			$prefix.'slide_link',
			array(
				'name'=> $title_slide_link,
				'desc'=> $desc_slide_link,
				'std'=> ''
			)
		);

     	/* target */
		$title_slide_link_target = esc_html__('Link target', 'neko-slider');
		$my_meta->addRadio(
			$prefix.'slide_link_target',
			array(
				'_self'  => esc_html__('_self', 'neko-slider'),
				'_blank' => esc_html__('_blank', 'neko-slider')
			),

			array(
				'name'=> $title_slide_link_target,
				'std'=> '_self'
				)
			);

			$my_meta->Finish();
	}


	/**
	 * Add Neko slider slide caption metabox.
	 *
	 * @since    1.0.0
	 */
	public function create_slidepostcaption_metabox(){

		$config = array(
			'id'             => 'neko_slidecpation_meta_box', 
			'title'          => 'slide caption',
			'pages'          => array('neko-slides'), 
			'context'        => 'normal',  
			'priority'       => 'high',                         
			'fields'         => array(),                     
			'local_images'   => false,                        
			'use_with_theme' => plugins_url() . '/neko-slider/includes/libs/neko-metabox-generator/engine'
		);

		$prefix = 'neko_slides_';
		$on  = esc_html__('On','neko-slider');
		$off = esc_html__('Off','neko-slider');

		$my_meta =  new Neko_Slider_Meta_extends_Class( $config );

		/* caption position */
		$title_slide_captionposition = esc_html__('Caption position', 'neko-slider');
		$my_meta->addSelect(
			$prefix.'slide_caption_position',
			array(
				'emptylabel'    => esc_html__('Select ...','neko-slider'),
				'top-left'      => esc_html__('Top left', 'neko-slider'),
				'middle-left'   => esc_html__('Middle left', 'neko-slider'),
				'bottom-left'   => esc_html__('Bottom left', 'neko-slider'),
				'top-center'    => esc_html__('Top center', 'neko-slider'),
				'middle-center' => esc_html__('Middle center', 'neko-slider'),
				'bottom-center' => esc_html__('Bottom center', 'neko-slider'),
				'top-right'     => esc_html__('Top right', 'neko-slider'),
				'middle-right'  => esc_html__('Middle right', 'neko-slider'),
				'bottom-right'  => esc_html__('Bottom right', 'neko-slider')
			),
			array(
				'name'=> $title_slide_captionposition,
				'std'=> '_self', 
				'class' => 'no-fancy'
				)
			);

		/* caption animation */
		$title_slide_captionanimation = esc_html__('Caption animation', 'neko-slider');
		$my_meta->addSelect(
			$prefix.'slide_caption_animation',
			array(
				'emptylabel'       => esc_html__('Select ...','neko-slider'),
				'bounceIn'         => esc_html__('bounce In', 'neko-slider'),
				'bounceInDown'     => esc_html__('bounce In Down', 'neko-slider'),
				'bounceInLeft'     => esc_html__('bounce In Left', 'neko-slider'),
				'bounceInRight'    => esc_html__('bounce In Right', 'neko-slider'),
				'bounceInUp'       => esc_html__('bounce In Up', 'neko-slider'),
				'fadeIn'           => esc_html__('fade In', 'neko-slider'),
				'fadeInDown'       => esc_html__('fade In Down', 'neko-slider'),
				//'fadeInDownBig'  => esc_html__('fade In DownBig', 'neko-slider'),
				'fadeInLeft'       => esc_html__('fade In Left', 'neko-slider'),
				//'fadeInLeftBig'  => esc_html__('fade In Left Big', 'neko-slider'),
				'fadeInRight'      => esc_html__('fade In Right', 'neko-slider'),
				//'fadeInRightBig' =>e sc_html__('fade In Right Big', 'neko-slider'),
				'fadeInUp'         => esc_html__('fade In Up', 'neko-slider'),
				//'fadeInUpBig'    => esc_html__('fade In Up Big', 'neko-slider'),
				'slideInDown'      => esc_html__('slide In Down', 'neko-slider'),
				'slideInLeft'      => esc_html__('slide In Left', 'neko-slider'),
				'slideInRight'     => esc_html__('slide In Right', 'neko-slider'),
				'slideInUp'        => esc_html__('slide In Up', 'neko-slider'),
				'zoomIn'           => esc_html__('zoom In', 'neko-slider'),
				'zoomInDown'       => esc_html__('zoom In Down', 'neko-slider'),
				'zoomInLeft'       => esc_html__('zoom In Left', 'neko-slider'),
				'zoomInRight'      => esc_html__('zoom In Right', 'neko-slider'),
				'zoomInUp'         => esc_html__('zoom In Up', 'neko-slider')
			),
			array(
				'name'=> $title_slide_captionanimation,
				'std'=> '_self', 
				'class' => 'no-fancy'
				)
			);		


		/* Slide Title */
		$my_meta->addRadio(
			$prefix.'slide_caption_title',
			array(
				'on' => $on,
				'off'=> $off,
			),
			array(
				'name' => esc_html__('Caption title', 'neko-slider'),
				'desc' => esc_html__('If set on "On" the title of the slide will appear in the caption', 'neko-slider'), 
				'std'  => 'off'
			)
		);


		/* text color */
		$my_meta->addColor(
			$prefix.'slide_caption_textcolor',
			array(
				'name'=> esc_html__('Caption text color', 'neko-slider'),
				'std' => '#ffffff'
			)
		);


		/* text sizing */
		$my_meta->addSelect(
			$prefix.'slide_caption_textsize',
			array(
				'emptylabel' => esc_html__('Select ...','neko-slider'),
				'xx-large' => esc_html__('XX large', 'neko-slider'),
				'x-large'  => esc_html__('X large', 'neko-slider'),
				'large'    => esc_html__('Large', 'neko-slider'),
				'medium'   => esc_html__('Medium', 'neko-slider'),
				'small'    => esc_html__('Small', 'neko-slider'),
				'x-small'  => esc_html__('X small', 'neko-slider'),
				'xx-small'  => esc_html__('XX small', 'neko-slider')
			),
			array(
				'name'=> esc_html__('Caption text sizing', 'neko-slider'),
				'std' => 'medium', 
				'class' => 'no-fancy'
			)
		);



		$my_meta->Finish();
	}

	/**
	 * Add Neko slider taxonomy metabox.
	 *
	 * @since    1.0.0
	 */
	public function create_slidepostmask_metabox(){

		$config = array(
			'id'             => 'neko_slidemask_meta_box', 
			'title'          => 'Slide overlay',
			'pages'          => array('neko-slides'), 
			'context'        => 'normal',  
			'priority'       => 'high',                         
			'fields'         => array(),                     
			'local_images'   => false,                        
			'use_with_theme' => plugins_url() . '/neko-slider/includes/libs/neko-metabox-generator/engine'
			);

		$prefix = 'neko_slides_';

		$my_meta =  new Neko_Slider_Meta_extends_Class( $config );


		/* mask opacity */
		$title_slide_mask_opacity = esc_html__('Overlay opacity', 'neko-slider');
		$my_meta->addSelect(
			$prefix.'slide_maskopacity',
			array(
				'emptylabel' => esc_html__('Select ...','neko-slider'),
				'0.1'=>'0.1',
				'0.2'=>'0.2',
				'0.3'=>'0.3',
				'0.4'=>'0.4',
				'0.5'=>'0.5',
				'0.6'=>'0.6',
				'0.7'=>'0.7',
				'0.8'=>'0.8',
				'0.9'=>'0.9',
				'1'=>'1'
			),

			array(
				'name'=> $title_slide_mask_opacity,
				'std'=> '_self', 
				'class' => 'no-fancy'
				)
			);

		/* mask color */
		$my_meta->addColor(
			$prefix.'slide_maskcolor',
			array(
				'name'=> esc_html__('Overlay color', 'neko-slider'),
				'std' => '#000000'
			)
		);


		$my_meta->Finish();
	}

	


	/**
	 * Add Neko slider taxonomy metabox.
	 *
	 * @since    1.0.0
	 */
	public function create_slidertaxonomy_metabox(){

		$config = array(
			'id'             => 'wp_owl_carousel_meta_box',
			'title'          => 'Carousel settings',
			'pages'          => array('neko-sliders'),
			'context'        => 'normal',
			'priority'       => 'high',
			'fields'         => array(),
			'local_images'   => false,                       		
			'use_with_theme' => plugins_url() . '/neko-slider/includes/libs/neko-metabox-tax-generator/engine'
		);

		$my_meta =  new Neko_Slider_Tax_Meta_extends_Class( $config );

		$prefix = 'neko_slider_';
		$on  = esc_html__('On','neko-slider');
		$off = esc_html__('Off','neko-slider');

  		/* owl style */
		$title_slider_skin = esc_html__('Slider skin', 'neko-slider');
		$desc_slider_skin  = esc_html__('Choose the way your slider will look like', 'neko-slider');
		$my_meta->addSelect(
			$prefix.'skin',
			array(
				'neko-slider-theme-default'=>esc_html__('Default', 'neko-slider'),
				'neko-slider-theme-1'=>esc_html__('Hover', 'neko-slider'),
			),
			array(
				'name'=> $title_slider_skin,
				'std'=> array('neko-slider-theme-default'),
				'desc' => $desc_slider_skin, 
				'class' => 'no-fancy'
			)
		);


  		/* Items */
		$title_items = esc_html__('Items', 'neko-slider');
		$desc_items = esc_html__('This variable allows you to set the maximum amount of items displayed at a time with the widest browser width', 'neko-slider');
		$my_meta->addSelect(
			$prefix.'items',
			array(
				'1'=>'1',
				'2'=>'2',
				'3'=>'3',
				'4'=>'4',
				'5'=>'5',
				'6'=>'6'
			),
			array(
				'name'=> $title_items,
				'std'=> array('1'),
				'desc' => $desc_items, 
				'class' => 'no-fancy'
			)
		);


		/* Slide speed */
		$title_slidespeed = esc_html__('Slide speed', 'neko-slider');
		$desc_slidespeed = esc_html__('Slide speed in milliseconds', 'neko-slider');
		$my_meta->addText(
			$prefix.'slidespeed',
			array(
				'name'=> $title_slidespeed,
				'std'=> 200,
				'desc' => $desc_slidespeed
			)
		);


		/* Transition style */
		$title_transitionstyle = esc_html__('Transition style', 'neko-slider');
		$my_meta->addSelect(
			$prefix.'transitionstyle',
			array(
				'fade'      => esc_html__('fade', 'neko-slider'),
				'slide'     => esc_html__('slide', 'neko-slider'),
				'backSlide' => esc_html__('backSlide', 'neko-slider'),
				'goDown'    => esc_html__('goDown', 'neko-slider'),
				'fadeUp'    => esc_html__('fadeUp', 'neko-slider')
			),
			array(
				'name'=> $title_transitionstyle,
				'std'=> 'slide', 
				'class' => 'no-fancy'
			)
		);

		/* items scaleup */
		// $title_itemsscaleup = esc_html__('Items scaleup', 'neko-slider');
		// $desc_itemsscaleup = esc_html__('If set on "On" each item will not stretch when it is less than the supplied items', 'neko-slider');

		// $my_meta->addRadio(
		// 	$prefix.'itemsscaleup',
		// 	array(
		// 		'true'=>$on,
		// 		'false'=>$off
		// 	),
		// 	array(
		// 		'name'=> $title_itemsscaleup,
		// 		'std'=> array('false'),
		// 		'desc' => $desc_itemsscaleup
		// 	)
		// );

		/* navigation */
		$title_navigation = esc_html__('Navigation', 'neko-slider');
		$desc_navigation = esc_html__('Display "next" and "prev" buttons', 'neko-slider');
		$my_meta->addRadio(
			$prefix.'navigation',
			array(
				'true'=>$on,
				'false'=>$off
				),
			array(
				'name'=> $title_navigation,
				'std'=> array('false'),
				'desc' => $desc_navigation
				)
			);

		/* Navigation Text Previous */
		$title_navigationTextPrev = esc_html__('Previous button text', 'neko-slider');
		$my_meta->addText(
			$prefix.'navigationTextPrev',
			array(
				'name'=> $title_navigationTextPrev,
				'std'=> '&larr;'
			)
		);


		/* Navigation Text Next */
		$title_navigationTextNext = esc_html__('Next button text', 'neko-slider');
		$my_meta->addText(
			$prefix.'navigationTextNext',
			array(
				'name'=> $title_navigationTextNext,
				'std'=> '&rarr;'
				)
			);


		/* pagination */
		$title_pagination = esc_html__('Pagination', 'neko-slider');
		$desc_pagination = '';
		$my_meta->addRadio(
			$prefix.'pagination',
			array(
				'true'=>$on,
				'false'=>$off
				),
			array(
				'name'=> $title_pagination,
				'std'=> array('true'),
				'desc' => $desc_pagination
				)
			);

		/* pagination numbers */
		$title_paginationnumbers = esc_html__('Pagination numbers', 'neko-slider');
		$desc_paginationnumbers = esc_html__('Add numbers inside pagination buttons', 'neko-slider');
		$my_meta->addRadio(
			$prefix.'paginationnumbers',
			array(
				'true'=>$on,
				'false'=>$off
				),
			array(
				'name'=> $title_paginationnumbers,
				'std'=> array('false'),
				'desc' => $desc_paginationnumbers
				)
			);



		/* auto height */
		$title_autoheight = esc_html__('Auto height', 'neko-slider');
		$desc_autoheight = esc_html__('Automatic height adjustment. Use it only if the "items" option (2nd option) is set to 1', 'neko-slider');
		$my_meta->addRadio(
			$prefix.'autoheight',
			array(
				'true'=>$on,
				'false'=>$off
				),
			array(
				'name'=> $title_autoheight,
				'std'=> array('false'),
				'desc' => $desc_autoheight
				)
			);



		/* auto play */
		$title_autoplay = esc_html__('Autoplay', 'neko-slider');
		$desc_autoplay = '';
		$my_meta->addRadio(
			$prefix.'autoplay',
			array(
				'true'=>$on,
				'false'=>$off
				),
			array(
				'name'=> $title_autoplay,
				'std'=> array('false'),
				'desc' => $desc_autoplay
				)
			);

		/* auto height */
		$title_imgresponsive = esc_html__('Image aspect ratio', 'neko-slider');
		$desc_imgresponsive = esc_html__('Desactivate to keep the original aspect ration for the slider\'s images', 'neko-slider');
		$my_meta->addRadio(
			$prefix.'imgresponsive',
			array(
				'true'=>$on,
				'false'=>$off
				),
			array(
				'name'=> $title_imgresponsive,
				'std'=> array('true'),
				'desc' => $desc_imgresponsive
				)
			);

		/* captions position */
		// $title_captionposition = esc_html__('Caption style', 'neko-slider');
		// $my_meta->addRadio(
		// 	$prefix.'captionposition',
		// 	array(
		// 		'over'  => esc_html__('over image', 'wp-owl-carousel'),
		// 		'under' => esc_html__('under image', 'wp-owl-carousel')
		// 		),
		// 	array(
		// 		'name' => $title_captionposition,
		// 		'std'  => array('over'),
		// 		)
		// 	);




		/* Add shortcode in the taxonomy edit page */
		if(!empty($_GET['tag_ID'])){

			$title_portfolio_shortcode = esc_html__('Neko slider shortcode', 'neko-slider');
			$my_meta->addShortcodeTxt('paragraph_field_id',array('taxonomy'=> 'neko-sliders', 'shortcodename' => 'NEKO_SLIDER', 'class' => 'nekoInfoParag'));

		}



		$my_meta->Finish();		
	}



}