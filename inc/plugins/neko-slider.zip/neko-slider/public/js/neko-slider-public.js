(function( $ ) {
	'use strict';

  /* DOC READY */
	$(function() { });

  /* WIN LOAD */
  $( window ).load(function() {

    $('.neko-slider-data').each(function( index ) {
      var owl = $(this);
      owl.owlCarousel(
      {
        items:$(this).data('neko-slider-items'),
        navigation:$(this).data('neko-slider-navigation'),
        singleItem:$(this).data('neko-slider-singleitem'),
        autoPlay:$(this).data('neko-slider-autoplay'),
        slideSpeed:$(this).data('neko-slider-slidespeed'),
        navigationText: [$(this).data('neko-slider-navigationtextprev'),$(this).data('neko-slider-navigationtextnext')],
        pagination:$(this).data('neko-slider-pagination'),
        paginationNumbers:$(this).data('neko-slider-paginationnumbers'),
        autoHeight:$(this).data('neko-slider-autoheight'),
        mouseDrag:$(this).data('neko-slider-mousedrag'),
        transitionStyle:$(this).data('neko-slider-transitionstyle'),
        itemsScaleUp: true,
        addClassActive: true,
        lazyLoad : true,
        responsive: true,
        itemsDesktop :[1450,4],
        afterInit: function(){
          $('.active .caption').each(function(index, val) {
            var currentCaption = $(this);
            $('.caption-wrapper').css('display', 'none');
            $('.active .caption-wrapper').css('display', 'block');

            if(currentCaption.data('nekoslider_animation') != ''){
              currentCaption.addClass('animated '+currentCaption.data('nekoslider_animation'));
            }
          });
        },
        beforeMove:  function(){
          $('.caption-wrapper').css('display', 'none');
          $('.active .caption-wrapper').css('display', 'block');  
          
          $('.caption', owl).each(function(index, val) {
            var currentCaption = $(this);
            if( currentCaption.data('nekoslider_animation') != '' ){
              currentCaption.removeClass('animated '+currentCaption.data('nekoslider_animation'));
            }
          });
        },
        afterMove:  function(){
          $('.caption-wrapper').css('display', 'none');

          $('.active .caption').each(function(index, val) {
            var currentCaption = $(this);
            if( currentCaption.data('nekoslider_animation') != '' ){
              setTimeout(function(){  
                $('.active .caption-wrapper').css('display', 'block');    
                currentCaption.addClass('animated '+currentCaption.data('nekoslider_animation'));
              }, 450);
            }
          });
        }
        
      });
    });

  });



})( jQuery );
