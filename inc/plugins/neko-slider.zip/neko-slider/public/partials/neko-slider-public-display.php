<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       http://little-neko.com/
 * @since      1.0.0
 *
 * @package    Neko_Slider
 * @subpackage Neko_Slider/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<?php

/* INIT VARS */
$neko_slide   = 'neko-slides';
$neko_slider = 'neko-sliders';

/* Slider options */
$neko_slider_skin               = get_tax_meta($neko_slider_id, 'neko_slider_skin');
$neko_slider_items              = get_tax_meta($neko_slider_id, 'neko_slider_items');
$neko_slider_slidespeed         = get_tax_meta($neko_slider_id, 'neko_slider_slidespeed');
$neko_slider_transitionstyle    = get_tax_meta($neko_slider_id, 'neko_slider_transitionstyle');
$neko_slider_navigation         = get_tax_meta($neko_slider_id, 'neko_slider_navigation');
$neko_slider_navigationTextPrev = get_tax_meta($neko_slider_id, 'neko_slider_navigationTextPrev');
$neko_slider_navigationTextNext = get_tax_meta($neko_slider_id, 'neko_slider_navigationTextNext');
$neko_slider_pagination         = get_tax_meta($neko_slider_id, 'neko_slider_pagination');
$neko_slider_paginationnum      = get_tax_meta($neko_slider_id, 'neko_slider_paginationnumbers');
$neko_slider_autoheight         = get_tax_meta($neko_slider_id, 'neko_slider_autoheight');
$neko_slider_autoplay           = get_tax_meta($neko_slider_id, 'neko_slider_autoplay');
$neko_slider_imgresponsive      = get_tax_meta($neko_slider_id, 'neko_slider_imgresponsive');


/* js data builder */
$data_items         = ( 1 == $neko_slider_items ) ? 'data-neko-slider-singleitem="true"' : 'data-neko-slider-items="'.esc_attr($neko_slider_items).'"';
$data_speed         = ( !empty( $neko_slider_items ) ) ? 'data-neko-slider-slidespeed="'.esc_attr($neko_slider_slidespeed).'"' : 'data-neko-slider-slidespeed="3000"';	
$data_transition    = ( 'slide' == $neko_slider_transitionstyle || empty($neko_slider_transitionstyle) ) ? '' : 'data-neko-slider-transitionstyle="'.esc_attr($neko_slider_transitionstyle).'"';
$data_navigation    = ( !empty( $neko_slider_navigation ) ) ? 'data-neko-slider-navigation="'.esc_attr($neko_slider_navigation).'"' : 'data-neko-slider-navigation="true"';
$data_prevtxt       = ( !empty( $neko_slider_navigationTextPrev ) ) ? 'data-neko-slider-navigationtextprev="'.esc_attr($neko_slider_navigationTextPrev).'"' : 'data-neko-slider-navigationtextprev="previous"' ;
$data_nexttxt       = ( !empty( $neko_slider_navigationTextNext ) ) ? 'data-neko-slider-navigationtextnext="'.esc_attr($neko_slider_navigationTextNext).'"' : 'data-neko-slider-navigationtextnext="next"' ;
$data_pagination    = ( !empty( $neko_slider_pagination ) ) ? 'data-neko-slider-pagination="'.esc_attr($neko_slider_pagination).'"' : 'data-neko-slider-pagination="true"';
$data_paginationnum = ( !empty( $neko_slider_paginationnum ) ) ? 'data-neko-slider-paginationnumbers="'.esc_attr($neko_slider_paginationnum).'"' : 'data-neko-slider-paginationnumbers="false"';
$data_autoheight    = ( !empty($neko_slider_autoheight) ) ? 'data-neko-slider-autoheight="'.esc_attr($neko_slider_autoheight).'"' : 'data-neko-slider-autoheight="true"';
$data_autoplay      = ( !empty($neko_slider_autoplay) ) ? 'data-neko-slider-autoplay="'.esc_attr($neko_slider_autoplay).'"' : 'data-neko-slider-autoplay="false"';

if( empty($neko_slider_items) ){
	$data_items         = 'data-neko-slider-singleitem="true"';
}
if( empty($neko_slider_imgresponsive) ){
	$neko_slider_imgresponsive = true;
}


?>


<div id="neko-slider-<?php echo esc_attr($neko_slider_id) ?>" class="neko-slider-data owl-carousel <?php echo esc_attr($neko_slider_skin); ?>" <?php echo $data_items.' '.$data_speed.' '.$data_transition.' '.$data_navigation.' '.$data_prevtxt.' '.$data_nexttxt.' '.$data_pagination.' '.$data_paginationnum.' '.$data_autoheight.' '.$data_autoplay ?>>


<?php
/* Slides query */
$args=array(
	'post_type' => $neko_slide,
	'tax_query' => array(
		array(
			'taxonomy' => $neko_slider,
			'terms' => function_exists('icl_object_id')?icl_object_id($neko_slider_id,$neko_slider,false):$neko_slider_id,
			'field' => 'term_id'
		)
	),
	'post_status' => 'publish',
	'posts_per_page'=> -1
);

$wp_query = new WP_Query( $args );
/* Slides query */



while ( $wp_query->have_posts() ) : $wp_query->the_post();

$slide           = get_post();
$slide_options   = get_post_meta($slide->ID);
$caption_title   = '';
$caption_content = '';
$caption_link    = '';
?>
<div class="item" id="slide-<?php echo esc_attr($slide->ID) ; ?>">

<?php

/* mask */
$slide_maskopacity = ( !empty( $slide_options['neko_slides_slide_maskopacity'][0] ) && 'emptylabel' != $slide_options['neko_slides_slide_maskopacity'][0] ) ? $slide_options['neko_slides_slide_maskopacity'][0] : 0;
$slide_maskcolor = ( !empty( $slide_options['neko_slides_slide_maskcolor'][0] ) ) ? $slide_options['neko_slides_slide_maskcolor'][0] : 0;
$slider_mask = '';
if( 0 != $slide_maskopacity ){
	$slider_mask = '<div class="neko-slider-mask" style=" background-color:'.$slide_maskcolor.'; opacity:'.$slide_maskopacity.' "></div>';
}

echo $slider_mask;

$alt_media = get_post_meta(get_post_thumbnail_id(), '_wp_attachment_image_alt', true);
$alt = (!empty($alt_media))?$alt_media:get_the_title();
$featured_img = wp_get_attachment_image_src(get_post_thumbnail_id() , 'full');



/******* blog post slide *******/
if( !empty($slide_options['neko_slides_posts_field_id'][0]) && '-1' !== $slide_options['neko_slides_posts_field_id'][0] ){

	$blog_post = get_post($slide_options['neko_slides_posts_field_id'][0]);
	//echo '<pre>'; print_r($blog_post); echo '</pre>';

	$attr = array(
		'class'	=> "neko-force-fullwidth"
	);

	echo get_the_post_thumbnail( $slide_options['neko_slides_posts_field_id'][0], 'full', $attr );
	$caption_content = $blog_post->post_content.'<br/>';
	$link = ( !empty($slide_options['neko_slides_slide_link'][0]) )? $slide_options['neko_slides_slide_link'][0] : post_permalink( $blog_post->ID ); ;
	$link_target = ( !empty($slide_options['neko_slides_slide_link_target'][0]) ) ? 'target="'.$slide_options['neko_slides_slide_link_target'][0].'"' : '' ;

/******* img slide *******/
}elseif ( !empty($featured_img) ) {

	$responsive_class = ( !isset($neko_slider_imgresponsive) || 'true' == $neko_slider_imgresponsive ) ? 'neko-force-fullwidth-slider' : '' ; 
	echo '<img src="'.$featured_img[0].'" alt="'.$alt.'" class="'.$responsive_class.'" />';
	
	$neko_wp_content = get_the_content();

	if ( '' != $neko_wp_content ) {
		$caption_content = '<div>'.$neko_wp_content.'</div>';
	}

	$link = ( !empty($slide_options['neko_slides_slide_link'][0]) )? $slide_options['neko_slides_slide_link'][0] : '';
	$link_target = ( !empty($slide_options['neko_slides_slide_link_target'][0]) )? 'target="'.$slide_options['neko_slides_slide_link_target'][0].'"' : '' ;

/******* txt slide *******/
}else{
	$neko_wp_content = get_the_content();
	if ( '' != $neko_wp_content ) { 
		echo '<div>'.$neko_wp_content.'</div>'; 
		$link = ( !empty($slide_options['neko_slides_slide_link'][0]) ) ? $slide_options['neko_slides_slide_link'][0] : '';
		$link_target = ( !empty($slide_options['neko_slides_slide_link_target'][0]) ) ? 'target="'.$slide_options['neko_slides_slide_link_target'][0].'"' : '' ;
	}
}


/* Caption positionning */
$caption_position = ( !empty($slide_options['neko_slides_slide_caption_position'][0]) && 'emptylabel' !== $slide_options['neko_slides_slide_caption_position'][0] )?$slide_options['neko_slides_slide_caption_position'][0]:'bottom-center';
$caption_position = explode('-', $caption_position);

/* Caption animation */
$caption_animation = ( !empty($slide_options['neko_slides_slide_caption_animation'][0]) && 'emptylabel' !== $slide_options['neko_slides_slide_caption_position'][0] )? 'data-nekoslider_animation="'.$slide_options['neko_slides_slide_caption_animation'][0].'"':'';

/* Caption title */
$caption_title = ( !empty($slide_options['neko_slides_slide_caption_title'][0]) && 'on' === $slide_options['neko_slides_slide_caption_title'][0] ) ? '<h1>'.get_the_title().'</h1>' : '' ;

/* Caption Link */
$caption_link = '';
if( !empty($link) ){
	$caption_link = '<a href="'.$link.'" title="" class="btn btn-default" '.$link_target.'>'.esc_html__('Read More', 'neko-slider').'</a>';
}

/* Caption text color */
$caption_text_color = ( !empty($slide_options['neko_slides_slide_caption_textcolor'][0]) )?$slide_options['neko_slides_slide_caption_textcolor'][0]:'#ffffff';

/* Caption text sizing */
$caption_text_size = ( !empty($slide_options['neko_slides_slide_caption_textsize'][0]) && 'emptylabel' !== $slide_options['neko_slides_slide_caption_position'][0] ) ? $slide_options['neko_slides_slide_caption_textsize'][0] : 'medium' ;




/******* caption system *******/
if( !empty($caption_content) || !empty($caption_title) || !empty($caption_link) ){




	echo trim('
	<div class="caption-wrapper">
		<div class="caption '.$caption_position[1].' txt-'.$caption_text_size.'" '.$caption_animation.' style="color:'.$caption_text_color.'; font-size:'.$caption_text_size.';">
			<div class="caption-content-position text-'.$caption_position[1].' v-'.$caption_position[0].'">
				'.$caption_title.'
				'.$caption_content.'
				'.$caption_link.'
			</div>
		</div>
	</div>');	
}

?>

</div>

<?php
endwhile;
?>
</div>


<?php wp_reset_query(); ?>