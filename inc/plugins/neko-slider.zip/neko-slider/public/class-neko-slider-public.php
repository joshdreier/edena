<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://little-neko.com/
 * @since      1.0.0
 *
 * @package    Neko_Slider
 * @subpackage Neko_Slider/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Neko_Slider
 * @subpackage Neko_Slider/public
 * @author     Thomas bechier
 */
class Neko_Slider_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;


  /**
   * The version of this plugin.
   *
   * @since    1.0.0
   * @access   private
   * @var      string    $version    The current version of this plugin.
   */
  private $terms;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;


	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		
		
		
		// plugins css
		wp_enqueue_style( 'neko-slider-plugins', plugins_url( 'assets/allplugins.min.css', __FILE__ ), array(),  $this->version );
		

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/neko-slider-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		//wp_enqueue_script( 'owl-carousel-modernizr', plugin_dir_url( __FILE__ ) . 'assets/owl-carousel/modernizr.custom.49676.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( 'owl-carousel', plugin_dir_url( __FILE__ ) . 'assets/owl-carousel/owl.carousel.min-MODIFIED.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/neko-slider-public.js', array( 'jquery' ), $this->version, true );
	}


	/**
	 * Shortcode Activation
	 * @since    1.0.0
	 */
	public function neko_slider_shortcode( $atts, $content = null ) {
		

    	if ( defined( 'WPB_VC_VERSION' ) ) {
	    	$atts = vc_map_get_attributes( 'NEKO_SLIDER', $atts );
	    	extract($atts);
	    }else{
	    	extract(
	    		shortcode_atts(
	    			array(
	    				'slug' => '',
	    				), $atts
	    			)
	    		);
	    }

		$terms = get_term_by('slug', $slug, 'neko-sliders');
		$neko_slider_id = $terms->term_id;

		ob_start();

		include(plugin_dir_path( __FILE__ ) . 'partials/neko-slider-public-display.php');

		$content = ob_get_clean();

		return $content;

	}

	/**
	 * Get slider category
	 */
	public function neko_add_shortcode_to_vc() {

		$output = array(); 
		$terms = get_terms('neko-sliders', array('hide_empty' => 1) );

		//echo '<pre>'; print_r($terms); echo '</pre>';

		$count = count($terms);

		if ( $count > 0 ){
			foreach ( $terms as $term ){
				$output[$term->name] = $term->slug;
			}
		}

		vc_map( 
			array(
				"name" => esc_html__( "Neko slider", "neko-slider" ),
				"base" => "NEKO_SLIDER",
				"class" => "",
				"category" => esc_html__( "Neko shortcodes", "neko-slider"),
				"icon" => plugins_url( '/assets/image/icon-neko-slider.png', __FILE__ ),
				"params" => array(

				/**
				 * TITLE
				 */		    	
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => esc_html__( "Select your slider", "neko-slider" ),
					"param_name" => "slug",
					"value" => $output,
					"description" => esc_html__( "Select the slider you wan to show here", "neko-slider" ),
					'admin_label' => true
					)

				)
				)
			);

		add_shortcode('NEKO_SLIDER', array( $this, 'neko_slider_shortcode'));

	}	



}
