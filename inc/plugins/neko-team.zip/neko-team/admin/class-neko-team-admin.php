<?php
/**
 * Plugin Name.
 *
 * @package   Neko_Team_Admin
 * @author    Thomas Bechier
 * @license   GPL-2.0+
 * @link      http://www.little-neko.com
 * @copyright 2014 Thomas Bechier
 */

/**
 * Plugin class. This class should ideally be used to work with the
 * administrative side of the WordPress site.
 *
 * If you're interested in introducing public-facing
 * functionality, then refer to `class-plugin-name.php`
 *
 * @TODO: Rename this class to a proper name for your plugin.
 *
 * @package Neko_Team_Admin
 * @author  Thomas Bechier
 */

class Neko_Team_Admin {

	/**
	 * Instance of this class.
	 *
	 * @since    1.0.0
	 *
	 * @var      object
	 */
	protected static $instance = null;

	/**
	 * Slug of the plugin screen.
	 *
	 * @since    1.0.0
	 *
	 * @var      string
	 */
	protected $plugin_screen_hook_suffix = null;


	/**
	 * admin inlude path.
	 *
	 * @since    1.0.0
	 *
	 * @var      string
	 */
	const NP_INCLUDES = 'includes/';



	/**
	 * Initialize the plugin by loading admin scripts & styles and adding a
	 * settings page and menu.
	 *
	 * @since     1.0.0
	 */
	private function __construct() {

		/*
		 * @TODO :
		 *
		 * - Uncomment following lines if the admin class should only be available for super admins
		 */
		/* if( ! is_super_admin() ) {
			return;
		} */

		/*
		 * Call $plugin_slug from public plugin class.
		 */
		$plugin = Neko_Team::get_instance();
		$this->plugin_slug = $plugin->get_plugin_slug();

		/* Load admin style sheet and JavaScript. */
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_styles' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );

		/* Add the options page and menu item. */
		//add_action( 'admin_menu', array( $this, 'add_plugin_admin_menu' ) );

		/* Add an action link pointing to the options page. */
		// add_action( 'admin_init', array( $this, 'register_neko_team_settings'));
		// $plugin_basename = plugin_basename( plugin_dir_path( dirname(__FILE__) ) . $this->plugin_slug . '.php' );
		// add_filter( 'plugin_action_links_' . $plugin_basename, array( $this, 'add_action_links' ) );
		

		/*
		 * Define custom functionality.
		 * Read more about actions and filters:
		 * http://codex.wordpress.org/Plugin_API#Hooks.2C_Actions_and_Filters
		 */

		/* add images sizes */
		add_action( 'init', array( $this, 'addNekoTeamImageizes') );
		add_action( 'init', array( $this, 'neko_init' ), 2 );
		/* clean on delete */
		add_action('delete_neko_team_category', array( $this, 'neko_delete_tax'));


	}






	/**
	 * Return an instance of this class.
	 *
	 * @since     1.0.0
	 *
	 * @return    object    A single instance of this class.
	 */
	public static function get_instance() {

		/*
		 * @TODO :
		 *
		 * - Uncomment following lines if the admin class should only be available for super admins
		 */
		/* if( ! is_super_admin() ) {
			return;
		} */

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	/**
	 * Register and enqueue admin-specific style sheet.
	 * @since     1.0.0
	 *
	 * @return    null    Return early if no settings page is registered.
	 */
	public function enqueue_admin_styles() {

		if ( ! isset( $this->plugin_screen_hook_suffix ) ) {
			return;
		}

		$screen = get_current_screen();
		if ( $this->plugin_screen_hook_suffix == $screen->id ) {
			wp_enqueue_style( $this->plugin_slug .'-admin-styles', plugins_url( 'assets/css/admin.css', __FILE__ ), array(), Neko_Team::VERSION );
		}

	}

	/**
	 * Register and enqueue admin-specific JavaScript.
	 * @since     1.0.0
	 *
	 * @return    null    Return early if no settings page is registered.
	 */
	public function enqueue_admin_scripts() {

		// if ( ! isset( $this->plugin_screen_hook_suffix ) ) {
		// 	return;
		// }

		$screen = get_current_screen();
		if ( $this->plugin_screen_hook_suffix == $screen->id || 'edit-neko_team_category' == $screen->id ) {
			wp_enqueue_script( $this->plugin_slug . '-admin-script', plugins_url( 'assets/js/admin.js', __FILE__ ), array( 'jquery' ), Neko_Team::VERSION );
		}

	}

	/**
	 * Register the administration menu for this plugin into the WordPress Dashboard menu.
	 *
	 * @since    1.0.0
	 */
	public function add_plugin_admin_menu() {

		/*
		 * Add a settings page for this plugin to the Settings menu.
		 *
		 * NOTE:  Alternative menu locations are available via WordPress administration menu functions.
		 *
		 *        Administration Menus: http://codex.wordpress.org/Administration_Menus
		 *
		 * @TODO:
		 *
		 * - Change 'Page Title' to the title of your plugin admin page
		 * - Change 'Menu Text' to the text for menu item for the plugin settings page
		 * - Change 'manage_options' to the capability you see fit
		 *   For reference: http://codex.wordpress.org/Roles_and_Capabilities
		 */
		$this->plugin_screen_hook_suffix = add_submenu_page(
			'edit.php?post_type=neko_team',
			esc_html__( 'Team settings', 'neko-team' ),
			esc_html__( 'Team settings', 'neko-team' ),
			'manage_options',
			$this->plugin_slug,
			array( $this, 'display_plugin_admin_page' )
		);

	}

	/**
	 * Render the settings page for this plugin.
	 *
	 * @since    1.0.0
	 */
	public function display_plugin_admin_page() {
		include_once( 'views/admin.php' );
	}

	/**
	 * Add settings action link to the plugins page.
	 *
	 * @since    1.0.0
	 */
	public function add_action_links( $links ) {
		$postType = str_replace('-', '_', $this->plugin_slug);
		return array_merge(
			array( 'settings' => '<a href="' . admin_url( 'edit.php?post_type=' . $postType .'&page='.$this->plugin_slug) . '">' . esc_html__( 'Settings', 'neko-team' ) . '</a>' )
			, $links 
		);

	}


	/**
	 *  Registers options for the neko team settings page.
	 *
	 * @since    1.0.0
	 */
	public function register_neko_team_settings() {

		$option_slug = str_replace('-', '_', $this->plugin_slug);

		register_setting( $this->plugin_slug.'-option-group', $option_slug.'_options' );

		add_settings_section( 'neko_team_radio_section', esc_html__('Neko Team general layout options', 'neko-team'), array($this, 'display_section'), $this->plugin_slug.'-option-group');

		/* Create textbox field */
		$field_display_skills = array(
			'type'      => 'radio',
			'id'        => $option_slug.'_display_skills',
			'name'      => $option_slug.'_display_skills',
			'desc'      => esc_html__('Check yes if you want to display skills progress bar for members of your team', 'neko-team'),
			'std'       => 1,
			'class'     => 'radioField',
			'values' => array(0 => esc_html__('yes', 'neko-team'), 1 => esc_html__('no', 'neko-team'))
		);

		add_settings_field( $option_slug.'_display_skills', 'Display Skills', array($this, 'display_setting'), $this->plugin_slug.'-option-group', 'neko_team_radio_section', $field_display_skills );

		$field_display_skill_value = array(
			'type'      => 'radio',
			'id'        => $option_slug.'_display_skill_value',
			'name'      => $option_slug.'_display_skill_value',
			'desc'      => esc_html__('Check yes if you want to display skills percentage in the progress bar for all members of your team', 'neko-team'),
			'std'       => 1,
			'class'     => 'radioField',
			'values' => array(0 => esc_html__('yes', 'neko-team'), 1 => esc_html__('no', 'neko-team'))
		);


		add_settings_field( $option_slug.'_display_skill_value', 'Display Skill value', array($this, 'display_setting'), $this->plugin_slug.'-option-group', 'neko_team_radio_section', $field_display_skill_value );
	}


	public function display_section($section){ 

	}



	public function display_setting($args)
	{	

		extract( $args );
		
		$option_name = 'neko_team_options';

		$options = get_option( $option_name );

		switch ( $type ) {

			case 'radio':  
			$options[$id] = stripslashes($options[$id]);  
			$options[$id] = esc_attr( $options[$id]);
			$checked = (isset($options[$id]) && '' !== $options[$id])?$options[$id]:$std;
	
			foreach ($values as $key => $value) {
				echo "<label>$value</label>";
			  	echo "<input class='$class' type='radio' id='$id' name='" . $option_name . "[$id]' value='$key' ".checked( $key, $checked, false )."/>";  	 
			} 

			echo ($desc != '') ? "<span class='description'>$desc</span>" : "";

			break;  
		}
	}



	/**
	 * Add images sizes.
	 *
	 * @since    1.0.0
	 */

	public function addNekoTeamImageizes(){

		if (!in_array('img-large-ms', get_intermediate_image_sizes())){
			add_image_size( 'img-large-ms', 570 );
		}
	}




	/**
	 * After theme setup hook
	 * Add all actions that needs to be executed within the after theme setup hook
	 * @since    1.0.0
	 */
	public function neko_init(){

		require_once( self::NP_INCLUDES . 'metabox-post/team_settings.php');
		require_once( self::NP_INCLUDES . 'metabox-post/team_skills.php');
		require_once( self::NP_INCLUDES . 'metabox-post/team_social.php');
		require_once( self::NP_INCLUDES . 'metabox-taxonomy/team-cat.php');
		
	}


	/**
	 * After custom taxonomy delete hook
	 * Add all actions that needs to be executed within the after theme setup hook
	 * @since    1.0.0
	 */
	public function neko_delete_tax($tax_id){
		delete_option('tax_meta_'.$tax_id);
	}

	
//END OF CLASS
}
