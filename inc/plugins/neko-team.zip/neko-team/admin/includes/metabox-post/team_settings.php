<?php

if (is_admin()){
	$prefix = 'neko_team_';
	$pluginUri = plugins_url();
	/**
	* configure your meta box
	*/
	$config = array(
	'id'             => 'neko_team_member_settings_meta_box',           // meta box id, unique per meta box
	'title'          => esc_html__('Team member settings','neko-team'),           // meta box title
	'pages'          => array('neko_team'),     // post types, accept custom post types as well, default is array('post'); optional
	'context'        => 'normal',                        // where the meta box appear: normal (default), advanced, side; optional
	'priority'       => 'high',                        // order of meta box: high (default), low; optional
	'fields'         => array(),                       // list of meta fields (can be added by field arrays)
	'local_images'   => false,                         // Use local or hosted images (meta box images for add/remove)                      
	'use_with_theme' => $pluginUri . '/neko-team/includes/tools/neko-metabox-generator/engine' //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
	);



	/**
	* Initiate your meta box
	*/
	$my_meta =  new Neko_Team_Meta_extends_Class($config);


	/**
	* Add fields to your meta box
	*/

	//function 
	$title_function = esc_html__('Function', 'neko-team');
	$desc_function = esc_html__('Choose one of the themes defined in option panel, to change background color', 'neko-team');

	$my_meta->addText($prefix.'function',array('name'=> $title_function));


	//email 
	$title_email = esc_html__('Email', 'neko-team');

	$my_meta->addText($prefix.'email',array('name'=> $title_email));

	//Finish Meta Box Declaration 
	$my_meta->Finish();



}