<?php
if (is_admin()){

	$prefix = 'neko_team_';
	$pluginUri = plugins_url();
	
	/**
	* configure your meta box
	*/
	$config = array(
	'id'             => 'neko_team_member_skills_meta_box',           // meta box id, unique per meta box
	'title'          => esc_html__('Skills','neko-team'),           // meta box title
	'pages'          => array('neko_team'),     // post types, accept custom post types as well, default is array('post'); optional
	'context'        => 'normal',                        // where the meta box appear: normal (default), advanced, side; optional
	'priority'       => 'low',                        // order of meta box: high (default), low; optional
	'fields'         => array(),                       // list of meta fields (can be added by field arrays)
	'local_images'   => false,                         // Use local or hosted images (meta box images for add/remove)                        
	'use_with_theme' => $pluginUri . '/neko-team/includes/tools/neko-metabox-generator/engine' //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
	);


	/**
	* Initiate your meta box
	*/
	$my_meta =  new Neko_Team_Meta_extends_Class($config);


	/**
	* Add fields to your meta box
	*/
	$title_skills = esc_html__('skill name ', 'neko-team');
	$title_level = esc_html__('Level in %', 'neko-team');

	$repeater_fields[] = $my_meta->addText($prefix.'skill_name',array('name'=> $title_skills ),true);
	$repeater_fields[] = $my_meta->addText($prefix.'skill_value',array('name'=> $title_level ),true);

	$my_meta->addRepeaterBlock($prefix.'re_skills',array('inline' => true, 'name' => 'Add skills and level in value for each skills','fields' => $repeater_fields));

	$my_meta->Finish();
}