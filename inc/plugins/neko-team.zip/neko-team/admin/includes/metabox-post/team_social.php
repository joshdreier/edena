<?php

if (is_admin()){
	$prefix = 'neko_team_';
	$pluginUri = plugins_url();
	/* 
	* configure your meta box
	*/
	$config = array(
	'id'             => 'neko_team_member_social_meta_box',           // meta box id, unique per meta box
	'title'          => esc_html__('Social medias','neko-team'),           // meta box title
	'pages'          => array('neko_team'),     // post types, accept custom post types as well, default is array('post'); optional
	'context'        => 'normal',                        // where the meta box appear: normal (default), advanced, side; optional
	'priority'       => 'high',                        // order of meta box: high (default), low; optional
	'fields'         => array(),                       // list of meta fields (can be added by field arrays)
	'local_images'   => false,                         // Use local or hosted images (meta box images for add/remove)        
	'use_with_theme' => $pluginUri . '/neko-team/includes/tools/neko-metabox-generator/engine' //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
	);

   /**
	* Initiate your meta box
	*/
	$my_meta =  new Neko_Team_Meta_extends_Class($config);


   /**
	* Add fields to your meta box
	*/
	$title_display_social_icons = esc_html__('Display social icons', 'neko-team');
	


	$social_icons_preset = array(
		'rss'        => 'Rss',
		'facebook'   => 'Facebook', 
		'twitter'    => 'Twitter',
		'pinterest'  => 'Pinterest',
		'flickr'     => 'Flickr', 
		'dribbble'   => 'Dribbble', 
		'googleplus' => 'Google +', 
		'linkedin'   => 'Linkedin', 
		'tumblr'     => 'Tumblr', 
		'reddit'     => 'Reddit', 
		'yahoo'      => 'Yahoo', 
		'vimeo'      => 'Vimeo', 
		'youtube'    => 'Youtube'
		);


	$repeater_fields_nt_preset[] = $my_meta->addSelect($prefix.'network_type_preset', $social_icons_preset, array('name'=> 'Select an network', 'std' => array('facebook'), 'class' => 'no-fancy'), true);
	$repeater_fields_nt_preset[] = $my_meta->addText($prefix.'network_url_preset', array('name'=> 'Social network url'), true);

	$my_meta->addRepeaterBlock($prefix.'re_network_type_preset',array('inline' => true, 'name' => 'Add a preset social network','fields' => $repeater_fields_nt_preset));

		/* $social_icons_custom = array(
			"neko-icon-linkedin-1",
			"neko-icon-googleplus-1",
			"neko-icon-instagram-1", 
			"neko-icon-vimeo-1",
			"neko-icon-twitter-1",
			"neko-icon-youtube-1",
			"neko-icon-github-1",
			"neko-icon-flickr-1",
			"neko-icon-facebook-1",
			"neko-icon-dropbox-1",
			"neko-icon-dribbble-1",
			"neko-icon-apple-1",
			"neko-icon-android-1",
			"neko-icon-wordpress-1",
			"neko-icon-vimeo-2",
			"neko-icon-twitter-2",
			"neko-icon-tumbler-2",
			"neko-icon-soundcloud-1",
			"neko-icon-sharethis-1",
			"neko-icon-sharethis-3",
			"neko-icon-reddit-1",
			"neko-icon-pinterest-2",
			"neko-icon-windows-2",
			"neko-icon-windows-1",
			"neko-icon-linux-1",
			"neko-icon-drupal-1",
			"neko-icon-dropbox-2",
			"neko-icon-rss-1",
			"neko-icon-rss-2",
			"neko-icon-mail-1",
			"neko-icon-tumbler-1",
			"neko-icon-skype-1",
			"neko-icon-pinterest-1"
			); */

$repeater_fields_nt_custom[] = $my_meta->addText($prefix.'network_name_custom', array('name'=> 'Social network name'), true);
$repeater_fields_nt_custom[] = $my_meta->addText($prefix.'network_icon_custom', array('name'=> 'Select an icon', 'desc' => 'check out available icons <a href="'. plugins_url( '../../public/assets/font-icons/demo.html', dirname(__FILE__)).'" target="_blank">here</a>'), true);
$repeater_fields_nt_custom[] = $my_meta->addText($prefix.'network_url_custom', array('name'=> 'Social network url'), true);

$my_meta->addRepeaterBlock($prefix.'re_network_type_custom',array('inline' => true, 'name' => 'Add a custom social network','fields' => $repeater_fields_nt_custom));


$my_meta->Finish();
}