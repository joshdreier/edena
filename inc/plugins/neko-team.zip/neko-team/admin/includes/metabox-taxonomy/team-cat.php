<?php

if (is_admin()){

  /** 
   * prefix of meta keys, optional
   * use underscore (_) at the beginning to make keys hidden, for example $prefix = '_ba_';
   *  you also can make prefix empty to disable it
   */
  $prefix = 'neko_team_';
  $pluginUri = plugins_url();

  /** 
   * configure your meta box
   */
  $config = array(
    'id'             => 'neko_team_meta_box',      			    // meta box id, unique per meta box
    'title'          => esc_html__('Team settings', 'neko-team'),      					// meta box title
    'pages'          => array('neko_team_category'),       		// post types, accept custom post types as well, default is array('post'); optional
    'context'        => 'normal',                       		// where the meta box appear: normal (default), advanced, side; optional
    'priority'       => 'high',                         		// order of meta box: high (default), low; optional
    'fields'         => array(),                        		// list of meta fields (can be added by field arrays)
    'local_images'   => false,                          		// Use local or hosted images (meta box images for add/remove)                        		
    'use_with_theme' => $pluginUri . '/neko-team/includes/tools/neko-metabox-tax-generator/engine' //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
    );


  /*
   * Trad Vars
   */

  $on  = esc_html__('On','neko-team');
  $off = esc_html__('Off','neko-team');





  /**
   * Initiate your meta box
   */
  
  $my_meta =  new Neko_Team_Tax_Meta_extends_Class($config);
  

  /**
   * Add fields to your meta box
   */

  // Choose team layout
  $title_team_layout = esc_html__('Team Layout', 'neko-team');
  $desc_team_layout = esc_html__('Set how your team is going to be displayed', 'neko-team');
  $my_meta->addSelect($prefix.'display_type',array('0'=> esc_html__('columns', 'neko-team'),'1'=> esc_html__('line', 'neko-team'),'2'=> esc_html__('mosaic', 'neko-team'),'3'=> esc_html__('rollover', 'neko-team'),'4'=> esc_html__('columns no padding', 'neko-team'),'5'=> esc_html__('rollover no padding', 'neko-team'),'6'=> esc_html__('rounded pics', 'neko-team') ),array('name'=> $title_team_layout, 'desc' => $desc_team_layout, 'std'=> array('0')));



  // Display skills
  $title_team_ds = esc_html__('Display Skills', 'neko-team');
  $desc_team_ds  = esc_html__('Check yes if you want to display skills', 'neko-team');
  $my_meta->addRadio($prefix.'display_skills',array('0'=>$off,'1'=>$on),array('name'=> $title_team_ds, 'desc' => $desc_team_ds, 'std'=> array('0')));


  // Display skills values
  $title_team_dsv = esc_html__('Display Skills Value', 'neko-team');
  $desc_team_dsv  = esc_html__('Check yes if you want to display skills percentage in the progress bar for all members of this team', 'neko-team');
  $my_meta->addRadio($prefix.'display_skills_value',array('0'=>$off,'1'=>$on),array('name'=> $title_team_dsv, 'desc' => $desc_team_dsv, 'std'=> array('0')));

  
  // Display content
  $title_team_ct = esc_html__('Display Content', 'neko-team');
  $desc_team_ct  = esc_html__('Check yes if you want the content of each team member to be shown', 'neko-team');
  $my_meta->addRadio($prefix.'display_content',array('0'=>$off,'1'=>$on),array('name'=> $title_team_ct, 'desc' => $desc_team_ct, 'std'=> array('0')));


  // Display email
  $title_team_ct = esc_html__('Display Email', 'neko-team');
  $desc_team_ct  = esc_html__('Check yes if you want the email of each team member to be shown', 'neko-team');
  $my_meta->addRadio($prefix.'display_email',array('0'=>$off,'1'=>$on),array('name'=> $title_team_ct, 'desc' => $desc_team_ct, 'std'=> array('0')));

  // Display social
  $title_team_ct = esc_html__('Display Social Icons', 'neko-team');
  $desc_team_ct  = esc_html__('Check yes if you want the social icons of each team member to be shown', 'neko-team');
  $my_meta->addRadio($prefix.'display_social',array('0'=>$off,'1'=>$on),array('name'=> $title_team_ct, 'desc' => $desc_team_ct, 'std'=> array('0')));


  // Social Icon Style
  $title_team_sis = esc_html__('Social Icon Style', 'neko-team');
  $desc_team_sis  = esc_html__('Change the way social icons looks like for all team members in this of this team', 'neko-team');
  $my_meta->addRadio($prefix.'social_icon_style',array('0'=>esc_html__('normal', 'neko-team'),'1'=>esc_html__('rounded', 'neko-team')),array('name'=> $title_team_sis, 'desc' => $desc_team_sis, 'std'=> array('0')));


  // Display shortcode
  if(!empty($_GET['tag_ID'])){
  	$title_portfolio_shortcode = esc_html__('Team shortcode', 'neko-team');
  	$my_meta->addShortcodeTxt('shortcode_field_id',array('taxonomy'=> 'neko_team_category', 'shortcodename' => 'NEKO_TEAM', 'class' => 'nekoInfoParag'));
  }

  // Finish Meta Box Declaration 
  $my_meta->Finish();


}