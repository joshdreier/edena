<?php
/**
 * Represents the view for the public-facing component of the plugin.
 *
 * This typically includes any information, if any, that is rendered to the
 * frontend of the theme when the plugin is activated.
 *
 * @package   Plugin_Name
 * @author    Your Name <email@example.com>
 * @license   GPL-2.0+
 * @link      http://example.com
 * @copyright 2014 Your Name or Company Name
 */
?>

<!-- This file is used to markup the public facing aspect of the plugin. -->

<?php
//INIT VARS
$post_type = 'neko_team';
$taxonomy  = 'neko_team_category';

/* Layout selector */
$display_view        = get_tax_meta($neko_team_id,'neko_team_display_type');

/* Skills params */
$show_skills       = get_tax_meta( $neko_team_id, 'neko_team_display_skills' );
$show_skill_value = get_tax_meta($neko_team_id,'neko_team_display_skills_value');

/* Content params */
$show_content      = get_tax_meta( $neko_team_id, 'neko_team_display_content' );
$show_email        = get_tax_meta( $neko_team_id, 'neko_team_display_email' );

/* Social params */
$show_social       = get_tax_meta( $neko_team_id, 'neko_team_display_social' );
$iconType            = ( '1' === get_tax_meta($neko_team_id,'neko_team_social_icon_style'))?'circle':'';


$args=array(
	'post_type' => $post_type,
	'tax_query' => array(
		array(
			'taxonomy' => $taxonomy,
			'terms' => function_exists('icl_object_id')?icl_object_id($neko_team_id,$taxonomy,false):$neko_team_id,
			'field' => 'term_id'
			)
		),
	'post_status' => 'publish'
	);

$loop = new WP_Query( $args );

//increment
$i = 1;

/**
 * INIT VARS
 */

$return  = '';

$no_padding = ( '4' === $display_view || '5' === $display_view ) ? 'neko-team-nopadding' : '';
$rounded_pics = ( '6' === $display_view  ) ? 'neko-team-roundedpics' : '';
if( '2' !== $display_view ){ $return .= '<div class="row '.esc_attr($no_padding).' '.esc_attr($rounded_pics).'">'; }


while ( $loop->have_posts() ) : $loop->the_post(); 

$HTML_social_icons = '';
$HTML_skills       = '';

/**
 * IMG
 */
$thumb_id  = get_post_thumbnail_id();
$alt_media = get_post_meta( $thumb_id, '_wp_attachment_image_alt', true );
$alt       = ( !empty($alt_media) )?$alt_media:get_the_title();
$thumb_url = wp_get_attachment_image_src( $thumb_id,'img-x-large-ms' );
$team_pic  = $thumb_url[0];
/* END IMG */


/**
 * PERSONAL INFOS
 */
$people_names      = get_the_title();
$people_content    = ( '1' === $show_content )?get_the_content():'';
$people_function   = get_post_meta( get_the_ID(), 'neko_team_function', true );

$email_raw = get_post_meta( get_the_ID(), 'neko_team_email', true );
$people_email_link = ('1' === $show_email && !empty($email_raw) )?'<a href="mailto:'.get_post_meta( get_the_ID(), 'neko_team_email', true ).'" class="neko_team_email">'.get_post_meta( get_the_ID(), 'neko_team_email', true ).'</a>':'';
/* END PERSONAL INFOS */


/**
 * Social Icons
 */
if ( '1' === $show_social ) {

	$HTML_social_icons.= '<ul class="social-network">';

	/* REGULAR NETWORKS */
	$reg_networks_type_preset   = get_post_meta( get_the_ID(), 'neko_team_re_network_type_preset', false  );
	if(!empty($reg_networks_type_preset[0])){
		foreach ($reg_networks_type_preset[0] as $key => $value) {
			$icon_name   = 'neko-social-icon-'.$value['neko_team_network_type_preset'].'-1';

			switch ($value['neko_team_network_type_preset']) {
				case 'googleplus':
					$network_name = 'Google +';
					break;
				case 'linkedin':
					$network_name = 'Linked In';
					break;	
				default:
					$network_name = $value['neko_team_network_type_preset'];
					break;
			}

			$HTML_social_icons .= '
			<li>
				<a href="'.$value['neko_team_network_url_preset'].'" class="tips social-icon-'.$value['neko_team_network_type_preset'].'" target="_blank" title="Follow me on '.ucfirst($network_name).'">
					<i class="icon-neko '.$icon_name.' '.$iconType.'"></i>
				</a>
			</li>';

		}
	}

	/* CUSTOM NETWORKS */
	$reg_networks_type_custom   = get_post_meta( get_the_ID(), 'neko_team_re_network_type_custom', false  );
	if(!empty($reg_networks_type_custom[0])){
		foreach ($reg_networks_type_custom[0] as $key => $value) {
			
			$icon_name   = str_replace('team', 'social', $value['neko_team_network_icon_custom']);

			$HTML_social_icons .= '
			<li>
				<a href="'.$value['neko_team_network_url_custom'].'" class="tips social-icon-custom " target="_blank" title="Follow me on '.ucfirst($value['neko_team_network_name_custom']).'">
					<i class="icon-neko '.$icon_name.' '.$iconType.'"></i>
				</a>
			</li>';

		}
	}

	$HTML_social_icons.= '</ul>';
}
/* END SOCIAL ICONS */


/**
 * Skills progress bar
 */
if( '1' === $show_skills ){
	$reg_skills = get_post_meta( get_the_ID(), 'neko_team_re_skills', false  );
	if(!empty($reg_skills[0])){
		$HTML_skills .= '<div class="item-skills">';
		foreach ($reg_skills[0] as $key => $value) {

			$skill_name      = 'neko_team_skill_name'.$i;
			$skill_value_num = 'neko_team_skill_value'.$i;
			$skill_value     = $value['neko_team_skill_value'];

			if (!empty($skill_value)){
				$HTML_skills .= '<h4>'.$value['neko_team_skill_name'].'</h4>';
				$HTML_skills .= '<div class="progress">';
				$HTML_skills .= '<div class="progress-bar" role="progressbar" aria-valuenow="'.$skill_value.'" aria-valuemin="0" aria-valuemax="100" style="width: '.$skill_value.'%;">';
				$HTML_skills .= '<span class="sr-only">'.$skill_value.'% Complete</span>';

				if ( '1' === $show_skill_value ) {
					$HTML_skills .= '<span class="neko-team-skill-value">'.$skill_value.'%</span>';
				}

				$HTML_skills .= '</div></div>';
			}
		}
		$HTML_skills .= '</div>';
	}	
}

/* END SKILLS */


/* VIEWS SWITCH */
switch ($display_view) {
	case '0': /* COLUMNS */
		$no_padding = '';
		include('partials/neko_team_column.php');
		break;

	case '1': /* LINES */
		include('partials/neko_team_line.php');
		break;	

	case '2': /* MOSAIC */
		include('partials/neko_team_mosaic.php');
		break;

	case '3': /* ROLLOVER */
		include('partials/neko_team_rollover.php');
		break;	

	case '4': /* COLUMNS */
		include('partials/neko_team_column.php');
		break;

	case '5': /* ROLLOVER */
		include('partials/neko_team_rollover.php');
		break;

	case '6': /* ROLLOVER */
		include('partials/neko_team_column.php');
		break;

	default: /* DEFAULT TO COLUMNS */
		include('partials/neko_team_column.php');
		break;
}
/* VIEWS SWITCH */

$i++;

endwhile; 
wp_reset_query();


if( '2' !== $display_view ){ $return .= '</div>'; }
//$return .= '</div>';


echo $return;	 
?>