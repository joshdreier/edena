<?php

$return .= '<article class="row neko-team neko-team-mosaic">';

$swicth_class_pic  = '';
$swicth_class_info = '';
if(0 === $i % 2) {
	$swicth_class_pic = 'col-md-push-6';
	$swicth_class_info = 'col-md-pull-6';
}

$return .= '<div class="col-md-6 item-media '.esc_attr($swicth_class_pic).'" style="background-image:url('.esc_url($team_pic).')"></div>';

$return .= '<div class="col-md-6 col-md-offset-6 item-content '.esc_attr($swicth_class_info).'">';

$return .= '<h2><span>'.$people_function.'</span>'.$people_names.'</h2>';
$return .= $people_email_link;
$return .= $people_content;
$return .= $HTML_social_icons;
$return .= $HTML_skills;

$return .= '</div>';

$return .= '</article>';