<?php

$return .= '<article class="row neko-team neko-team-line">';

/* BLOC 1 */
$return .= '<div class="col-md-3">';
/* IMG */
$return .= '<img src="'.esc_url($team_pic).'" class="neko-force-fullwidth" alt="" />';
$return .= '</div>';
/* BLOC 1 */

/* BLOC 2 */
$bloc2_class = ( !empty($HTML_skills) ) ? 'col-md-3' : 'col-md-9' ;
$return .= '<div class="'.esc_attr($bloc2_class).'"><div class="item-content">';

/* INFOS */
$return .= '<h2>'.$people_names.'<span>'.$people_function.'</span></h2>';
$return .= $people_email_link;
$return .= $people_content;

/* SOCIAL ICONS */
$return .= $HTML_social_icons;

$return .= '</div></div>';
/* BLOC 2 */

/* BLOC 3 */
if(!empty($HTML_skills)){
	$return .= '<div class="col-md-6">';
	/* SKILLS */
	$return .= $HTML_skills;
	$return .= '</div>';
}
/* BLOC 3 */

$return .= '</article>';