<?php

/* get total elements */
$item_count = $loop->post_count;

switch ($item_count) {

	case 1:
	$span ='col-sm-4 col-sm-offset-4';
	break;

	case 2:
	$span1 ='col-md-4 col-md-offset-2 col-sm-6';
	$span  ='col-md-4 col-sm-6';
	break;

	case $item_count % 3 == 0:
	$span ='col-sm-4';
	break;

	default:
	$span ='col-md-3 col-sm-6';
	break;

}

$cards_class= (6==$display_view)?'':' neko-team-cards';

$applied_class = ( 2 == $item_count && 1 == $i )? $span1 : $span ;

$return .= '<article class="'.esc_attr($applied_class).' neko-team'.$cards_class.'">';

$return .= '<figure>';

/* IMG */
$return .= '<img src="'.esc_url($team_pic).'" class="neko-force-fullwidth item-media" alt="'.esc_attr($alt).'" />';


$return .= '<figcaption class="item-content">';
/* INFOS */
$return .= '<h2>'.$people_names.'<span>'.$people_function.'</span></h2>';
$return .= $people_email_link;
$return .= $people_content;
/* END INFOS */

/* SOCIAL ICONS */
$return .= $HTML_social_icons;
/* END SOCIAL ICONS */

/* SKILLS */
$return .= $HTML_skills;
/* END SKILLS */


$return .= '</figcaption>';

$return .= '</figure>';

$return .= '</article>';
