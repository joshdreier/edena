<?php

/* get total elements */
$item_count = $loop->post_count;

switch ($item_count) {

	case 1:
	$span ='col-sm-4 col-sm-offset-4';
	break;

	case 2:
	$span1 ='col-md-4 col-md-offset-2 col-sm-6';
	$span  ='col-md-4 col-sm-6';
	break;

	case $item_count % 3 == 0:
	$span ='col-sm-4';
	break;

	default:
	$span ='col-md-3 col-sm-6';
	break;

}

$applied_class = ( 2 == $item_count && 1 == $i )? $span1 : $span ;

$rollover_class = ( '3' === $display_view || '5' === $display_view  ) ? 'rollover effect-sarah' : '' ;



$return .= '<article class="'.esc_attr($applied_class).' '.esc_attr($rollover_class).' neko-team neko-team-rollover">';

$return .= '<figure>';

/* IMG */
$return .= '<img src="'.esc_url($team_pic).'" class="neko-force-fullwidth" alt="'.esc_attr($alt).'" />';

/* INFOS */
$return .= '<figcaption>';
$return .= '<div class="description">';
// $return .= '<h2>'.$people_function.'</h2>';
// $return .= $people_email_link;
$return .= $people_content;
/* END INFOS */



$return .= '</div>';

$return .= '</figcaption>';

$return .= '</figure>';

$return .= '<div class="item-content">';
/* INFOS */
$return .= '<h2><span>'.$people_function.'</span>'.$people_names.'</h2>';
$return .= $people_email_link;
/* END INFOS */

/* SOCIAL ICONS */
$return .= $HTML_social_icons;
/* END SOCIAL ICONS */

/* SKILLS */
$return .= $HTML_skills;
/* END SKILLS */

$return .= '</div>';

$return .= '</article>';