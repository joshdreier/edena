(function ( $ ) {
	"use strict";

	$(function () {

			/** New rollover system **/
			if (Modernizr.touch) {
				var original_href;
				$('[class*="effect-"] figure').on('touchstart', function(){
					if(!$(this).hasClass('hovered')){
						if($('figcaption>a', this).length && $('figcaption>a', this).attr('href') != 'javascript://' && $('figcaption>a', this).css('display') != 'none' ){
							original_href = $('figcaption>a', this).attr('href');
						}else{
							original_href = 'empty';
						}
					}
					$('figcaption .rollover-content a', this).on( 'touchstart', function(e) {
						e.stopPropagation();
					});
					if(!$(this).hasClass('hovered')){
						$('[class*="effect-"] figure').removeClass('hovered');
						$(this).addClass('hovered');
						$('figcaption>a', this).attr('href','javascript://');
					}else{
						$(this).removeClass('hovered');
						if(original_href != 'empty'){
							var clickedLink = $('figcaption>a', this);
							clickedLink.attr('href', original_href);
							setTimeout(function(){
								window.location.href = original_href;
							}, 500);
						}
					}
				});	
			} else { 
				$('[class*="effect-"] figure').hover(function() {
					$(this).addClass('hovered');
				}, function() {
					$(this).removeClass('hovered');
				});
			} 
			/** End new rollover system **/

	});

}(jQuery));