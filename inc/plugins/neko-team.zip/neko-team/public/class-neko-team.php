<?php
/**
 * Neko Team.
 *
 * @package   Neko_Team
 * @author    Thomas Bechier
 * @license   GPL-2.0+
 * @link      http://www.little-neko.com
 * @copyright 2014 Thomas Bechier
 */

/**
 * Plugin class. This class should ideally be used to work with the
 * public-facing side of the WordPress site.
 *
 * If you're interested in introducing administrative or dashboard
 * functionality, then refer to `class-plugin-name-admin.php`
 *
 * @TODO: Rename this class to a proper name for your plugin.
 *
 * @package Neko_Team
 * @author  Thomas Bechier
 */

class Neko_Team {

	/**
	 * Plugin version, used for cache-busting of style and script file references.
	 *
	 * @since   1.0.0
	 *
	 * @var     string
	 */
	const VERSION = '2.0';

	/**
	 * The variable name is used as the text domain when internationalizing strings
	 * of text. Its value should match the Text Domain file header in the main
	 * plugin file.
	 *
	 * @since    1.0.0
	 *
	 * @var      string
	 */
	protected $plugin_slug = 'neko-team';

	/**
	 * Instance of this class.
	 *
	 * @since    1.0.0
	 *
	 * @var      object
	 */
	protected static $instance = null;

	/**
	 * admin inlude path.
	 *
	 * @since    1.0.0
	 * @var      string
	 */
	const NP_INCLUDES = 'includes/';


	/**
	 * Initialize the plugin by setting localization and loading public scripts
	 * and styles.
	 *
	 * @since     1.0.0
	 */
	private function __construct() {

		// Load plugin text domain
		add_action( 'init', array( $this, 'load_plugin_textdomain' ), 1 );

		// Activate plugin when new blog is added
		add_action( 'wpmu_new_blog', array( $this, 'activate_new_site' ) );

		// Load public-facing style sheet and JavaScript.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

	
		/* 
		 * Custom functionality.
		 */
		
		add_action( 'init', array( $this, 'neko_init'), 2);

		/**
		 * If visual compser is installed add team to it
		 */
		if ( defined( 'WPB_VC_VERSION' ) ) {
			add_action( 'init', array( $this, 'neko_add_shortcode_to_vc'), 11);
		}else{
			add_shortcode('NEKO_TEAM', array( $this, 'neko_team_shortcode'));
		}

	}



	/**
	 * Return the plugin slug.
	 *
	 * @since    1.0.0
	 *
	 * @return    Plugin slug variable.
	 */

	public function get_plugin_slug() {
		return $this->plugin_slug;
	}

	/**
	 * Return an instance of this class.
	 *
	 * @since     1.0.0
	 *
	 * @return    object    A single instance of this class.
	 */
	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	/**
	 * Fired when the plugin is activated.
	 *
	 * @since    1.0.0
	 *
	 * @param    boolean    $network_wide    True if WPMU superadmin uses
	 *                                       "Network Activate" action, false if
	 *                                       WPMU is disabled or plugin is
	 *                                       activated on an individual blog.
	 */
	public static function activate( $network_wide ) {

		if ( function_exists( 'is_multisite' ) && is_multisite() ) {

			if ( $network_wide  ) {

				// Get all blog ids
				$blog_ids = self::get_blog_ids();

				foreach ( $blog_ids as $blog_id ) {

					switch_to_blog( $blog_id );
					self::single_activate();
				}

				restore_current_blog();

			} else {
				self::single_activate();
			}

		} else {
			self::single_activate();
		}

	}

	/**
	 * Fired when the plugin is deactivated.
	 *
	 * @since    1.0.0
	 *
	 * @param    boolean    $network_wide    True if WPMU superadmin uses
	 *                                       "Network Deactivate" action, false if
	 *                                       WPMU is disabled or plugin is
	 *                                       deactivated on an individual blog.
	 */
	public static function deactivate( $network_wide ) {

		if ( function_exists( 'is_multisite' ) && is_multisite() ) {

			if ( $network_wide ) {

				// Get all blog ids
				$blog_ids = self::get_blog_ids();

				foreach ( $blog_ids as $blog_id ) {

					switch_to_blog( $blog_id );
					self::single_deactivate();

				}

				restore_current_blog();

			} else {
				self::single_deactivate();
			}

		} else {
			self::single_deactivate();
		}

	}

	/**
	 * Fired when a new site is activated with a WPMU environment.
	 *
	 * @since    1.0.0
	 *
	 * @param    int    $blog_id    ID of the new blog.
	 */
	public function activate_new_site( $blog_id ) {

		if ( 1 !== did_action( 'wpmu_new_blog' ) ) {
			return;
		}

		switch_to_blog( $blog_id );
		self::single_activate();
		restore_current_blog();

	}

	/**
	 * Get all blog ids of blogs in the current network that are:
	 * - not archived
	 * - not spam
	 * - not deleted
	 *
	 * @since    1.0.0
	 *
	 * @return   array|false    The blog ids, false if no matches.
	 */
	private static function get_blog_ids() {

		global $wpdb;

		// get an array of blog ids
		$sql = "SELECT blog_id FROM $wpdb->blogs
			WHERE archived = '0' AND spam = '0'
			AND deleted = '0'";

		return $wpdb->get_col( $sql );

	}

	/**
	 * Fired for each blog when the plugin is activated.
	 *
	 * @since    1.0.0
	 */
	private static function single_activate() {
		// @TODO: Define activation functionality here
	}

	/**
	 * Fired for each blog when the plugin is deactivated.
	 *
	 * @since    1.0.0
	 */
	private static function single_deactivate() {
		// @TODO: Define deactivation functionality here
	}

	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		$domain = $this->plugin_slug;
		$locale = apply_filters( 'plugin_locale', get_locale(), $domain );
		load_plugin_textdomain( $domain, false, dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/' );

	}

	/**
	 * Register and enqueue public-facing style sheet.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		//custom font
		wp_enqueue_style( 'neko-social-icon', plugins_url( 'assets/font-icons/css/neko-social-icons.css', __FILE__ ), array(), self::VERSION);
		wp_enqueue_style( $this->plugin_slug . '-plugin-styles', plugins_url( 'assets/css/public.css', __FILE__ ), array(), self::VERSION );
	}

	/**
	 * Register and enqueues public-facing JavaScript files.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {
		//Modernizr
    	wp_enqueue_script( 'modernizr', plugins_url( 'assets/js/plugins/modernizr/modernizr-2.6.1.min.js'), null, '2.6.1', false );

		wp_enqueue_script( $this->plugin_slug . '-plugin-script', plugins_url( 'assets/js/public.js', __FILE__ ), array( 'jquery', 'modernizr' ), self::VERSION, true  );
	}


	/**
	 * Shortcode Activation
	 * @since    1.0.0
	 */
    public function neko_team_shortcode( $atts, $content = null ) {
    	

    	if ( defined( 'WPB_VC_VERSION' ) ) {
	    	$atts = vc_map_get_attributes( 'NEKO_TEAM', $atts );
	    	extract($atts);
	    }else{
	    	extract(
	    		shortcode_atts(
	    			array(
	    				'slug' => '',
	    				), $atts
	    			)
	    		);
	    }

    	$terms = get_term_by('slug', $slug, 'neko_team_category');
    	$neko_team_id = $terms->term_id;

    	ob_start();
    	include(plugin_dir_path( __FILE__ ) . 'views/public.php');
    	$content = ob_get_clean();
    	
    	return $content;
	}



	/**
	 * After theme setup hook
	 * Add all actions that needs to be executed within the after theme setup hook
	 * @since    1.0.0
	 */

	public function neko_init() {

		require_once( plugin_dir_path( dirname(__FILE__) ) . 'includes/tools/neko-metabox-generator/neko-metabox-class.php' );
		require_once( plugin_dir_path( dirname(__FILE__) ) . 'includes/tools/neko-metabox-tax-generator/neko-meta-box-class.php' );

		require_once( plugin_dir_path( dirname(__FILE__) ).'includes/custom-post/team-post.php' );
		require_once( plugin_dir_path( dirname(__FILE__) ).'includes/custom-taxonomy/team-taxonomy.php' );

	}



	/**
	 * Get team category
	 */
	public function neko_add_shortcode_to_vc() {

		$output = array(); 
		$terms = get_terms('neko_team_category', array('hide_empty' => 1) );
		//echo '<pre>'; print_r($terms); echo '</pre>';
		$count = count($terms);

		if ( $count > 0 ){
			foreach ( $terms as $term ){
				$output[$term->name] = $term->slug;
			}
		}

		vc_map( 
			array(
				"name" => esc_html__( "Neko team", "neko-team" ),
				"base" => "NEKO_TEAM",
				"class" => "",
				"category" => esc_html__( "Neko shortcodes", "neko-team"),
				"icon" => plugins_url( '/assets/image/icon-neko-team.png', __FILE__ ),
				"params" => array(

				/**
				 * TITLE
				 */		    	
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => esc_html__( "Select your team", "neko-team" ),
					"param_name" => "slug",
					"value" => $output,
					"description" => esc_html__( "Select the team you wan to show here", "neko-team" )
					)

				)
				)
			);

		add_shortcode('NEKO_TEAM', array( $this, 'neko_team_shortcode'));

	}
}
