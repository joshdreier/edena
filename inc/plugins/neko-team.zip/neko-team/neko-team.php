<?php

/**
 * The WordPress Plugin Boilerplate.
 *
 * A foundation off of which to build well-documented WordPress plugins that
 * also follow WordPress Coding Standards and PHP best practices.
 *
 * @package   Neko_Team
 * @author    Thomas Bechier
 * @license   GPL-2.0+
 * @link      http://www.little-neko.com
 * @copyright 2014 Thomas Bechier
 *
 * @wordpress-plugin
 * Plugin Name:       Neko Team
 * Plugin URI:        http://www.little-neko.com
 * Description:       Add team functionalities to your Little NEko theme.
 * Version:           1.0.1
 * Author:            Little Neko
 * Author URI:        http://www.little-neko.com
 * Text Domain:       neko-team
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Domain Path:       /languages
 * GitHub Plugin URI: https://github.com/<owner>/<repo>
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}


/*----------------------------------------------------------------------------*
 * Public-Facing Functionality
 *----------------------------------------------------------------------------*/

require_once( plugin_dir_path( __FILE__ ) . 'public/class-neko-team.php' );


/*

 * Register hooks that are fired when the plugin is activated or deactivated.
 * When the plugin is deleted, the uninstall.php file is loaded.
 */
register_activation_hook( __FILE__, array( 'Neko_Team', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Neko_Team', 'deactivate' ) );


add_action( 'plugins_loaded', array( 'Neko_Team', 'get_instance' ) );



/*----------------------------------------------------------------------------*
 * Dashboard and Administrative Functionality
 *----------------------------------------------------------------------------*/

/*
 * If you want to include Ajax within the dashboard, change the following
 * conditional to:
 *
 * if ( is_admin() ) {
 *   ...
 * }
 *
 * The code below is intended to to give the lightest footprint possible.
 */
if ( is_admin() ) { // && ( ! defined( 'DOING_AJAX' ) || ! DOING_AJAX )

	require_once( plugin_dir_path( __FILE__ ) . 'admin/class-neko-team-admin.php' );
	add_action( 'plugins_loaded', array( 'Neko_Team_Admin', 'get_instance' ) );

}
