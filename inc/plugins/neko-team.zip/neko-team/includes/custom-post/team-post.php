<?php


/**
 * Custom posts 
 *
 * @since neko-framework 1.0
 */

/* Portfolio*/

add_action( 'init', 'neko_register_cpt_team' );

function neko_register_cpt_team() {

    $labels = array( 
		'name'               => esc_html__( 'Team Members', 'neko-team' ),
		'singular_name'      => esc_html__( 'Team Member', 'neko-team' ),
		'all_items'          => esc_html__( 'Team Members', 'neko-team' ),
		'add_new'            => esc_html__( 'Add Team member', 'neko-team' ),
		'add_new_item'       => esc_html__( 'Add Team member', 'neko-team' ),
		'edit_item'          => esc_html__( 'Edit team member', 'neko-team' ),
		'new_item'           => esc_html__( 'New team member', 'neko-team' ),
		'view_item'          => esc_html__( 'View team member', 'neko-team' ),
		'search_items'       => esc_html__( 'Search team member', 'neko-team' ),
		'not_found'          => esc_html__( 'No team member found', 'neko-team' ),
		'not_found_in_trash' => esc_html__( 'No team member found in Trash', 'neko-team' ),
		'parent_item_colon'  => esc_html__( 'Parent team member:', 'neko-team' ),
		'menu_name'          => esc_html__( 'Neko Team', 'neko-team' ),
    );

    $args = array( 
        'menu_icon' => 'dashicons-groups', 
        'labels' => $labels,
        'hierarchical' => false,  
        'supports' => array( 'title', 'editor', 'thumbnail' ),
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 30,
        'show_in_nav_menus' => true,
        'publicly_queriable' => false,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'rewrite' => array('slug' => 'team-item')
    );

    register_post_type( 'neko_team', $args );
}

?>