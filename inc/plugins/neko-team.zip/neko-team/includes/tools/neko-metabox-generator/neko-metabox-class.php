<?php
require_once('engine/my-meta-box-custom-class.php');

if ( ! class_exists( 'Neko_Team_Meta_extends_Class') ){

	class Neko_Team_Meta_extends_Class extends Neko_Team_AT_Meta_Box{


		public function __contruct( $meta_box ){
			parent::__construct( $meta_box ); 
		}


	}/* END OF CLASS */

} /* End Check Class Exists */