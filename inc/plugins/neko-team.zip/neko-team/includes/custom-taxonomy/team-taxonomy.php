<?php
/**
 * Represents the view for the administration dashboard.
 *
 * This includes the header, options, and other information that should provide
 * The User Interface to the end user.
 *
 * @package   Neko_Team
 * @author    Little Neko <little@little-neko.com>
 * @license   GPL-2.0+
 * @link      http://www.little-neko.com
 * @copyright 2014 Little Neko
 */

add_action( 'init', 'neko_team_category_taxonomies' );


function neko_team_category_taxonomies() 
{
	// Add new taxonomy, make it hierarchical (like categories)
	$labels = array(
		'name'                       => esc_html__( 'Teams', 'neko-team' ),
		'menu_name'                  => esc_html__( 'Teams', 'neko-team' ),
		'name_admin_bar'             => esc_html__( 'Teams', 'neko-team' ),
		'search_items'               => esc_html__( 'Search Teams', 'neko-team' ),
		'popular_items'              => esc_html__( 'Popular Teams', 'neko-team' ),
		'all_items'                  => esc_html__( 'All Teams', 'neko-team' ),
		'edit_item'                  => esc_html__( 'Edit Team', 'neko-team' ),
		'view_item'                  => esc_html__( 'View Team', 'neko-team' ),
		'update_item'                => esc_html__( 'Update A Team', 'neko-team' ),
		'add_new_item'               => esc_html__( 'Add New A Team', 'neko-team' ),
		'new_item_name'              => esc_html__( 'New Team Name', 'neko-team' ),
		);    

	$args = array(
		'labels'              => $labels,
		'public'              => true,
		'show_ui'             => true,
		'show_admin_column'   => true,
		'show_in_nav_menus'	  => false,
		'show_tagcloud'       => false,
		'query_var'           => true,
		'hierarchical'        => false,
		'rewrite'             => array( 
			'slug' => 'team',
			'with_front'   => false,
			'hierarchical' => false,
			'ep_mask'      => EP_NONE
			)
		);
	register_taxonomy( 'neko_team_category', array( 'neko_team' ), $args );
}



add_action( 'admin_menu', 'neko_team_remove_meta_box');  
function neko_team_remove_meta_box(){  
	remove_meta_box( 'tagsdiv-neko_team_category', 'neko_team', 'side' ); 
}


add_action( 'add_meta_boxes', 'neko_team_addmeta_boxes' );


function neko_team_addmeta_boxes( ) {

	add_meta_box( 'tagsdiv-neko_team_category', 'Teams', 'team_selector', 'neko_team', 'side' );
}

function team_selector( $post, $meta_box ) {

	$taxonomy = 'neko_team_category';
	$tax      = get_taxonomy( $taxonomy );
	$name = 'tax_input[' . $taxonomy . '][]'; 

	$terms = get_terms($taxonomy,array('hide_empty' => 0)); 

	$postterms = get_the_terms( $post->ID,$taxonomy );  


	$current = array();

	if(!empty($postterms)){
		foreach ($postterms as $checkedKey => $checkedValue) {
			array_push($current, $checkedValue->slug);
		}
	}

	$popular = get_terms( $taxonomy, array( 'orderby' => 'count', 'order' => 'DESC', 'number' => 10, 'hierarchical' => false ) );


	?>

	<div id="taxonomy-<?php echo esc_attr($taxonomy); ?>" class="categorydiv">

		<!-- Display tabs-->  
		<ul id="<?php echo esc_attr($taxonomy); ?>-tabs" class="category-tabs">  
			<li class="tabs">
				<a href="#<?php echo esc_attr($taxonomy); ?>-all" tabindex="3"><?php echo $tax->labels->all_items; ?></a>
			</li>  
			<li class="hide-if-no-js">
				<a href="#<?php echo esc_attr($taxonomy); ?>-pop" tabindex="3"><?php esc_html_e( 'Most Used', 'neko-team' ); ?></a>
			</li>  
		</ul>


		<!-- Display taxonomy terms -->  
		<div id="<?php echo esc_attr($taxonomy); ?>-all" class="tabs-panel">  
			<ul id="<?php echo esc_attr($taxonomy); ?>checklist" class="list:<?php echo esc_attr($taxonomy)?> categorychecklist form-no-clear">  
				<?php   foreach($terms as $term){  
					$checked = in_array( $term->slug, $current ) ? ' checked="checked" ' : ''; 
					$id = $taxonomy.'-'.$term->term_id;  
					echo "<li id='esc_attr($id)'><label class='selectit'>";  
					echo "<input type='checkbox' id='in-esc_attr($id)' name='{$name}' ".$checked." value='$term->slug' />&nbsp;$term->name<br />";  
					echo "</label></li>";  
				}?>  
			</ul>  
		</div>  		


		<!-- Display popular taxonomy terms -->  
		<div id="<?php echo $taxonomy; ?>-pop" class="tabs-panel" style="display: none;">  
			<ul id="<?php echo $taxonomy; ?>checklist-pop" class="categorychecklist form-no-clear" >  
				<?php   foreach($popular as $term){ 
					$checked = in_array( $term->slug, $current ) ? ' checked="checked" ' : '';  
					$id = 'popular-'.$taxonomy.'-'.$term->term_id;  
					echo "<li id='esc_attr($id)'><label class='selectit'>";  
					echo "<input type='checkbox' id='in-esc_attr($id)' ".$checked." value='$term->slug' />&nbsp;$term->name<br />";  
					echo "</label></li>";  
				}?>  
			</ul>  
		</div>  
	</div>
	<?php

}

?>