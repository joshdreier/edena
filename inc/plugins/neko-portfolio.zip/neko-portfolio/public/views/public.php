<?php

	/**
	  * 
	  * neko_portfolio_hover_pics
	  * Generate the pics with its hover state (zoom & direct link)
	  * @param array $hoverThumb array containing pic url based on desired size
	  * @param boolean $activateZoom activate zoom btn  
	  * @param boolean $activateLink activate direct link btn 
	  * @param boolean $return  what this method should return 
	  * @param string $post_content  content type of the post
	  * @param string $videoType  Video url if any
	  * @param string $forceResp  responsive option to set from max-width 100% to width 100%	  
	  * @return string
	  *
	  */
	if(!function_exists('neko_portfolio_hover_pics')){


		function neko_portfolio_hover_pics( 
			$hoverThumb, 
			$activateZoom = true, 
			$activateLink = true, 
			$return = false, 
			$post_content = 'pics', 
			$videoType = '', 
			$forceResp = false, 
			$postTitle = null, 
			$enhanced_zoom = false,
			$hoverType = 'original',
			$target_link = null,
			$use_featured_img = true)

		{
			/* CONFIG */
			global $customField, $sectionWidth;

			$resp_class        = ( false === $forceResp )?'img-responsive':'neko-force-resp-portfolio';

			switch($hoverType){
				case 'romeo':
				$show_title = false;
				$show_date  = false;
				break;
				case 'zoe':
				$show_title = true;
				$show_date  = false;
				break;
				default:
				$show_title = false;
				$show_date  = false;
				break;
			}

			$cancel_hover = (false === $activateZoom && false === $activateLink)?'canceled':'';

			/* CONFIG */

			$content ='<figure class="img-hover-portfolio '.$hoverType.' '.$cancel_hover.'">';

			$alt_media = get_post_meta(get_post_thumbnail_id(), '_wp_attachment_image_alt', true);
			$alt = (!empty($alt_media))?$alt_media:$postTitle;

			$content .= '<img src="'.$hoverThumb.'" alt="'.$alt.'" class="'.esc_attr($resp_class).'">';

			$content .='<figcaption >';

			/* Show title */
			if(true == $show_title){ $content .='<h2>'.get_the_title().'</h2>'; }

			/* Show date */
			if(true == $show_date){ $content .='<p>'. get_the_date().'</p>'; }

			/* Zoom = true && link = false other than original */
			if(true === $activateZoom && false === $activateLink && 'original' !== $hoverType){
				$content .= neko_portfolio_create_zoom_link ($post_content, $activateZoom, $activateLink, $custom_class = 'full-link', $videoType, $enhanced_zoom, $postTitle, $target_link, $hoverType, $use_featured_img);
			}

			/* Zoom = false && link = true other than original */
			if(false === $activateZoom && true === $activateLink && 'original' !== $hoverType ){
				$content .= neko_portfolio_create_zoom_link ($post_content, $activateZoom, $activateLink, $custom_class = 'full-link', $videoType, $enhanced_zoom, $postTitle, $target_link, $hoverType, $use_featured_img);
			}

			/* Zoom = true && link = true other than original OR original */
			if(true === $activateZoom && true === $activateLink || 'original' === $hoverType ){
				$content .='<p class="icon-links clearfix">';
				$content .= neko_portfolio_create_zoom_link ($post_content, $activateZoom, $activateLink, $custom_class = '', $videoType, $enhanced_zoom, $postTitle, $target_link, $hoverType, $use_featured_img);
				$content .='</p>';
			}

			$content .='</figcaption>';
			$content .='</figure>';

			switch ($return) {

				case true:
				return $content;
				break;
				
				default:
				echo  $content;
				break;

			}

		}

	}

	if(!function_exists('neko_portfolio_create_zoom_link')){

		function neko_portfolio_create_zoom_link (
			$post_content, 
			$activateZoom  = false, 
			$activateLink  = false, 
			$custom_class  = '', 
			$videoType     = '',
			$enhanced_zoom = false,
			$postTitle     = '',
			$target_link   = null,
			$hoverType = 'original',
			$use_featured_img = true
		) 
		{

			global $customField, $sectionWidth;
			$largPic = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full');


			switch($hoverType){
				case 'romeo':
				$icon_link = 'neko-portfolio-icon-plus-1';
				$icon_zoom  = 'neko-portfolio-icon-search';
				break;
				case 'zoe':
				$icon_link = 'neko-portfolio-icon-plus-1';
				$icon_zoom  = 'neko-portfolio-icon-search';
				break;
				default:
				$icon_link = 'neko-portfolio-icon-link icon-rounded';
				$icon_zoom  = 'neko-portfolio-icon-search icon-rounded';
				break;
			}


			$zoom_link = '';

			if(true === $activateZoom){

				if(true === $enhanced_zoom){

					$zoom_link .= '<a href="#" class="neko-portfolio-ajax-info animated '.$custom_class.'" data-nekopid="'.esc_attr(get_the_ID()).'" data-nekosection="'.esc_attr($sectionWidth).'" title="'.esc_attr($postTitle).'"><i class="'.$icon_zoom.'"></i></a>';

				}elseif( 'pics' === $post_content ){

					$zoom_link .= '<a href="'.$largPic[0].'" class="neko-portfolio-magnific-pop-img animated '.$custom_class.'" title="'.get_the_title().'"><i class="'.$icon_zoom.'"></i></a>';


				}elseif( 'gal' === $post_content ){

					$otherImg = array();
					for ($i = 1; $i <= 5; $i++) {

						$attachment_image = Neko_Portfolio_MultiPostThumbnails::get_post_thumbnail_url(get_post_type(), 'image'.$i, null, 'full');

						if(!empty($attachment_image)){

							array_push($otherImg, $attachment_image);

						}

					}

					$otherImg  = implode(',', $otherImg);
					$zoom_link .= '<a href="'.$largPic[0].'" class="neko-portfolio-magnific-pop-gallery animated '.$custom_class.'" title="'.esc_attr($postTitle).'" data-gallery="'.$otherImg.'" data-use-thumb="'.esc_attr($use_featured_img).'"><i class="'.$icon_zoom.'"></i></a>';

				}else{

					switch ($videoType) {
						case 0:
						$url = '//www.youtube.com/watch?v='.$post_content;
						break;
						case 1:
						$url = 'http://vimeo.com/'.$post_content;
						break;
						default:
						$url = $post_content;
						break;
					}


					$zoom_link .= '<a href="'.$url.'" class="neko-portfolio-magnific-pop-video animated '.$custom_class.'" title="'.esc_attr($postTitle).'"><i class="'.$icon_zoom.'"></i></a>';

				}
			}

			if( true === $activateLink ){

				$target = (null === $target_link)?get_permalink(get_the_ID()):$target_link;
				$target_handle = (null === $target_link)?'':'target="_blank"';

				$zoom_link .= '<a href="'.esc_url($target).'" title="'.esc_attr($postTitle).'" class=" animated '.$custom_class.'" '.$target_handle.'><i class="'.$icon_link.'"></i></a>';
			}
			return $zoom_link;
		}
	}

	/**
	  * 
	  * Neko_Portfolio_Single_Prev_Next
	  * Generate the prev next bouton on single item 
	  *
	  * @param string $currentTerms list of terms linked to the current post
	  * @param int $postId id of the current post 	  
	  * @return string
	  *
	  */
	if(!function_exists('neko_Portfolio_Single_Prev_Next')){

		function neko_Portfolio_Single_Prev_Next($currentTerms, $postId, $fromajax = false ){

			/* get_posts in same custom taxonomy */
			if(true === $fromajax){

				$postlist_args = array(
					'posts_per_page'       => -1,
					'orderby'              => 'menu_order',
					'order'                => 'ASC',
					'post_type'            => 'neko_portfolio',
					'neko_portfolio_category' => $currentTerms
					);
			}else{

				$postlist_args = array(
					'posts_per_page'       => -1,
					//'orderby'              => 'menu_order',
					//'order'                => 'ASC',
					'post_type'            => 'neko_portfolio',
					'neko_portfolio_category' => $currentTerms
					);
			}




			$postlist = get_posts( $postlist_args ); 

			/* get ids of posts retrieved from get_posts */
			$ids = array();
			foreach ($postlist as $thepost) {
				$ids[] = $thepost->ID;
			}


			/* get and echo previous and next post in the same taxonomy */        
			$thisindex   = array_search($postId, $ids);
			$previd      = @$ids[$thisindex-1];
			$nextid      = @$ids[$thisindex+1];
			$class_for_ajax = (true === $fromajax)?'class="prev-next-ajax"':'';

		

			$content_nav = '<ul class="neko-portfolio-single-nav pager">';

			if(false === $fromajax)
			$return_link = get_post_meta($postId,'neko_portfolio_portfolio_returnpage',true);


			// $return_link = ( !empty( $return_link ) ) ? get_page_link( $return_link ) : get_site_url() ;
			// 
			$return_link = ( !empty($return_link) ) ? get_page_link( $return_link ) : '' ;

			if(  !empty($return_link) ){
				$content_nav .=  '<li><a href="'.esc_url($return_link).'" class="portfolio-return" title=""><i class="neko-portfolio-icon-th-thumb-empty"></i></a></li>'; 	
			}
			

			if ( !empty($previd) ) {
				$content_nav .=  '<li><a rel="prev" '.$class_for_ajax.' data-nekopid="'.$previd.'" href="' . get_permalink($previd). '" title=""><i class="neko-portfolio-icon-left-open-big"></i><span>'.esc_html__('previous', 'neko-portfolio').'</span></a></li>';
			}

			if ( !empty($nextid) ) {
				$content_nav .=  '<li><a rel="next" '.$class_for_ajax.' data-nekopid="'.$nextid.'" href="' . get_permalink($nextid). '" title=""><span>'.esc_html__('next', 'neko-portfolio').'</span><i class="neko-portfolio-icon-right-open-big"></i></a></li>';
			}

			$content_nav .=  '</ul>';

			return $content_nav;
		}
	}



	/**
	  * 
	  * Generate_Menu_Filter
	  * Generate the filter menu for ordering purposes
	  *
	  * @param string $currentTerms list of terms linked to the current post
	  * @param int $postId id of the current post 	  
	  * @return string
	  *
	  */
	if(!function_exists('neko_generate_Menu_Filter')){

		function neko_generate_Menu_Filter($terms_filter, $grid = true){


			$row =(true === $grid)?'row text-center':'text-center';
			$col =(true === $grid)?'col-md-12':'';

			$filter_menu =  '<div class="'.$row.'"> <nav class="neko-portfolio-filter '.$col.'" >';

			$count = count($terms_filter);

			if ( $count > 0 ){
				$filter_menu .= '<ul>';
				
				$filter_menu .= '<li><a href="" class="current" data-filter="*">'.esc_html__('All', 'neko-portfolio').'</a></li>';

				foreach ( $terms_filter as $term_filter ) {
					$filter_menu .= '<li><a href="" data-filter=".'.@$term_filter->slug.'" class="">' . @$term_filter->name . '</a></li>';
				}

				$filter_menu .= '</ul>';
			}

			$filter_menu .= '</nav></div>';

			return $filter_menu;
		}
		
	}

	/**
	  * 
	  * Generate_Class_Filter
	  * Generate the filter class to link the filter menu to each items
	  *
	  * @param string $currentTerms list of terms linked to the current post
	  * @param int $postId id of the current post 	  
	  * @return string
	  *
	  */
	if(!function_exists('neko_generate_Class_Filter')){
		function neko_generate_Class_Filter($term_list){

			$filter_classe = '';

			if(!empty($term_list)){
				foreach ($term_list as $value) {
					$filter_classe .= ' '.$value->slug;
				}
			}

			return $filter_classe;
		}

	}
	


	if(!empty($nekoPortfolioSingle) && true === $nekoPortfolioSingle){
		global $neko_portfolio_single_id;

		$neko_portfolio_title        = ( isset( $_GET['pt'] ) ) ? sanitize_text_field( $_GET['pt'] ) : sanitize_text_field( get_tax_meta($neko_portfolio_single_id,'neko_portfolio_portfolio_title') ) ;
		$neko_portfolio_excerpt      = ( isset( $_GET['pe'] ) ) ? sanitize_text_field( $_GET['pe'] ) : sanitize_text_field( get_tax_meta($neko_portfolio_single_id,'neko_portfolio_portfolio_excerpt') ) ;
		$neko_portfolio_hovertype    = ( isset( $_GET['ph'] ) ) ? sanitize_text_field( $_GET['ph'] ) : sanitize_text_field( get_tax_meta($neko_portfolio_single_id,'neko_portfolio_portfolio_hover_type') ) ;

		include_once('templates/single-neko_portfolio.php');

	}elseif(!empty($fromajax) && true === $fromajax){

		include_once('templates/ajax-content.php');

	}else{

		global $position_page;


		$neko_portfolio_style        = ( isset( $_GET['ps'] ) ) ? sanitize_text_field( $_GET['ps'] ) : sanitize_text_field( get_tax_meta($neko_portfolio_id,'neko_portfolio_portfolio_style') ) ;
		$neko_portfolio_layout       = ( isset( $_GET['pl'] ) ) ? sanitize_text_field( $_GET['pl'] ) : sanitize_text_field( get_tax_meta($neko_portfolio_id,'neko_portfolio_portfolio_layout') ) ;
		$neko_portfolio_hovertype    = ( isset( $_GET['ph'] ) ) ? sanitize_text_field( $_GET['ph'] ) : sanitize_text_field( get_tax_meta($neko_portfolio_id,'neko_portfolio_portfolio_hover_type') ) ;
		$neko_portfolio_title        = ( isset( $_GET['pt'] ) ) ? sanitize_text_field( $_GET['pt'] ) : sanitize_text_field( get_tax_meta($neko_portfolio_id,'neko_portfolio_portfolio_title') ) ;
		$neko_portfolio_excerpt      = ( isset( $_GET['pe'] ) ) ? sanitize_text_field( $_GET['pe'] ) : sanitize_text_field( get_tax_meta($neko_portfolio_id,'neko_portfolio_portfolio_excerpt') ) ;
		$neko_portfolio_filter       = ( isset( $_GET['pf'] ) ) ? sanitize_text_field( $_GET['pf'] ) : sanitize_text_field( get_tax_meta($neko_portfolio_id,'neko_portfolio_portfolio_filterable') ) ;
		$neko_portfolio_enhancedzoom = ( isset( $_GET['pz'] ) ) ? sanitize_text_field( $_GET['pz'] ) : sanitize_text_field( get_tax_meta($neko_portfolio_id,'neko_portfolio_portfolio_enhancedzoom') ) ;

		// echo 'layout: '.$neko_portfolio_layout.'<br>';
		// echo 'position: '.$position.'<br>';
		// echo 'excerpt: '.$neko_portfolio_excerpt.'<br>';
		// echo 'filter: '.$neko_portfolio_filter.'<br>';
		// echo 'style: '.$neko_portfolio_style.'<br>';
		// echo 'ezoom: '.$neko_portfolio_enhancedzoom.'<br>';

		if('1' === $neko_portfolio_style || '2' === $neko_portfolio_style || empty($neko_portfolio_style)){
      
			include('templates/grid.php');
		}elseif('3' === $neko_portfolio_style || '4' === $neko_portfolio_style){
			include('templates/mosaic.php');
		}
	}

