<?php
global $sectionWidth;




if(empty($sectionWidth)) $sectionWidth = 'standard';

$ms_img = ('2' === $neko_portfolio_style)?'-ms':'';

if( $neko_portfolio_layout == 6){
	
	$imgSize  = (empty($position_page) && $sectionWidth != 'standard'|| $position_page == 'no-sidebar'  && $sectionWidth != 'standard')?'img-large'.$ms_img:'img-medium'.$ms_img;
	$itemSize = 'nkpf-col-md-2';

}elseif( $neko_portfolio_layout == 4){

	$imgSize  = (empty($position_page) && $sectionWidth != 'standard' || $position_page == 'no-sidebar' && $sectionWidth != 'standard')?'img-xx-large'.$ms_img:'img-x-large'.$ms_img;
	$itemSize = 'nkpf-col-md-3';

}elseif( $neko_portfolio_layout == 3){

	$imgSize  = (empty($position_page) && $sectionWidth != 'standard' || $position_page == 'no-sidebar' && $sectionWidth != 'standard')?'img-xx-large'.$ms_img:'img-x-large'.$ms_img;
	$itemSize = 'nkpf-col-md-4';

}elseif( $neko_portfolio_layout == 2){

	$imgSize  = 'img-xx-large'.$ms_img;
	$itemSize = 'nkpf-col-md-6';

}else{

	$imgSize  = (empty($position_page) && $sectionWidth != 'standard' || $position_page == 'no-sidebar' && $sectionWidth != 'standard')?'img-xx-large'.$ms_img:'img-x-large'.$ms_img;
	$itemSize = 'nkpf-col-md-3';
}

?>

<div class="neko-portfolio neko-grid">

	<!-- Preloader --> 
	<div class="preloader-portfolio">
		<div class="status-portfolio"></div>
	</div> 
	<!-- / Preloader -->

	
	<?php 
	if(!empty($neko_portfolio_filter) && $neko_portfolio_filter == '1'){ ?>
		<!-- Menu Filter -->
		<?php 
		$terms_filter = get_terms("neko_portfolio_filters");
		echo neko_generate_Menu_Filter($terms_filter);
		?>
		<!-- / Menu Filter -->
	<?php } ?>
	

	<?php if(!empty($neko_portfolio_enhancedzoom) && $neko_portfolio_enhancedzoom == 1){ ?><div id="neko-ajax-content"></div><?php } ?>

	<div class="neko-portfolio-isotope nkpf-row" >
		
		<?php

		$args=array(
			'post_type' => $this->_custom_post_type,
      
			'tax_query' => array(

				array(
          'taxonomy' => $this->_porfolio_category,
          'terms'    => function_exists('icl_object_id')?icl_object_id($neko_portfolio_id,$this->_porfolio_category,false):$neko_portfolio_id,
          'field'    => 'term_id'
					)
				),
      'suppress_filters' => 0,
			'post_status' => 'publish',
			'posts_per_page' => -1
			);


		$loop = new WP_Query( $args );
    //echo '<pre>'; print_r($loop); echo '</pre>'; 

		while ( $loop->have_posts() ) : $loop->the_post();

		$post = get_post();

		$title = the_title('<h3>','</h3>', false);

		$term_list = wp_get_post_terms($post->ID, 'neko_portfolio_filters', array("fields" => "all"));

		$filterCLasse = '';

		if(!empty($term_list)){
			foreach ($term_list as $value) {
				$filterCLasse .= ' '.$value->slug;
			}
		}
		
		$customField = get_post_meta($post->ID);


		$activate_zoom = ($customField['neko_portfolio_portfolio_zoom'][0] == 0)?true:false;
		$activate_enhanced_zoom = ($neko_portfolio_enhancedzoom == 0)?false:true;
		$activate_link = ($customField['neko_portfolio_portfolio_link'][0] == 0)?true:false;

		switch ($customField['neko_portfolio_portfolio_type'][0]) {
			case 0:
			$post_content = 'pics';
			break;
			case 1:
			$post_content = 'gal';
			break;
			case 2:
			$post_content = @$customField['neko_portfolio_video_url'][0];
			break;
			
		}

		$videoType = @$customField['neko_portfolio_video_type'][0];


		/* Filter class */
		$term_class = '';

		if(!empty($neko_portfolio_filter) && '1' === $neko_portfolio_filter){
			$term_list = wp_get_post_terms($post->ID, 'neko_portfolio_filters', array("fields" => "all"));
			$term_class = neko_generate_Class_Filter($term_list);	
		}

		/* / Filter class */

		?>
		<div class="neko-portfolio-grid neko-portfolio-isotope-item nkpf-col-sm-6 nkpf-col-xs-12 <?php echo esc_attr($itemSize).' '.esc_attr($term_class) ?>">
		<article>
			<?php
			$hoverThumb = wp_get_attachment_image_src(get_post_thumbnail_id(),  $imgSize );
			if( !empty( $hoverThumb ) ) { 
				?>
				<header class="item-header">
					<div class="item-media">
						<?php 

						$target_link = (empty($customField['neko_portfolio_portfolio_link_to_porject'][0]) || 2 == $customField['neko_portfolio_portfolio_link_to_porject'][0] )?null:$customField['neko_portfolio_portfolio_url'][0];

						switch ($neko_portfolio_hovertype) {
							case 1:
							$hover_type = 'original';
							break;
							case 2:
							$hover_type = 'romeo';
							break;
							case 3:
							$hover_type = 'zoe';
							break;		
							default:
							$hover_type = 'original';
							break;
						}


						neko_portfolio_hover_pics( 
							$hoverThumb[0], 
							$activateZoom = $activate_zoom, 
							$activateLink = $activate_link, 
							$return = false, 
							$post_content = $post_content, 
							$videoType = $videoType, 
							$forceResp = true, 
							$postTitle = get_the_title(), 
							$enhanced_zoom = $activate_enhanced_zoom,
							$hoverType = $hover_type,
							$target_link   = $target_link,
							$use_featured_img = $customField['neko_portfolio_portfolio_thumbnail'][0]
							);

							?> 
						</div>
					</header>
					<?php } ?>

					<?php if( ( !empty($neko_portfolio_title) && $neko_portfolio_title == 1  ||  !empty($neko_portfolio_excerpt) && $neko_portfolio_excerpt == 1 ) ) { ?>
					<footer class="item-footer">

						<div class="item-content">
							<?php if( !empty($neko_portfolio_title) && $neko_portfolio_title == 1 ) the_title('<h3>','</h3>');?>

							<?php if( !empty($neko_portfolio_excerpt) && $neko_portfolio_excerpt == 1 ) { ?>

								<?php echo get_the_excerpt(); ?>

							<?php } ?>
						</div>
					</footer>
					<?php } ?>		
				</article>
				</div>
		<?php endwhile; ?>

	</div>
</div>

<?php  wp_reset_query(); wp_reset_postdata(); ?>