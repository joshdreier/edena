<?php
$media_desc_pos   = ( 2 == $meta_pos && true === $activate_both_meta_desc )? 'nkpf-col-md-push-6' : '' ;
$meta_position    = ( 2 == $meta_pos && true === $activate_both_meta_desc )? 'nkpf-col-md-pull-6' : '' ;
$description_size = ( !empty($project_meta_html) ) ? 'nkpf-col-md-6' : 'nkpf-col-md-12' ;
$meta_size        = ( !empty($project_portfolio) ) ? 'nkpf-col-md-6' : 'nkpf-col-md-12' ;
?>
<article  class="neko-portfolio-single">

	<?php if( !empty($title_header) || !empty($nav_header) ){ ?>
	<!-- header -->
	<header class="item-header clearfix neko-page-header page-header">
		<?php echo $title_header; ?>
		<?php echo $nav_header ?>
	</header>
	<!-- / header -->
	<?php } ?>

	<!-- media -->
	<?php if( !empty($media_html) ){ ?>
	<div class="item-media">
		<?php echo $media_html; ?>
	</div>
	<?php } ?>
	<!-- / media -->

	<!-- content -->
	<div class="nkpf-container">
		<?php if( true === $activate_meta_desc ) { ?>
			<div class="nkpf-row">
				<?php if( !empty($project_portfolio) ) { ?>
					<div class="<?php echo esc_attr($description_size); ?>  <?php echo esc_attr($media_desc_pos); ?>">
						<div class="item-description">
							<?php echo $project_portfolio; ?>
						</div>
					</div>
				<?php } ?>	
				<?php if( !empty($project_meta_html) ) { ?>
					<div class="<?php echo esc_attr($meta_size); ?>  <?php echo esc_attr($meta_position); ?>">
						<div class="item-meta">
							<?php echo $project_meta_html; ?>
						</div>
					</div>
				<?php } ?>
			</div>
		<?php } ?>

		<div class="nkpf-row">	
			<div class="nkpf-col-md-12">
				<div class="item-content">
					<?php echo $title_content; ?>
					<?php the_content(); ?>
					<!-- compatibility with Altea theme -->
					<?php if ( function_exists( 'neko_get_social_icons' ) ){ neko_get_social_icons() ;}?>
				</div>
			</div>
			
			<!-- / content -->

			<?php if( !empty($nav_footer) ){ ?>
			<!-- footer -->
			<footer class="item-footer nkpf-col-md-12">
				<?php echo $nav_footer ?>
			</footer>
			<!-- / footer -->
			<?php } ?>
		</div>
	</div>
</article>