<?php
$media_content_pos = ( 2 == $meta_pos && true === $activate_meta_desc )? 'nkpf-col-md-push-6' : '' ;
$meta_position     = ( 2 == $meta_pos && true === $activate_meta_desc )? 'nkpf-col-md-pull-6' : '' ;
$content_size	   = ( true === $activate_meta_desc ) ? 'nkpf-col-md-6' : 'nkpf-col-md-12' ;
?>
<article  class="neko-portfolio-single">
	<?php if( !empty($title_header) || !empty($nav_header) ){ ?>
	<!-- header -->
	<header class="item-header clearfix neko-page-header page-header">
		<?php echo $title_header; ?>
		<?php echo $nav_header ?>
	</header>
	<!-- / header -->
	<?php } ?>

	<!-- media -->
	<?php if( !empty($media_html) ){ ?>
	<div class="item-media">
		<?php echo $media_html; ?>
	</div>
	<?php } ?>
	<!-- / media -->

	<!-- content -->
	<div class="container-fw clearfix">
		<div class="row-fw">

			<div class="<?php echo esc_attr($content_size);?> <?php echo esc_attr($media_content_pos); ?>">
				<div class="item-content">
					<?php echo $title_content; ?>
					<?php the_content(); ?>
					<!-- compatibility with Altea theme -->
					<?php if ( function_exists( 'neko_get_social_icons' ) ){ neko_get_social_icons() ;}?>
				</div>
			</div>

			<?php if( true === $activate_meta_desc ) { ?>

			<div class="nkpf-col-md-6 <?php echo esc_attr($meta_position); ?>">

				<?php if( !empty($project_portfolio) ) { ?>
				<div class="item-description">
					<?php echo $project_portfolio; ?>
				</div>
				<?php } ?>

				<?php if( !empty($project_meta_html) ) { ?>
				<div class="item-meta">
					<?php echo $project_meta_html; ?>
				</div>
				<?php } ?>

			</div>

			<?php } ?>
			<!-- / content -->
		</div>
	</div>

	<?php if( !empty($nav_footer) ){ ?>
	<!-- footer -->
	<footer class="item-footer">
		<div class="nkpf-container">
			<div class="nkpf-row">
				<div class="nkpf-col-md-12 text-center">
					<?php echo $nav_footer ?>
				</div>
			</div>
		</div>
	</footer>
	<!-- / footer -->
	<?php } ?>

</article>