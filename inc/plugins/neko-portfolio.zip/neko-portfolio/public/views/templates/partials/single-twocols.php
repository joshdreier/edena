<?php
$media_content_pos = ( 2 == $meta_pos && true === $activate_meta_desc )?'nkpf-col-md-push-4':'';
$meta_position     = ( 2 == $meta_pos && true === $activate_meta_desc )?'nkpf-col-md-pull-8':'';
$content_size	   = ( true === $activate_meta_desc ) ? 'nkpf-col-md-8' : 'nkpf-col-md-12' ;
$header_class = ( empty($title_header) && empty($nav_header) ) ? ' neko-portfolio-no-header' : '' ;
?>

<article class="neko-portfolio-single<?php echo esc_attr($header_class); ?>">

	<?php if( !empty($title_header) || !empty($nav_header) ){ ?>
	<div class="nkpf-container neko-page-header">
		<div class="nkpf-row">

			<!-- header -->
			<div class="nkpf-col-md-12">
				<header class="item-header clearfix">
					<?php echo $title_header; ?>
					<?php echo $nav_header ?>

				</header>
			</div>
			<!-- / header -->

		</div>
	</div>
	<?php } ?>

	<div class="nkpf-container">
		<div class="nkpf-row">	
			<!-- content -->
			<div class="<?php echo esc_attr($content_size);?> <?php echo esc_attr($media_content_pos); ?>">
				<!-- media -->
				<?php if( !empty($media_html) ){ ?>
				<div class="item-media">
					<?php echo $media_html; ?>
				</div>
				<?php } ?>
				<!-- / media -->
				<div class="item-content">
					<?php echo $title_content; ?>
					<?php the_content(); ?>
					<!-- compatibility with Altea theme -->
					<?php if ( function_exists( 'neko_get_social_icons' ) ){ neko_get_social_icons() ;}?>
				</div>
			</div>

			<?php if( true === $activate_meta_desc ) { ?>
			<div class="nkpf-col-md-4 <?php echo esc_attr($meta_position); ?>">

				<?php if( !empty($project_portfolio) ) { ?>
				<div class="item-description">
					<?php echo $project_portfolio; ?>
				</div>
				<?php } ?>

				<?php if( !empty($project_meta_html) ) { ?>
				<div class="item-meta">
					<?php echo $project_meta_html; ?>
				</div>
				<?php } ?>

			</div>
			<?php } ?>
			<!-- / content -->

			<?php if( !empty($nav_footer) ){ ?>
			<!-- footer -->
			<footer class="item-footer nkpf-col-md-12">
				<?php echo $nav_footer ?>
			</footer>
			<!-- / footer -->
			<?php } ?>
		</div>
	</div>
</article>