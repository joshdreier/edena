<!-- / related projects -->
<?php 

$hand_picked_related = get_post_meta($post->ID,'neko_portfolio_re_marker',true);

remove_all_filters('posts_orderby');

$args = array( 
	'post_type' => 'neko_portfolio', 
	);

if( !empty($hand_picked_related) ){
	$portfolio_item_ids = array();
	foreach ($hand_picked_related as $key => $value) {
		$portfolio_item_ids[] = $value ['neko_portfolio_re_neko_portfolio_id'];
	}
	$args['post__in'] = $portfolio_item_ids;
	$args['orderby'] = 'post__in';
}else{
	$args['orderby'] = 'rand';
	$args['posts_per_page'] = 3;
	$args['neko_portfolio_category'] =$current_tax;
	$args['post__not_in'] = array($post->ID);
}

$loopRelated = new WP_Query( $args );

	//echo '<pre>'; print_r($loopRelated); echo '</pre>';

?>

<?php if($loopRelated->have_posts() && !empty($current_tax)){ ?>

	<section id="neko-related-works">
		<div class="nkpf-container">
			<div class="nkpf-row">
				<div class="nkpf-col-md-12">
					<h2><?php esc_html_e('Related works', 'neko-portfolio' ) ?></h2>
				</div> 

				<?php

				$term_list = wp_get_post_terms($post->ID, 'neko_portfolio_filters', array("fields" => "all"));

				$slugTerm = '';
				foreach ($term_list as $key => $value) {
					$slugTerm .=  ','.$value->slug;
				}
				$slugTerm = substr( $slugTerm, 1 );




				while ( $loopRelated->have_posts() ) : $loopRelated->the_post();
				$customFieldRelated = get_post_meta($post->ID);
    	        //echo '<pre>'; print_r($customFieldRelated ); echo '</pre>';
				$activateZoom = (isset($customFieldRelated['neko_portfolio_portfolio_zoom'][0]) && $customFieldRelated['neko_portfolio_portfolio_zoom'][0] == 0)?true:false;
				$activateLink = (isset($customFieldRelated['neko_portfolio_portfolio_link'][0]) &&  $customFieldRelated['neko_portfolio_portfolio_link'][0] == 0)?true:false;

				?>
				<article class="neko-portfolio-portfolio-item nkpf-col-md-4 ">

					<?php
					$hoverThumb = wp_get_attachment_image_src(get_post_thumbnail_id(), 'img-medium' );
					if( !empty( $hoverThumb ) ) { 
						?>
						<header class="item-header">
							<div class="item-media">	
								<?php
								switch ($customFieldRelated['neko_portfolio_portfolio_type'][0]) {
									case 0:
									$post_content = 'pics';
									break;
									case 1:
									$post_content = 'gal';
									break;
									case 2:
									$post_content = $customFieldRelated['neko_portfolio_video_url'][0];
									break;
								}

								$videoType = $customFieldRelated['neko_portfolio_video_type'][0];


								neko_portfolio_hover_pics( 
									$hoverThumb    = $hoverThumb[0], 
									$activateZoom  = $activateZoom, 
									$activateLink  = $activateLink, 
									$return        = false, 
									$post_content  = $post_content, 
									$videoType     = $videoType, 
									$forceResp     = true,
									$postTitle     = get_the_title(),
									$enhanced_zoom = false,
									$hoverType     = $hover_type_sg
									); 
								?>
							</div>
						</header>
						<?php } ?>
						<?php if(!empty($neko_portfolio_title) && $neko_portfolio_title == 1 || !empty($neko_portfolio_excerpt) && $neko_portfolio_excerpt == 1 ) { ?>
							<footer class="item-footer">
								<div class="item-content">
									<?php
									if(!empty($neko_portfolio_title) && $neko_portfolio_title == 1 || 'original' == $hover_type_sg ) { the_title('<h2>','</h2>'); }
									if(!empty($neko_portfolio_excerpt) && $neko_portfolio_excerpt == 1 || 'original' == $hover_type_sg ){ the_excerpt(); }
									?>
								</div>
							</footer>
							<?php } ?>

						</article>
						
					<?php endwhile; ?>
				</div>
			</div> 
		</section>

		<?php } ?>
			<!-- / related projects -->