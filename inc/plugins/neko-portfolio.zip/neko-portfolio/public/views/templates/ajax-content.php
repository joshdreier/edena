<?php
global $post;
$post = get_post($_POST['pid']);
?>

<?php if ($post) : ?>

	<?php 
	setup_postdata($post); 
	$porfolio_type = 'neko_portfolio_category';
	$portfolioCat = get_the_terms( $post->ID, $porfolio_type );

	$current_tax = '';
	if(!empty($portfolioCat)){
		foreach ($portfolioCat as $portfolioCatKey => $portfolioCatValue) {
			$current_tax .= ', '.$portfolioCatValue->slug;
		}
		$current_tax = substr( $current_tax, 1 );
	}

	$permalink = get_permalink( $post->ID, false );	

	/* customs options */
	$customField = get_post_meta($post->ID);
	$neko_portfolio_portfolio_url    = (!empty($customField['neko_portfolio_portfolio_url'][0]))?$customField['neko_portfolio_portfolio_url'][0]:'';
	$activate_link = ($customField['neko_portfolio_portfolio_link'][0] == 0)?true:false;
	/* customs options */
	?>

	<div class="neko-portfolio neko-container-size neko-portfolio-ajax">
		<article class="portfolio-content">
			<button id="neko-close-portfolio" class="portfolio-close">&#215;</button>
			<div class="nkpf-row">

				<div class="nkpf-col-md-8 nkpf-col-lg-9 portfolio-item-pic">
					<a href="<?php echo esc_url($neko_portfolio_portfolio_url); ?>" title="<?php the_title(); ?>" target="_blank">
						<?php 
						$custom_attr = array();
						if ( !has_post_thumbnail(get_the_ID()) ) {
							$custom_attr['src'] = plugins_url('neko-portfolio').'/public/assets/image/no_img.jpg';
						}
						$custom_attr['class'] = "launcher img-responsive";
						echo get_the_post_thumbnail( get_the_ID(), 'img-xx-large-ms', $custom_attr );
						?>
					</a>
				</div>

				<div class="nkpf-col-md-4 nkpf-col-lg-3 portfolio-item-data">
					<header class="item-header">
						<h2 class="item-title"><?php the_title(); ?></h2>
					</header>

			
					<div class="item-content">
						<?php the_excerpt(); ?>
					</div>

					<footer class="item-footer">

						<?php if( !empty( $neko_portfolio_portfolio_url ) ){ ?>
							<a href="<?php echo esc_url($neko_portfolio_portfolio_url) ?>" title="<?php echo esc_attr($post->post_title); ?>" class="neko-portfolio-launch btn btn-lg" target="_blank">
								<?php echo esc_html__('Launch', 'neko-portfolio'); ?>
							</a> 
						<?php } ?>

						<?php echo neko_Portfolio_Single_Prev_Next( $current_tax , $post->ID, true ); ?>
						
					</footer>
				</div>

			</div>
		</article>
	</div>
<?php endif; ?>