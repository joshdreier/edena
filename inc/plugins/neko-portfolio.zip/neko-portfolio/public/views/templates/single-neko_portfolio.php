<?php
/**
 * The Template for displaying all single posts.
 *
 * @package neko-framework
 * @since neko-framework 1.0
 */

/* Globals */
global $wp_embed, $neko_portfolio_nb_thumbs;

/* Post meta box values*/
$customField = get_post_meta($post->ID);
// print_r($customField);

/* Project type (gallery, image or video) */
$singlePageType = (!empty($customField['neko_portfolio_portfolio_type'][0]))?$customField['neko_portfolio_portfolio_type'][0]:0;

/* Layout style (fullwidth or two columns */
$layout   = $customField['neko_portfolio_portfolio_width'][0] ;
$meta_pos = (!empty($customField['neko_portfolio_portfolio_meatpos'][0])) ? $customField['neko_portfolio_portfolio_meatpos'][0]:1;


/* Project metas informations */
$neko_portfolio_portfolio_date   = (!empty($customField['neko_portfolio_portfolio_date'][0]))?$customField['neko_portfolio_portfolio_date'][0]:'';
$neko_portfolio_portfolio_client = (!empty($customField['neko_portfolio_portfolio_client'][0]))?$customField['neko_portfolio_portfolio_client'][0]:'';
$neko_portfolio_portfolio_url    = (!empty($customField['neko_portfolio_portfolio_url'][0]))?$customField['neko_portfolio_portfolio_url'][0]:'';


$project_meta_html = '';
if( !empty($neko_portfolio_portfolio_date)  || !empty($neko_portfolio_portfolio_client) || !empty($neko_portfolio_portfolio_url) ){
	$project_meta_html .= '<ul class="project-meta">';
	$project_meta_html .= ($neko_portfolio_portfolio_date != '')? '<li><span>'.esc_html__('Date', 'neko-portfolio').' : </span>'.$neko_portfolio_portfolio_date.'</li>':'';
	$project_meta_html .= ($neko_portfolio_portfolio_client != '')? '<li><span>'.esc_html__('Client', 'neko-portfolio').' : </span>'.$neko_portfolio_portfolio_client.'</li>':''; 
	$project_meta_html .= ($neko_portfolio_portfolio_url != '')? '<li><span>'.esc_html__('Project url' ,'neko-portfolio').' : </span><a href="'.esc_url($neko_portfolio_portfolio_url).'" target="_blank">'.$neko_portfolio_portfolio_url.'</a></li>':''; 
	$project_meta_html .= '</ul>';
}

/* Project short description */
$project_portfolio = (!empty($customField['neko_portfolio_project_description'][0])) ? $customField['neko_portfolio_project_description'][0] : '';


$activate_meta_desc = ( !empty($project_portfolio) || !empty($project_meta_html) ) ? true : false ;
$activate_both_meta_desc = ( !empty($project_portfolio) && !empty($project_meta_html) ) ? true : false ;

/* Image size depending on layout style */ 
$img_size = ( 0 == $layout ||  1 == $layout && false == $activate_meta_desc || 2 == $layout || 3 == $layout || 4 == $layout )?'img-xx-large-ms':'img-x-large-ms';

//get current taxonomy
$porfolio_type = 'neko_portfolio_category';
$attachment_thumb = array();
$thePostID = $wp_query->post->ID;
$portfolioCat = get_the_terms( $thePostID, $porfolio_type );
$current_tax = '';
if(!empty($portfolioCat)){
	foreach ($portfolioCat as $portfolioCatKey => $portfolioCatValue) {
		$current_tax .= ', '.$portfolioCatValue->slug;
	}
	$current_tax = substr( $current_tax, 1 );

}


/* Title position */
$title_pos =  (!empty($customField['neko_portfolio_portfolio_titlepos'][0])) ? $customField['neko_portfolio_portfolio_titlepos'][0]:2;
$title_header = ( 1 == $title_pos ) ? '<h1>'.get_the_title($thePostID).'</h1>' : '' ;
$title_content = ( 2 == $title_pos ) ? '<h1>'.get_the_title($thePostID).'</h1>' : '' ;

/* nav position */
$nav_pos =  (!empty($customField['neko_portfolio_portfolio_navpos'][0])) ? $customField['neko_portfolio_portfolio_navpos'][0]:1;
$nav_header = ( 1 == $nav_pos || 3 == $nav_pos ) ? neko_Portfolio_Single_Prev_Next( $current_tax , $post->ID) : '' ;
$nav_footer = ( 2 <= $nav_pos ) ? neko_Portfolio_Single_Prev_Next( $current_tax , $post->ID) : '' ;
$navfooter_class =  ( 2 <= $nav_pos ) ? 'neko-portfolio-nav-footer' : '' ;
/* hover type */
//$hover_type_sg = (empty($neko_portfolio_hovertype) || 1 == $neko_portfolio_hovertype )?'original':'romeo';

switch ($neko_portfolio_hovertype) {
	case 1:
		$hover_type_sg = 'original';
		break;
	case 2:
		$hover_type_sg = 'romeo';
		break;
	case 3:
		$hover_type_sg = 'zoe';
		break;		
	default:
		$hover_type_sg = 'original';
		break;
}

/* btn return to liste */
//$return_btn = '<a href="" class="portfolio-return btn btn-default"><i class="neko-portfolio-icon-th-thumb-empty"></i></a>';

/* Build media depending on project type */
$media_html ='';
switch ( $singlePageType ) {

	/* Gallery */
	case 1:
		
		$media_html .= '<div class="portfolio-owl-carousel-slideshow-thumb post-gallery nkpf-row-fluid  owl-carousel owl-theme">';
		$allImg = array();	

		if( has_post_thumbnail(get_the_ID()) && $customField['neko_portfolio_portfolio_thumbnail'][0] == 0 ) {
			$hoverThumb = wp_get_attachment_image_src(get_post_thumbnail_id(), $img_size );
			array_push($allImg, $hoverThumb[0]);
		}
		for ($i = 1; $i <= $neko_portfolio_nb_thumbs; $i++) {
			$attachment_image = Neko_Portfolio_MultiPostThumbnails::get_post_thumbnail_url(get_post_type(), 'image'.$i, null,  $img_size);
			if(!empty($attachment_image)){
				array_push($allImg, $attachment_image);
			}
		}

		foreach ($allImg as $key => $value) {

			$media_html .= '<div class="item">';
     			// neko_portfolio_hover_pics( $value, true, false, false, 'gal');

			$media_html .= 
			neko_portfolio_hover_pics( 
				$value, 
				$activateZoom = true, 
				$activateLink = false, 
				$return = true, 
				$post_content = 'gal', 
				$videoType = '', 
				$forceResp = false, 
				$postTitle = get_the_title(), 
				$enhanced_zoom = false,
				$hoverType = $hover_type_sg,
				$target_link = null,
				$use_featured_img = $customField['neko_portfolio_portfolio_thumbnail'][0]
			);
			$media_html .= '</div>';

		}
		$media_html .= '</div>';
		break;


	/* video */	
	case 2:


  	if($customField['neko_portfolio_video_type'][0] == 3){

     		if( has_post_thumbnail(get_the_ID()) && $customField['neko_portfolio_portfolio_thumbnail'][0] == 0 ) {
     			$poster = wp_get_attachment_image_src(get_post_thumbnail_id(), $img_size );
     			$poster = $poster[0];
     		}else{
     			$poster = Neko_Portfolio_MultiPostThumbnails::get_post_thumbnail_url(get_post_type(), 'image2', null,  $img_size );
     		}

     	}

     	switch ($customField['neko_portfolio_video_type'][0]) {

     		case 0:
     		$video = '[embed]http://www.youtube.com/watch?v='.$customField['neko_portfolio_video_url'][0].'[/embed]';
     		break;

     		case 1:
     		$video = '[embed]http://vimeo.com/'.$customField['neko_portfolio_video_url'][0].'[/embed]';
     		break;

     		case 3:
     		$video = '[video mp4="'.$customField['neko_portfolio_video_url'][0].'" poster="'.$poster.'"]';
     		break;
     	}	

     	if($customField['neko_portfolio_video_type'][0] == 0 || $customField['neko_portfolio_video_type'][0] == 1) {  
	     	$media_html .= '<div class="neko-portfolio-video-online entry-media">';
     	}else{ 
     		$media_html .= '<div class="neko-portfolio-video-local entry-media">'; 
     	} 

     	$media_html .= do_shortcode($wp_embed->run_shortcode($video)).'</div>';
   
		break;	


	/* Img */	
	default:

			$img_class = (0 == $layout || 2 == $layout || 3 == $layout || 4 == $layout) ? 'neko-force-resp-portfolio' : 'img-responsive' ;	

	     	if( has_post_thumbnail(get_the_ID()) && !isset($customField['neko_portfolio_portfolio_thumbnail']) || $customField['neko_portfolio_portfolio_thumbnail'][0] == 0) {

     			$media_html .= get_the_post_thumbnail( get_the_ID(), $img_size , array( 'class' => 'portfolio-thumb '.$img_class ) ); 
     		} 


     		for ($i = 1; $i <= $neko_portfolio_nb_thumbs; $i++) {		
     			if (class_exists('Neko_Portfolio_MultiPostThumbnails')) { 
     				
     				$media_html .=  Neko_Portfolio_MultiPostThumbnails::get_the_post_thumbnail(get_post_type(), 'image'.$i, null, $img_size, array( 'class' => 'portfolio-thumb '.$img_class )); 
     			}
     		}

		break;
}
/* Header */
get_header();

switch ($layout) {

	/* Two columns */
	case 1:
	$layout_class = "neko-portfolio-two-cols";
	break;


	/* Full width */	
	case 2:
	$layout_class = "neko-portfolio-fullwidth";
	break;


	/* Full width boxed content 1 */	
	case 3:
	$layout_class = "neko-portfolio-fullwidth-boxed";
	break;


	/* Full width boxed content 2 */		
	case 4:
	$layout_class = "neko-portfolio-fullwidth-boxed2";
	break;	


	/* Default */	
	default:
	$layout_class = "neko-portfolio-default";
	break;
}

?>

<main id="content" class="site-content">
	<div id="primary" class="content-area">

		<div class="neko-portfolio <?php echo esc_attr( $layout_class ); ?> <?php echo esc_attr( $navfooter_class  ); ?>">

		<?php
		/* Views options*/
		if ( have_posts() ) : while ( have_posts() ) : the_post();

		switch ($layout) {
			
			/* Two columns */
			case 1:
				include_once('partials/single-twocols.php');
				break;


			/* Full width */	
			case 2:
				include_once('partials/single-fullwidth.php');
				break;


			/* Full width boxed content 1 */	
			case 3:
				include_once('partials/single-fullwidthboxed.php');
				break;


			/* Full width boxed content 2 */		
			case 4:
				include_once('partials/single-fullwidthboxed2.php');
				break;	


			/* Default */	
			default:
				include_once('partials/single-default.php');
				break;
		}

		endwhile; endif;

		if( comments_open() ) {
			echo '<div class="container"> <div class="row"><div class="nkpf-col-md-12">';
			comments_template( '', true );
			echo '</div></div></div>';
		}

		/* related projects */
		if(!isset($customField['neko_portfolio_portfolio_relatedwork'][0]) || $customField['neko_portfolio_portfolio_relatedwork'][0] == 0){
			include_once('partials/related-works.php');
		}
		
		?>

		</div>

	</div>
</main>
<?php

/* Footer */
get_footer(); 
?>