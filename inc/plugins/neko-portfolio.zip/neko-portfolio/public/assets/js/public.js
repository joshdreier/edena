(function ($) {
	"use strict";


 	/*
    |--------------------------------------------------------------------------
    | IPAD HOVER BUG FIX
    |--------------------------------------------------------------------------
    */ 

    // if((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPod/i)) || (navigator.userAgent.match(/iPad/i))) {
    // 	$("figure.img-hover-portfolio a").unbind('click');
    // 	$("figure.img-hover-portfolio").bind('touchstart', function(){});
    // }


	/*
    |--------------------------------------------------------------------------
    | OWL CAROUSEL
    |--------------------------------------------------------------------------
    */ 

    jQuery('.portfolio-owl-carousel-slideshow').owlCarousel({
    	items:1,
    	pagination:true,
    	paginationNumbers:true,
    	transitionStyle : "fade",
    	autoHeight:true

    });



    var owlThumb = jQuery('.portfolio-owl-carousel-slideshow-thumb');
    owlThumb.owlCarousel({
    	items:1,
    	singleItem:true,
    	pagination:true,
    	transitionStyle : "fade",
    	autoHeight:true,
    	afterInit :nekoPotfolioStartThumbSys,
    	afterUpdate :nekoPotfolioStartThumbSys	
    });



    function nekoPotfolioStartThumbSys() {


    	if( jQuery(this.owl.userItems).width() >= 750 ){

    		jQuery('.portfolio-owl-carousel-slideshow-thumb.owl-theme .owl-controls').css('margin-top', 0);
    		jQuery('.portfolio-owl-carousel-slideshow-thumb.owl-theme .owl-controls .owl-pagination').css('text-align', 'left');
    		
    		var Links = jQuery('.portfolio-owl-carousel-slideshow-thumb .owl-controls .owl-page span');

    		jQuery.each(this.owl.userItems, function (i) {

    			jQuery(Links[i])
    			.addClass('portfolio-thumb-nav') 
    			.css({
    				'background': 'url(' + jQuery(this).find('img').attr('src') + ') center center no-repeat',
    				'-webkit-background-size': 'cover',
    				'-moz-background-size': 'cover',
    				'-o-background-size': 'cover',
    				'background-size': 'cover'
    			});

    		});	

    	}else{

    		jQuery('.portfolio-owl-carousel-slideshow-thumb.owl-theme .owl-controls').css('margin-top', 10);
    		jQuery('.portfolio-owl-carousel-slideshow-thumb.owl-theme .owl-controls .owl-pagination').css('text-align', 'center');

    	}


    }






 	/*
    |--------------------------------------------------------------------------
    | Fit Vidz
    |--------------------------------------------------------------------------
    */   

    jQuery('.neko-portfolio-video-online').fitVids({customSelector: "iframe[src^='https://w.soundcloud.com/'], iframe[src^='http://www.dailymotion.com/']"});




 	/*
    |--------------------------------------------------------------------------
    | Magnific popup vids & pics
    |--------------------------------------------------------------------------
    */ 

    if( jQuery("a.neko-portfolio-magnific-pop-img").length){
    	jQuery("a.neko-portfolio-magnific-pop-img").bind("click touchstart", function (e) {

    		e.preventDefault();
    		var $this =jQuery(this),
    		items = [];

    		items.push( { src: $this.attr('href')  } );
	    	jQuery.magnificPopup.open({
	    		type: 'image',
	    		fixedContentPos: false,
	    		fixedBgPos: true,
	    		preloader: true,
	    		disableOn:0,
	    		items:items,
	    		closeOnContentClick:true,
	    		image: {
	    			tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
	    			titleSrc: function(item) {
	    				return $this.attr('title');
	    			}
	    		},
	    		callbacks: {
	    			resize: function() {
	    				var img = this.content.find('img');
	    				img.css('max-height', parseFloat( jQuery(window).height() ) * 0.85);
	    			}
	    		}
	    	});
    	});
    }


    if( jQuery("a.neko-portfolio-magnific-pop-video").length){
    	jQuery("a.neko-portfolio-magnific-pop-video").bind("click touchstart", function (e) {

    		e.preventDefault();
    		var $this =jQuery(this),
    		items = [];
    		items.push( { src: $this.attr('href')  } );

	    	jQuery.magnificPopup.open({
	    		type: 'iframe',
	    		preloader: false,
	    		mainClass: 'mfp-fade',
	    		fixedContentPos: false,
	    		fixedBgPos: true,
	    		disableOn: 700,
	    		items:items,
	    		closeOnContentClick:true,
	    		patterns: {
	    			youtube: {
	    				index: 'youtube.com/', 

	    				id: 'v=', 

	    				src: '//www.youtube.com/embed/%id%?autoplay=1' 
	    			},
	    			vimeo: {
	    				index: 'vimeo.com/',
	    				id: '/',
	    				src: '//player.vimeo.com/video/%id%?autoplay=1'
	    			}
	    		}

	    	});
    	});
    }


    if( jQuery("a.neko-portfolio-magnific-pop-gallery").length){

    	jQuery("a.neko-portfolio-magnific-pop-gallery").bind("click touchstart", function (e) {

    		e.preventDefault();

    		var $this =jQuery(this),	
    		items = [];

    		if($this.data('use-thumb') == '' || $this.data('use-thumb') == 0){
    			items.push( { src: $this.attr('href')  } );
    			alert('toto');
    		}
    		
    		
    		if($this.data('gallery')){

    			var $arraySrc = $this.data('gallery').split(',');

    			$.each( $arraySrc, function( i, v ){
    				items.push( {
    					src: v 
    				});
    			});     
    		}

    		

    		jQuery.magnificPopup.open({
    			type:'image',
    			mainClass: 'mfp-fade',
    			disableOn:0,
    			items:items,
    			preloader: false,
    			fixedContentPos: false,
    			fixedBgPos: true,
    			gallery: {
    				enabled: true,
    				navigateByImgClick: true,
    				preload: [0,1]  
    			},
    			image: {
    				titleSrc: function(item) {
    					return $this.attr('title');
    				}
    			},
	    		callbacks: {
	    			resize: function() {
	    				var img = this.content.find('img');
	    				img.css('max-height', parseFloat( jQuery(window).height() ) * 0.85);
	    			}
	    		}
	    	});


    	});

		jQuery('body').on('click', '.mfp-arrow', function(event) {
			jQuery('.mfp-img').css('max-height', parseFloat( jQuery(window).height() ) * 0.85);
		});

    }

    if( jQuery("a.neko-portfolio-magnific-pop-gallery-inline").length){


    	jQuery("a.neko-portfolio-magnific-pop-gallery-inline").bind("click touchstart", function (e) {

    		e.preventDefault();
    		var $this =jQuery(this),
    		items = [];
    		items.push( { src: $this.attr('href')  } );

	    	jQuery.magnificPopup.open({
	    		type: 'image',
	    		tLoading: 'Loading image #%curr%...',
	    		mainClass: 'mfp-img-mobile',
	    		fixedContentPos: false,
	    		fixedBgPos: true,
	    		disableOn:0,
	    		items:items,
	    		gallery: {
	    			enabled: true,
	    			navigateByImgClick: true,
	    			preload: [0,1] 
	    		},
	    		image: {
	    			tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
	    			titleSrc: function(item) {
	    				return $this.attr('title');
	    			}
	    		},
	    		callbacks: {
	    			resize: function() {
	    				var img = this.content.find('img');
	    				img.css('max-height', parseFloat( jQuery(window).height() ) * 0.85);
	    			}
	    		}
	    	});
    	});

    	jQuery('body').on('click', '.mfp-arrow', function(event) {
    		jQuery('.mfp-img').css('max-height', parseFloat( jQuery(window).height() ) * 0.85);
    	});
    }




  	/*
    |--------------------------------------------------------------------------
    | Neko ajax portfolio
    |--------------------------------------------------------------------------
    */    

    if( jQuery("a.neko-portfolio-ajax-info").length){

    	jQuery("a.neko-portfolio-ajax-info").bind("click touchstart", function(event) {
    		
    		event.preventDefault();

    		var $this = jQuery(this);

    		var data = {
    			action: 'nekopfolioajaction',
    			pid:$this.data('nekopid'),
    			nekosection:$this.data('nekosection')
    		};


    		jQuery('#neko-ajax-content').animate({ opacity:0 }, 200, 'easeInOutQuad', function() {

    			jQuery.ajax({
    				type: "POST",
    				url: ajax_object.ajaxurl,
    				data :  data,
    				cache: false,
    				success: function(html) {

    					jQuery('#neko-ajax-content').html(html);
    					jQuery('.neko-portfolio').css('height', 'auto');


    					var offset = jQuery(".neko-portfolio").offset().top - (jQuery('.navbar-fixed-top').outerHeight(true) + 20);
    					jQuery('html,body').animate({ scrollTop:offset},300, function() {});
    					jQuery('.launcher').bind('load', function() {	
    						jQuery('#neko-ajax-content').animate({ opacity:1, height: jQuery('.portfolio-content').outerHeight(true)}, 300, function() {});
    					});
    				}  
    			});
    		});

    		return false;

    	});

    	jQuery(window).on('resize', function(){
    		jQuery('#neko-ajax-content').animate({opacity:0, height:0}, 300, 'easeInOutQuad', function() {
    			jQuery('#neko-ajax-content').html('');
    			jQuery('.neko-portfolio-isotope').isotope('layout');
    		});	
    	});
    }



    jQuery('#neko-ajax-content').on('click', '.prev-next-ajax', function(event) {
    	event.preventDefault();
    	/* Act on the event */
    	var $this = jQuery(this);
    	var data = {
    		action: 'nekopfolioajaction',
    		pid:$this.data('nekopid')
    	};

    	jQuery('#neko-ajax-content').animate({ opacity:0}, 1, function() {

    		jQuery.ajax({
    			type: "POST",
    			url: ajax_object.ajaxurl,
    			data :  data,
    			cache: false,
    			success: function(dataContent, textStatus, xhr) {
    				jQuery('#neko-ajax-content').html(dataContent);
    				var offset = jQuery(".neko-portfolio").offset().top - (jQuery('.navbar-fixed-top').outerHeight(true) + 20);
    				jQuery('html,body').animate({ scrollTop:offset},300, function() {});


    				jQuery('.launcher').bind('load', function() {
    					jQuery('#neko-ajax-content').animate({ opacity:1, height: jQuery('.portfolio-content').outerHeight(true)}, 300, function() {});
    				});
    			}  
    		});


    	});




    });

    jQuery('#neko-ajax-content').on('click', '#neko-close-portfolio', function(event) {
    	jQuery('#neko-ajax-content').animate({opacity:0, height:0}, 300, 'easeInOutQuad', function() {
    		jQuery('#neko-ajax-content').html('');
    		jQuery('.neko-portfolio-isotope').isotope('layout');
    	});
    });	

  	/*
    |--------------------------------------------------------------------------
    | END Neko ajax portfolio
    |--------------------------------------------------------------------------
    */  


})(jQuery);


jQuery(window).load(function(){

	/*
    |--------------------------------------------------------------------------
    | ISOTOPE USAGE FILTERING
    |--------------------------------------------------------------------------
    */ 
    if(jQuery('.neko-portfolio-isotope').length){

    	
    	var $container = jQuery('.neko-portfolio-isotope');

    	if(jQuery('.neko-portfolio-mosaic').length){
			//$container.height( $container.height() - 15 );
			//
			$container.each(function(index, el) {
				var $this = jQuery(this);

				$this.isotope({

					itemSelector: '.neko-portfolio-isotope-item',
					layoutMode: 'packery',
					percentPosition: true,
					resizesContainer: true,
					isInitLayout: false,
					packery: {
						gutter: 0
					},

				});

				$this.isotope('on', 'layoutComplete',
					function (isoInstance, laidOutItems) {
						if($this.parents('.neko-mosaic').length){
							setTimeout(function () {
							var $filter_offset = 0;
							if( $this.parents('.neko-mosaic').find('.neko-portfolio-filter').length ){
								$filter_offset = $this.parents('.neko-mosaic').find('.neko-portfolio-filter').outerHeight(true);
							}

							$this.parents('.neko-mosaic').css( 'height', ( $this.height() + $filter_offset ) - 5 );


							}, 0);							
						}
					}
				);
				$this.isotope();
				$this.isotope('layout');


		});


		}else{
			$container.each(function(index, el) {
				var $this = jQuery(this);
				
				$this.isotope({
					itemSelector: '.neko-portfolio-isotope-item',
					layoutMode: 'packery',
					percentPosition: true,
					resizesContainer: true
				});


				$this.isotope('layout');
			});		

			

		}

		
		
		jQuery('.neko-portfolio-filter a').click(function(e){
			var $this = jQuery(this);
			e.preventDefault();
			jQuery('.neko-portfolio-filter a').removeClass('current');
			$this.addClass('current');
			var selector = $this.attr('data-filter');
			var $cont = $this.parents('.neko-portfolio').find('.neko-portfolio-isotope');
			$cont.isotope({ filter: selector });
			e.preventDefault();
			return false;
		});  
	}  



    /*
    |--------------------------------------------------------------------------
    | PRELOADER
    |--------------------------------------------------------------------------
    */ 

    if(jQuery('.preloader-portfolio').length){
    	jQuery('.preloader-portfolio').css('display', 'none');
    	jQuery('.neko-portfolio-isotope').animate({ opacity: 1}, 300, 'easeInOutQuad', function() {

    		jQuery(this).css('visibility', 'visible');
    		

    		//scrollspy refresh if needed 
    		if (jQuery('[data-spy="scroll"]').length){
    			jQuery('[data-spy="scroll"]').scrollspy('refresh');
    		}

    	});
    }


    // jQuery('figure.img-hover-portfolio').hover(function() {
    	
    // }, function() {


    // });

if((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPod/i)) || (navigator.userAgent.match(/iPad/i))) {
	jQuery('figure.img-hover-portfolio a').unbind('click');
	jQuery('figure.img-hover-portfolio').bind('touchstart', function(){});
}
//END WINDOW LOAD
});