<?php
/**
 * Neko Portfolio.
 *
 * @package   Neko_Portfolio
 * @author    Little Neko <little@little-neko.com>
 * @license   GPL-2.0+
 * @link      http://www.little-neko.com
 * @copyright 2013 Thomas Bechier
 */

/**
 * Plugin class. This class should ideally be used to work with the
 * public-facing side of the WordPress site.
 *
 * If you're interested in introducing administrative or dashboard
 * functionality, then refer to `class-neko-portfolio-admin.php`
 *
 * @TODO: Rename this class to a proper name for your plugin.
 *
 * @package Neko_Portfolio
 * @author  Little Neko <little@little-neko.com>
 */
class Neko_Portfolio {

	/**
	 * Plugin version, used for cache-busting of style and script file references.
	 *
	 * @since   1.0.0
	 *
	 * @var     string
	 */
	const VERSION = '1.2.0';

	/**
	 * @TODO - Rename "neko-portfolio" to the name your your plugin
	 *
	 * Unique identifier for your plugin.
	 *
	 *
	 * The variable name is used as the text domain when internationalizing strings
	 * of text. Its value should match the Text Domain file header in the main
	 * plugin file.
	 *
	 * @since    1.0.0
	 *
	 * @var      string
	 */
	protected $plugin_slug = 'neko-portfolio';

	/**
	 * Instance of this class.
	 *
	 * @since    1.0.0
	 *
	 * @var      object
	 */
	protected static $instance = null;


	public $_custom_post_type;
	public $_porfolio_category;
	public $_porfolio_currenttax;

	/**
	 * Initialize the plugin by setting localization and loading public scripts
	 * and styles.
	 *
	 * @since     1.0.0
	 */
	private function __construct() {

		// Load plugin text domain
		add_action( 'init', array( $this, 'load_plugin_textdomain' ), 1 );
		//add_action( 'init', array( $this, 'neko_register_session' ), 1 );

		// Activate plugin when new blog is added
		add_action( 'wpmu_new_blog', array( $this, 'activate_new_site' ) );

		// Load public-facing style sheet and JavaScript.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );


		/* 
		 * Custom functionality.
		 */

		$this->_custom_post_type = 'neko_portfolio';
		$this->_porfolio_category = 'neko_portfolio_category';


		/* Filter the single_template with our custom function */
		add_filter('single_template', array( $this, 'neko_portfolio_custom_template'));

		add_action( 'after_setup_theme', array( $this, 'neko_add_featured_image_support' ), 11 );

		add_action( 'init', array( $this, 'neko_init'), 2);

		add_action('widgets_init', array($this, 'neko_recentportfolio_widgetloader'));

		add_action('wp_ajax_nopriv_nekopfolioajaction', array($this, 'neko_portfolio_ajax_action'));
		add_action('wp_ajax_nekopfolioajaction', array($this, 'neko_portfolio_ajax_action'));

		add_filter( 'the_excerpt', array( $this, 'neko_portfolio_excerpt_read_more_link'),  20 );
		add_filter( 'get_the_excerpt', array( $this, 'neko_portfolio_excerpt_read_more_link'),  20 );
		/**
		 * If visual compser is installed add portfolio to it
		 */
		
		//add_shortcode('NEKO_PORTFOLIO', array( $this, 'neko_portfolio_shortcode'));
		//
		if ( defined( 'WPB_VC_VERSION' ) ) {
			add_action( 'init', array( $this, 'neko_add_shortcode_to_vc'), 11);
		}else{
			add_shortcode('NEKO_PORTFOLIO', array( $this, 'neko_portfolio_shortcode'));
		}

	}

	/**
	 * Return the plugin slug.
	 *
	 * @since    1.0.0
	 *
	 *@return    Plugin slug variable.
	 */
	public function get_plugin_slug() {
		return $this->plugin_slug;
	}

	/**
	 * Return an instance of this class.
	 *
	 * @since     1.0.0
	 *
	 * @return    object    A single instance of this class.
	 */
	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	/**
	 * Fired when the plugin is activated.
	 *
	 * @since    1.0.0
	 *
	 * @param    boolean    $network_wide    True if WPMU superadmin uses
	 *                                       "Network Activate" action, false if
	 *                                       WPMU is disabled or plugin is
	 *                                       activated on an individual blog.
	 */
	public static function activate( $network_wide ) {

		if ( function_exists( 'is_multisite' ) && is_multisite() ) {

			if ( $network_wide  ) {

				// Get all blog ids
				$blog_ids = self::get_blog_ids();

				foreach ( $blog_ids as $blog_id ) {

					switch_to_blog( $blog_id );
					self::single_activate();
				}

				restore_current_blog();

			} else {
				self::single_activate();
			}

		} else {
			self::single_activate();
		}

	}

	/**
	 * Fired when the plugin is deactivated.
	 *
	 * @since    1.0.0
	 *
	 * @param    boolean    $network_wide    True if WPMU superadmin uses
	 *                                       "Network Deactivate" action, false if
	 *                                       WPMU is disabled or plugin is
	 *                                       deactivated on an individual blog.
	 */
	public static function deactivate( $network_wide ) {

		if ( function_exists( 'is_multisite' ) && is_multisite() ) {

			if ( $network_wide ) {

				// Get all blog ids
				$blog_ids = self::get_blog_ids();

				foreach ( $blog_ids as $blog_id ) {

					switch_to_blog( $blog_id );
					self::single_deactivate();

				}

				restore_current_blog();

			} else {
				self::single_deactivate();
			}

		} else {
			self::single_deactivate();
		}

	}

	/**
	 * Fired when a new site is activated with a WPMU environment.
	 *
	 * @since    1.0.0
	 *
	 * @param    int    $blog_id    ID of the new blog.
	 */
	public function activate_new_site( $blog_id ) {

		if ( 1 !== did_action( 'wpmu_new_blog' ) ) {
			return;
		}

		switch_to_blog( $blog_id );
		self::single_activate();
		restore_current_blog();

	}

	/**
	 * Get all blog ids of blogs in the current network that are:
	 * - not archived
	 * - not spam
	 * - not deleted
	 *
	 * @since    1.0.0
	 *
	 * @return   array|false    The blog ids, false if no matches.
	 */
	private static function get_blog_ids() {

		global $wpdb;

		// get an array of blog ids
		$sql = "SELECT blog_id FROM $wpdb->blogs
			WHERE archived = '0' AND spam = '0'
			AND deleted = '0'";

		return $wpdb->get_col( $sql );

	}



	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		$domain = $this->plugin_slug;
		$locale = apply_filters( 'plugin_locale', get_locale(), $domain );
		load_plugin_textdomain( $domain, false, dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/' );

	}


	/**
	 * Register and enqueue public-facing style sheet.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		// Bootstrap
		//wp_enqueue_style( 'bootstrap-portfolio', plugins_url( 'assets/css/plugins/bootstrap/bootstrap.min.css', __FILE__ ), array(), self::VERSION );

		// Owl Carousel compatibility with theme not included twice
		// wp_enqueue_style( 'owl-carousel-style', plugins_url( 'assets/css/plugins/owl-carousel/owl.carousel.css', __FILE__ ), array(), self::VERSION );
		// wp_enqueue_style( 'owl-carousel-theme', plugins_url( 'assets/css/plugins/owl-carousel/owl.theme.css', __FILE__ ), array(), self::VERSION );
		// wp_enqueue_style( 'owl-carousel-transition', plugins_url( 'assets/css/plugins/owl-carousel/owl.transitions.css', __FILE__ ), array(), self::VERSION );
		
		// Magnific popup
		// wp_enqueue_style( 'magnific-popup', plugins_url( 'assets/css/plugins/magnific-popup/magnific-popup.css', __FILE__), array(), self::VERSION );

		// Animation css
		// wp_enqueue_style( 'animation-css', plugins_url( 'assets/css/plugins/animation-framework/animate.min.css', __FILE__), array(), self::VERSION );



		// plugins css
		wp_enqueue_style( 'neko-portfolio-plugins', plugins_url( 'assets/css/plugins/allplugins.min.css', __FILE__ ), array(), self::VERSION );

		// custom font
		wp_enqueue_style( 'custom-icon-portfolio', plugins_url( 'assets/font-icons/css/neko-portfolio-icons.css', __FILE__ ), array(), self::VERSION );

		// Public css
		wp_enqueue_style( $this->plugin_slug . '-plugin-styles', plugins_url( 'assets/css/public.css', __FILE__ ), array(), self::VERSION );

	}


	/**
	 * Register and enqueues public-facing JavaScript files.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		//Modernizr
    	wp_enqueue_script( 'modernizr', plugins_url( 'assets/js/plugins/modernizr/modernizr-2.6.1.min.js'), null, '2.6.1', false );

		//Bootstrap js
    	//wp_enqueue_script( 'bootstrap', plugins_url( 'assets/js/plugins/bootstrap/bootstrap.min.js'), null, '3.0.1', false );

		//Isotope
		wp_enqueue_script( 'isotope', plugins_url( 'assets/js/plugins/isotope/isotope.pkgd.min.js', __FILE__ ), array( 'jquery' ), self::VERSION, true );
		wp_enqueue_script( 'isotope_packery', plugins_url( 'assets/js/plugins/isotope/packery-mode.pkgd.min.js', __FILE__ ), array( 'jquery' ), self::VERSION, true );
		

		//Owl Carousel compatibility with theme not included twice
		wp_enqueue_script( 'owl-carousel', plugins_url( 'assets/js/plugins/owl-carousel/owl.carousel.min-MODIFIED.js', __FILE__ ), array( 'jquery' ), self::VERSION, true );

		//Easing
    	wp_enqueue_script( 'easing', plugins_url( 'assets/js/plugins/easing/jquery.easing.1.3.js', __FILE__ ), array( 'jquery' ), '1.3', true );

    	//Magnific popup
		wp_enqueue_script( 'magnific-popup', plugins_url( 'assets/js/plugins/magnific-popup/jquery.magnific-popup.min.MODIFIED.js', __FILE__ ), array( 'jquery' ), self::VERSION, true );
		
		//FitVids	
		wp_enqueue_script( 'fitvids', plugins_url( 'assets/js/plugins/fitvids/jquery.fitvids.js', __FILE__), array( 'jquery' ), '3.2.7', true );

		//Public js
		wp_enqueue_script( $this->plugin_slug . '-plugin-script', plugins_url( 'assets/js/public.js', __FILE__ ), array( 'jquery' ), self::VERSION, true );
		
		wp_localize_script( $this->plugin_slug . '-plugin-script',  'ajax_object',
			array( 
				'ajaxurl' => admin_url( 'admin-ajax.php' )
			)
		);


	}


	/**
	 * Shortcode Activation
	 * @since    1.0.0
	 */
    public function neko_portfolio_shortcode( $atts, $content = null ) {

    	if ( defined( 'WPB_VC_VERSION' ) ) {
	    	$atts = vc_map_get_attributes( 'NEKO_PORTFOLIO', $atts );
	    	extract($atts);
	    }else{
	    	extract(
	    		shortcode_atts(
	    			array(
	    				'slug' => '',
	    				), $atts
	    			)
	    		);
	    }


   		
    	$terms = get_term_by('slug', $slug, 'neko_portfolio_category');
    	//print_r($terms);
		$neko_portfolio_id         = $terms->term_id;


    	ob_start();	
    	include(plugin_dir_path( __FILE__ ) . 'views/public.php');
    	$content = ob_get_clean();
    	
    	return $content;
	}


	public function neko_portfolio_custom_template($single) {

		global $wp_query, $post, $nekoPortfolioSingle, $neko_portfolio_single_id;
		$nekoPortfolioSingle = true;

		/* Checks for single template by post type */

		if ($post->post_type == "neko_portfolio"){
			if(file_exists(plugin_dir_path( __FILE__ ) . 'views/public.php')){
				$terms = get_the_terms($post->ID, 'neko_portfolio_category');
				$terms = array_values( $terms );
				//echo '<pre>'; print_r($terms); echo '</pre>'; exit();
				$neko_portfolio_single_id = $terms[0]->term_id;

				return plugin_dir_path( __FILE__ ) . 'views/public.php';
			}
		}

		return $single;
	}

	/**
	 * Fired for each blog when the plugin is activated.
	 *
	 * @since    1.0.0
	 */
	private static function single_activate() {
		// @TODO: Define activation functionality here
	}

	/**
	 * Fired for each blog when the plugin is deactivated.
	 *
	 * @since    1.0.0
	 */
	private static function single_deactivate() {
		// @TODO: Define deactivation functionality here
	}

	/**
	 * Add thumbnail support.
	 *
	 * @since    1.0.0
	 */
	public function neko_add_featured_image_support()
	{
	    $supported_types = get_theme_support( 'post-thumbnails' );

	    if( $supported_types === false )
	        add_theme_support( 'post-thumbnails', array( 'wp_owl_carousel' ) );               
	    elseif( is_array( $supported_types ) )
	    {
	        $supported_types[0][] = 'wp_owl_carousel';
	        add_theme_support( 'post-thumbnails', $supported_types[0] );
	    }
	}


	/**
	 * After theme setup hook
	 * Add all actions that needs to be executed within the after theme setup hook
	 * @since    1.0.0
	 */
	
	public function neko_init(){
		//$nb_thumb = self::$nb_thumb;
		require_once( plugin_dir_path( dirname(__FILE__) ) . 'includes/tools/multiple_thumbs/multi-post-thumbnails.php' );
		require_once( plugin_dir_path( dirname(__FILE__) ) . 'includes/tools/neko-metabox-generator/engine/my-meta-box-custom-class.php' );
		require_once( plugin_dir_path( dirname(__FILE__) ) . 'includes/tools/neko-metabox-tax-generator/neko-meta-box-class.php' );
		require_once( plugin_dir_path( dirname(__FILE__)  ) . 'includes/custom-post/portfolio-post.php' );
		require_once( plugin_dir_path( dirname(__FILE__) ) . 'includes/custom-taxonomy/portfolio-taxonomy.php' );
	}



	public function neko_recentportfolio_widgetloader()
	{
		require_once( plugin_dir_path( dirname(__FILE__)  ) . 'includes/widgets/Neko_Recent_Portfolio.php' );
		register_widget('recent_portfolio');
	}


	public function neko_portfolio_ajax_action() {
		if (defined('DOING_AJAX') && DOING_AJAX ){
			
			global $fromajax;
			$fromajax = true;
			require_once (plugin_dir_path( dirname(__FILE__)  ) . 'public/views/public.php' );
			die();
		}
	}

	/**
	 * Get team category
	 */
	public function neko_add_shortcode_to_vc() {

		$output = array(); 
		$terms = get_terms('neko_portfolio_category', array('hide_empty' => 1) );
		//echo '<pre>'; print_r($terms); echo '</pre>';
		$count = count($terms);

		if ( $count > 0 ){
			foreach ( $terms as $term ){
				$output[$term->name] = $term->slug;
			}
		}

		vc_map( 
			array(
				"name" => esc_html__( "Neko portfolio", "neko-portfolio" ),
				"base" => "NEKO_PORTFOLIO",
				"class" => "",
				"category" => esc_html__( "Neko shortcodes", "neko-portfolio"),
				"icon" => plugins_url( '/assets/image/icon-neko-portfolio.png', __FILE__ ),
				"params" => array(

				/**
				 * TITLE
				 */		    	
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => esc_html__( "Select your portfolio", "neko-portfolio" ),
					"param_name" => "slug",
					"value" => $output,
					"description" => esc_html__( "Select the portfolio you wan to show here", "neko-portfolio" ),
					'admin_label' => true
					)

				)
				)
			);

		add_shortcode('NEKO_PORTFOLIO', array( $this, 'neko_portfolio_shortcode'));

	}


	public function neko_portfolio_excerpt_read_more_link( $excerpt ) {
		
		global $post;
		
		if( 'neko_portfolio' === $post->post_type){

			$customField = get_post_meta($post->ID);
			$activate_link = ( $customField['neko_portfolio_portfolio_link'][0] == 0 )? true : false ;

			preg_match( '/<a[^>]* class="more-link btn-lg btn" [^>]*>[^<]*<\/a>/i',  $excerpt, $more_link_status );
			//echo '<pre>'; print_r( $more_link_status ); echo '</pre>'; 

			if( !empty($more_link_status[0]) && empty($activate_link) ){
				$excerpt =  str_replace( $more_link_status[0], '', $excerpt );
			}elseif ( empty($more_link_status[0]) && !empty($activate_link) ){
				$excerpt =  $excerpt. ' <div><a href="' . get_permalink( $post->ID ) . '" class="more-link btn-lg btn" >'.esc_html__('Read More', 'neko-portfolio').'</a></div>';
			}else{
				$excerpt =  $excerpt;
			}

		}

		return $excerpt;
	}

	// public function neko_register_session(){
	// 	if( !session_id() )
	// 		session_start();
	// }



//END OF CLASS
}
