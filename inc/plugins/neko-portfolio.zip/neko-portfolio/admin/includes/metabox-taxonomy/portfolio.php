<?php

if (is_admin()){

    /* 
   * prefix of meta keys, optional
   * use underscore (_) at the beginning to make keys hidden, for example $prefix = '_ba_';
   *  you also can make prefix empty to disable it
   * 
   */
    $prefix = 'neko_portfolio_';
    $pluginUri = plugins_url();
  /* 
   * configure your meta box
   */
  $config = array(
  	
    'id'             => 'portfolio_meta_box',      				// meta box id, unique per meta box
    'title'          => 'Portfolio settings',      				// meta box title
    'pages'          => array('neko_portfolio_category'),       // post types, accept custom post types as well, default is array('post'); optional
    'context'        => 'normal',                       		// where the meta box appear: normal (default), advanced, side; optional
    'priority'       => 'high',                         		// order of meta box: high (default), low; optional
    'fields'         => array(),                        		// list of meta fields (can be added by field arrays)
    'local_images'   => false,                          		// Use local or hosted images (meta box images for add/remove)
    'use_with_theme' => $pluginUri . '/neko-portfolio/includes/tools/neko-metabox-tax-generator/engine' //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
    );
  


  /*
   * Trad Vars
   */

	$on  = __('On','neko-portfolio');
	$off = __('Off','neko-portfolio');
  
  /*
   * Initiate your meta box
   */
  $my_meta =  new Neko_Portfolio_Tax_Meta_extends_Class($config);
  
  /*
   * Add fields to your meta box
   */

  //Portfolio style
  $title_portfolio_style = __('Portfolio style', 'neko-portfolio');
  $desc_portfolio_style = __('Set the style of portfolio you want to display', 'neko-portfolio');
  $my_meta->addSelect($prefix.'portfolio_style',array('1'=>__('grid', 'neko-portfolio'),'2'=>__('grid-masonery', 'neko-portfolio'),'3'=>__('mosaic', 'neko-portfolio'),'4'=>__('mosaic-masonery', 'neko-portfolio')),array('name'=> $title_portfolio_style, 'std'=> array('1'), 'desc' => $desc_portfolio_style, 'class' => 'no-fancy'));

  //Portfolio layout
  $title_portfolio_layout = __('Portfolio layout', 'neko-portfolio');
  $desc_portfolio_layout = __('Set the number of columns you want to display your portfolio ', 'neko-portfolio');
  $my_meta->addSelect($prefix.'portfolio_layout',array('2'=>__('2 columns', 'neko-portfolio'),'3'=>__('3 columns', 'neko-portfolio') ,'4'=>__('4 columns', 'neko-portfolio'),'6'=>__('6 columns', 'neko-portfolio')),array('name'=> $title_portfolio_layout, 'std'=> array('2'), 'desc' => $desc_portfolio_layout, 'class' => 'no-fancy'));


  //Portfolio Hover Type
  $title_portfolio_hover_type = __('Portfolio Rollover style', 'neko-portfolio');
  $desc_portfolio_hover_type = __('Set the rollover effect you want for your portfolio grids ', 'neko-portfolio');
  $my_meta->addSelect($prefix.'portfolio_hover_type',array('1'=>__('Classic', 'neko-portfolio'),'2'=>__('Smooth', 'neko-portfolio'),'3'=>__('modern', 'neko-portfolio') ),array('name'=> $title_portfolio_hover_type, 'std'=> array('1'), 'desc' => $desc_portfolio_hover_type));

  //Portfolio title
  $title_portfolio_title = __('Show title', 'neko-portfolio');
  $desc_portfolio_title = __('Wether or not you want the title to show under the thumbnail in the grid or masonery view of your portfolio', 'neko-portfolio');
  $my_meta->addRadio($prefix.'portfolio_title',array('0'=>$off,'1'=>$on),array('name'=> $title_portfolio_title.'', 'desc' => $desc_portfolio_title, 'std'=> array('0')));


  //Portfolio excerpt
  $title_portfolio_excerpt = __('Show excerpt', 'neko-portfolio');
  $desc_portfolio_excerpt = __('Wether or not you want the excerpt to show under the thumbnail in the grid or masonery view of your portfolio', 'neko-portfolio');
  $my_meta->addRadio($prefix.'portfolio_excerpt',array('0'=>$off,'1'=>$on),array('name'=> $title_portfolio_excerpt.'', 'desc' => $desc_portfolio_excerpt, 'std'=> array('0')));


  //Portfolio filterable
  $title_portfolio_filterable = __('Activate filterable portfolio', 'neko-portfolio');
  $desc_portfolio_filterable = __('Activate filters for your portfolio based on the filter taxonomy', 'neko-portfolio');
  $my_meta->addRadio($prefix.'portfolio_filterable',array('0'=>$off,'1'=>$on),array('name'=> $title_portfolio_filterable.'', 'desc' => $desc_portfolio_filterable, 'std'=> array('0')));

  //Portfolio enhanced zoom
  $title_portfolio_enhancedzoom = __('Activate enhanced zoom (Deprecated !)', 'neko-portfolio');
  $desc_portfolio_enhancedzoom = __('Activates an enhanced version of the zoom button', 'neko-portfolio');
  $my_meta->addRadio($prefix.'portfolio_enhancedzoom',array('0'=>$off,'1'=>$on),array('name'=> $title_portfolio_enhancedzoom.'', 'desc' => $desc_portfolio_enhancedzoom, 'std'=> array('0')));


  if(!empty($_GET['tag_ID'])){
	  $title_portfolio_shortcode = __('Portfolio shortcode', 'neko-portfolio');
	  $my_meta->addShortcodeTxt('shortcode_field_id',array('taxonomy'=> 'neko_portfolio_category', 'shortcodename' => 'NEKO_PORTFOLIO', 'class' => 'nekoInfoParag'));
  }

  //Finish Meta Box Declaration 
  $my_meta->Finish();
}