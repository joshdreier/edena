<?php

if (is_admin()){

  /**
   * prefix of meta keys, optional
   * use underscore (_) at the beginning to make keys hidden, for example $prefix = '_ba_';
   *  you also can make prefix empty to disable it
   * 
   */
  $prefix = 'neko_portfolio_';
  $pluginUri = plugins_url();


  /**
   * Trad Vars
   */

  $on      = esc_html__('On','neko-portfolio');
  $off     = esc_html__('Off','neko-portfolio');
  $header  = esc_html__('Header','neko-portfolio');
  $footer  = esc_html__('Footer','neko-portfolio');
  $content = esc_html__('Content','neko-portfolio');
  $both    = esc_html__('Both','neko-portfolio');
  $none    = esc_html__('None','neko-portfolio');
/**
   * Short Description metabox
   */
$config_description = array(
    'id'             => 'portfolio_description_metabox',      // meta box id, unique per meta box
    'title'          => 'Short description',      // meta box title
    'pages'          => array('neko_portfolio'),        // post types, accept custom post types as well, default is array('post'); optional
    'context'        => 'normal',                       // where the meta box appear: normal (default), advanced, side; optional
    'priority'       => 'high',                         // order of meta box: high (default), low; optional
    'fields'         => array(),                        // list of meta fields (can be added by field arrays)
    'local_images'   => false,                          // Use local or hosted images (meta box images for add/remove)                      
    'use_with_theme' => $pluginUri . '/neko-portfolio/includes/tools/neko-metabox-generator/engine' //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
    );


  /**
   * Initiate your meta box
   */
  $my_meta_description =  new Neko_Portfolio_AT_Meta_Box($config_description);
//project description
  $title_project_description  =  ''; 
  $desc_project_description = esc_html__('Add a short description of your project', 'neko-portfolio');
  $my_meta_description->addWysiwyg($prefix.'project_description',array('name'=> $title_project_description.' ', 'desc' => $desc_project_description));



  //Finish Meta Box Declaration 
  $my_meta_description->Finish();





/**
   * meta portfolio metabox
   */
$config_meta = array(
    'id'             => 'portfolio_meta_metabox',      // meta box id, unique per meta box
    'title'          => 'Portfolio meta data settings',      // meta box title
    'pages'          => array('neko_portfolio'),        // post types, accept custom post types as well, default is array('post'); optional
    'context'        => 'normal',                       // where the meta box appear: normal (default), advanced, side; optional
    'priority'       => 'high',                         // order of meta box: high (default), low; optional
    'fields'         => array(),                        // list of meta fields (can be added by field arrays)
    'local_images'   => false,                          // Use local or hosted images (meta box images for add/remove)                      
    'use_with_theme' => $pluginUri . '/neko-portfolio/includes/tools/neko-metabox-generator/engine' //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
    );


  /**
   * Initiate your meta box
   */
  $my_meta_2 =  new Neko_Portfolio_AT_Meta_Box($config_meta);



  //link to project
  $title_portfolio_link_to_project = esc_html__('Link to project', 'neko-portfolio');
  $desc_portfolio_to_project = esc_html__('If set on "On" the link will point to the project url instead of the single wordpress page', 'neko-portfolio');
  $my_meta_2->addRadio($prefix.'portfolio_link_to_porject',array('1'=>$on,'2'=>$off),array('name'=>  $title_portfolio_link_to_project.' ', 'std'=> array('2'), 'desc' => $desc_portfolio_to_project));

  //Portfolio date
  $wpDateFormat = str_replace(array('Y', 'F', 'j'), array('yy', 'MM', 'd' ), get_option('date_format'));
  $title_portfolio_date = esc_html__('Project date', 'neko-portfolio');
  $desc_portfolio_date = esc_html__('The date of the project if any', 'neko-portfolio');
  $my_meta_2->addDate($prefix.'portfolio_date',array('name'=> $title_portfolio_date.' ', 'desc' => $desc_portfolio_date,'format' => $wpDateFormat));

  //Portfolio url
  $title_portfolio_url = esc_html__('Project url ', 'neko-portfolio');
  $desc_portfolio_url = esc_html__('The url of the project if any', 'neko-portfolio');
  $my_meta_2->addText($prefix.'portfolio_url',array('name'=> $title_portfolio_url.' ', 'desc' => $desc_portfolio_url));

  //Portfolio client
  $title_portfolio_client = esc_html__('Project client', 'neko-portfolio');
  $desc_portfolio_client = esc_html__('The client of the project if any', 'neko-portfolio');
  $my_meta_2->addText($prefix.'portfolio_client',array('name'=> $title_portfolio_client.' ', 'desc' => $desc_portfolio_client));

   //meta position
  $title_portfolio_metapos = esc_html__('Project meta position', 'neko-portfolio');
  $desc_portfolio_metapos = esc_html__('put project meta left or right depneding on your needs', 'neko-portfolio');
  $my_meta_2->addRadio($prefix.'portfolio_meatpos',array('1'=>esc_html__('right', 'neko-portfolio'),'2'=>esc_html__('left', 'neko-portfolio')),array('name'=> $title_portfolio_metapos.' ','std'=> array('1'), 'desc' => $desc_portfolio_metapos));

  //Finish Meta Box Declaration 
  $my_meta_2->Finish();





  






   /**
   * Thumbnail metabox
   */
   $config_thumbnail = array(
    'id'             => 'portfolio_thumbnail_metabox',      // meta box id, unique per meta box
    'title'          => 'Thumbnail',      // meta box title
    'pages'          => array('neko_portfolio'),        // post types, accept custom post types as well, default is array('post'); optional
    'context'        => 'normal',                       // where the meta box appear: normal (default), advanced, side; optional
    'priority'       => 'high',                         // order of meta box: high (default), low; optional
    'fields'         => array(),                        // list of meta fields (can be added by field arrays)
    'local_images'   => false,                          // Use local or hosted images (meta box images for add/remove)                      
    'use_with_theme' => $pluginUri . '/neko-portfolio/includes/tools/neko-metabox-generator/engine' //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
    );


  /**
   * Initiate your meta box
   */
  $my_meta_thumbnail =  new Neko_Portfolio_AT_Meta_Box($config_thumbnail);

//Vignette
  $title_portfolio_thumb = esc_html__('Thumbnail', 'neko-portfolio');
  $desc_portfolio_thumb = esc_html__('Whether to use the first featured image (thumbnail) in the project single page or not', 'neko-portfolio');
  $my_meta_thumbnail->addRadio($prefix.'portfolio_thumbnail',array('0'=>esc_html__('Use', 'neko-portfolio'),'1'=>esc_html__('Do not use', 'neko-portfolio')),array('name'=> $title_portfolio_thumb.' ', 'std'=> array('0'), 'desc' => $desc_portfolio_thumb));

  //link
  $title_portfolio_link = esc_html__('Activate link', 'neko-portfolio');
  $desc_portfolio_link = esc_html__('show the link button', 'neko-portfolio');
  $my_meta_thumbnail->addRadio($prefix.'portfolio_link',array('0'=>$on,'1'=>$off),array('name'=>  $title_portfolio_link.' ', 'std'=> array('0'), 'desc' => $desc_portfolio_link));


  //zoom
  $title_portfolio_zoom = esc_html__('Activate zoom', 'neko-portfolio');
  $desc_portfolio_zoom = esc_html__('show the zoom button', 'neko-portfolio');
  $my_meta_thumbnail->addRadio($prefix.'portfolio_zoom',array('0'=>$on,'1'=>$off),array('name'=>  $title_portfolio_zoom.' ', 'std'=> array('0'), 'desc' => $desc_portfolio_zoom));


  //Finish Meta Box Declaration 
  $my_meta_thumbnail->Finish();









  /**
   * * Item view metabox
   */
  $config = array(
    'id'             => 'portfolio_item_meta_box',      // meta box id, unique per meta box
    'title'          => 'Display options',      // meta box title
    'pages'          => array('neko_portfolio'),        // post types, accept custom post types as well, default is array('post'); optional
    'context'        => 'normal',                       // where the meta box appear: normal (default), advanced, side; optional
    'priority'       => 'high',                         // order of meta box: high (default), low; optional
    'fields'         => array(),                        // list of meta fields (can be added by field arrays)
    'local_images'   => false,                          // Use local or hosted images (meta box images for add/remove)                      
    'use_with_theme' => $pluginUri . '/neko-portfolio/includes/tools/neko-metabox-generator/engine' //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
    );


  /**
   * Initiate your meta box
   */
  $my_meta =  new Neko_Portfolio_AT_Meta_Box($config);


  

  //Portfolio format
  $title_portfolio_type = esc_html__('Portfolio item Format', 'neko-portfolio');
  $desc_portfolio_type = esc_html__('The main type for the single page to show a video, an image or a complete gallery', 'neko-portfolio');
  $my_meta->addRadio($prefix.'portfolio_type',array('0'=>esc_html__('Image', 'neko-portfolio'),'1'=>esc_html__('Gallery', 'neko-portfolio'),'2'=>esc_html__('Video', 'neko-portfolio')),array('name'=> $title_portfolio_type.' ', 'std'=> array('0'), 'desc' => $desc_portfolio_type));


  //Layout
  $title_portfolio_layout = esc_html__('Layout', 'neko-portfolio');
  $desc_portfolio_layout = esc_html__('Choose the layout that fits your need', 'neko-portfolio');
  $my_meta->addSelect(
  	$prefix.'portfolio_width',
  	array(
  		'0'=>esc_html__('Default', 'neko-portfolio'),
  		'1'=>esc_html__('Two columns', 'neko-portfolio'),
  		'2'=>esc_html__('Full width', 'neko-portfolio'),
  		'3'=>esc_html__('Full width boxed content 1', 'neko-portfolio'),
  		'4'=>esc_html__('Full width boxed content 2', 'neko-portfolio')
  		),
  	array(
  		'name'=> $title_portfolio_layout.' ', 
  		'std'=> array('1'), 
  		'desc' => $desc_portfolio_layout,
  		'class' => 'no-fancy'
  		)
  	);

  
  //Title position
  $title_portfolio_titlepos = esc_html__('Display title', 'neko-portfolio');
  $desc_portfolio_titlepos = esc_html__('place the title of the project where you need it', 'neko-portfolio');
  $my_meta->addRadio(
  	$prefix.'portfolio_titlepos',
  	array(
  		1 => $header,
  		2 => $content,
  		3 => $none   
  		),
  	array(
  		'name'=>  $title_portfolio_titlepos.' ', 
  		'std'=> array(2), 
  		'desc' => $desc_portfolio_titlepos)
  	);

  //navigation position
  $title_portfolio_navpos = esc_html__('Display navigation', 'neko-portfolio');
  $desc_portfolio_navpos = esc_html__('splace the navigation where you need it', 'neko-portfolio');
  $my_meta->addRadio(
  	$prefix.'portfolio_navpos',
  	array(
  		1 => $header,
  		2 => $footer,
  		3 => $both  
  		),
  	array(
  		'name'=>  $title_portfolio_navpos.' ', 
  		'std'=> array(1), 
  		'desc' => $desc_portfolio_navpos)
  	);

  
  // return page option
  $title_portfolio_returnpage = esc_html__('Return page', 'neko-portfolio');
  $desc_portfolio_returnpage  = esc_html__('Select the page you want the single portfolio porject to go to when clicking on the return button', 'neko-portfolio');
  $my_meta->addPosts($prefix.'portfolio_returnpage',array('post_type' => 'page', 'args' => array('orderby' => 'ID', 'order'   => 'ASC')), array('name'=>  $title_portfolio_returnpage, 'desc' => $desc_portfolio_returnpage ));


 //related work
  $title_portfolio_relatedwork = esc_html__('Related work', 'neko-portfolio');
  $desc_portfolio_relatedwork = esc_html__('Activate related post row if hand picked portfolio items is empty the system will provide a selection of related portfolio items automatically.', 'neko-portfolio');
  $my_meta->addRadio($prefix.'portfolio_relatedwork',array('0'=>$on,'1'=>$off),array('name'=>  $title_portfolio_relatedwork.' ', 'std'=> array('0'), 'desc' => $desc_portfolio_relatedwork));


	//Hand picked related posts
  $title = esc_html__('Portfolio items', 'neko-portfolio');

  $title_postlink = esc_html__( 'List of portfolio items', 'neko-portfolio' );
  $desc_postlink  = '';

  $key_value = array();
  $posts_args = array( 'posts_per_page' => -1, 'post_type' => 'neko_portfolio', 'post_status' => 'publish' );

  $posts = get_posts($posts_args);
  foreach ($posts as $p) {
  	$key_value[$p->ID] = $p->post_title;
  }

  $repeater_fields[] = $my_meta->addSelect(
  	$prefix.'re_neko_portfolio_id',
  	$key_value,
  	array(
  		'name' => $title_postlink,
  		'class' => 'no-fancy'
  		),
  	true
  	);

  $my_meta->addRepeaterBlock($prefix.'re_marker',array('inline' => true, 'name' => 'Hand pick portfolio items you want to show as related to this one.', 'sortable' => true,'fields' => $repeater_fields));


  //Finish Meta Box Declaration 
  $my_meta->Finish();


  



  /**
   * Video metabox
   */
  $config_video = array(
    'id'             => 'portfolio_video_metabox',      // meta box id, unique per meta box
    'title'          => 'Video',      // meta box title
    'pages'          => array('neko_portfolio'),        // post types, accept custom post types as well, default is array('post'); optional
    'context'        => 'normal',                       // where the meta box appear: normal (default), advanced, side; optional
    'priority'       => 'high',                         // order of meta box: high (default), low; optional
    'fields'         => array(),                        // list of meta fields (can be added by field arrays)
    'local_images'   => false,                          // Use local or hosted images (meta box images for add/remove)                      
    'use_with_theme' => $pluginUri . '/neko-portfolio/includes/tools/neko-metabox-generator/engine' //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
    );


  /**
   * Initiate your meta box
   */
  $my_meta_video =  new Neko_Portfolio_AT_Meta_Box($config_video);

   //Video type
  $title_video_type  = esc_html__('Video Type', 'neko-portfolio');
  $desc_video_type = esc_html__('Defines the video type for embeding method', 'neko-portfolio');
  $my_meta_video->addSelect($prefix.'video_type',array('0'=>'Youtube','1'=>'Vimeo','3'=>esc_html__('local', 'neko-portfolio')),array('name'=> $title_video_type.' ', 'std'=> array('0'), 'desc' => $desc_video_type, 'class' => 'no-fancy'));

  //Video url
  $title_video_url  = esc_html__('Video Url', 'neko-portfolio');
  $desc_video_url = esc_html__('For online video enter the video id, For local video enter the video url', 'neko-portfolio');
  $my_meta_video->addText($prefix.'video_url',array('name'=> $title_video_url.' ', 'desc' => $desc_video_url));

  //Video width
  $title_video_width  = esc_html__('Video width', 'neko-portfolio');
  $desc_video_width = esc_html__('For online video enter the width of the video', 'neko-portfolio');
  $my_meta_video->addText($prefix.'video_width',array('name'=> $title_video_width.' ', 'desc' => $desc_video_width));

  //Video height
  $title_video_height  = esc_html__('Video height', 'neko-portfolio');
  $desc_video_height = esc_html__('For online video enter the height of the video', 'neko-portfolio');
  $my_meta_video->addText($prefix.'video_height',array('name'=> $title_video_height.' ', 'desc' => $desc_video_height));



  //Finish Meta Box Declaration 
  $my_meta_video->Finish();

  } //is admin