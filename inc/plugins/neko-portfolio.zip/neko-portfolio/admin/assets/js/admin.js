jQuery(function($){ 

	$(".shortcode-selector").click(function() {
	   $(this).select();
	});

}); /* End Doucment ready */