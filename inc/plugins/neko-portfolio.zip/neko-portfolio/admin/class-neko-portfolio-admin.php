<?php
/**
 * Neko Portfolio.
 *
 * @package   Neko_Portfolio_Admin
 * @author    Little Neko <email@example.com>
 * @license   GPL-2.0+
 * @link      http://www.little-neko.com
 * @copyright 2013 Thomas Bechier
 */

/**
 * Plugin class. This class should ideally be used to work with the
 * administrative side of the WordPress site.
 *
 * If you're interested in introducing public-facing
 * functionality, then refer to `class-plugin-name.php`
 *
 * @package Neko_Portfolio_Admin
 * @author  Your Name <email@example.com>
 */
class Neko_Portfolio_Admin {

	/**
	 * Instance of this class.
	 *
	 * @since    1.0.0
	 * @var      object
	 */
	protected static $instance     = null;
	

	/**
	 * Slug of the plugin screen.
	 *
	 * @since    1.0.0
	 * @var      string
	 */
	protected $plugin_screen_hook_suffix = null;

	/**
	 * admin include path.
	 *
	 * @since    1.0.0
	 * @var      string
	 */
	const NP_INCLUDES = 'includes/';

	/**
	 * Initialize the plugin by loading admin scripts & styles and adding a
	 * settings page and menu.
	 *
	 * @since     1.0.0
	 */
	private function __construct() {

		/*
		 * - Uncomment following lines if the admin class should only be available for super admins
		 */
		/* if( ! is_super_admin() ) {
			return;
		} */

		/*
		 * Call $plugin_slug from public plugin class.
		 *
		 */
		$plugin = Neko_Portfolio::get_instance();
		$this->plugin_slug = $plugin->get_plugin_slug();

		/* Load admin style sheet and JavaScript. */
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_styles' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );



		/* Add the options page and menu item. */
		//add_action( 'admin_menu', array( $this, 'add_plugin_admin_menu' ) );

		/* Add an action link pointing to the options page. */
		//$plugin_basename = plugin_basename( $this->plugin_slug.'/' . $this->plugin_slug . '.php' );
		//add_filter( 'plugin_action_links_' . $plugin_basename, array( $this, 'add_action_links' ) );

		
		/*
		 * Define custom functionality.
		 * Read more about actions and filters:
		 * http://codex.wordpress.org/Plugin_API#Hooks.2C_Actions_and_Filters
		 */

		add_action( 'init', array( $this, 'neko_init' ), 2 );

		/* add images sizes */
		add_action( 'init', array( $this, 'addNekoPortfolioImageizes') );

		/* add admin columns */
		add_filter( 'manage_neko_portfolio_posts_columns', array( $this,'set_custom_neko_portfolio_columns'));
		add_action( 'manage_neko_portfolio_posts_custom_column', array( $this, 'custom_neko_portfolio_column'), 10, 1);

		/* register css */
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_custom_post_styles'));

		/* clean on delete */
		add_action('delete_neko_portfolio_category', array( $this, 'neko_delete_tax'));	
		//add_action('delete_neko_portfolio_filters', array( $this, 'neko_delete_tax'));	
	}


	/**
	 * Return an instance of this class.
	 *
	 * @since     1.0.0
	 * @return    object    A single instance of this class.
	 */
	public static function get_instance() {

		/*
		 * - Uncomment following lines if the admin class should only be available for super admins
		 */

		/* if( ! is_super_admin() ) {
			return;
		} */

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	/**
	 * Register and enqueue admin-specific style sheet.
	 * @since     1.0.0
	 * @return    null    Return early if no settings page is registered.
	 */
	public function enqueue_admin_styles() {
	
		if ( ! isset( $this->plugin_screen_hook_suffix ) ) {
			return;
		}
		$screen = get_current_screen();
		
		if ( $this->plugin_screen_hook_suffix == $screen->id) {
			wp_enqueue_style( $this->plugin_slug .'-admin-styles', plugins_url( 'assets/css/admin.css', __FILE__ ), array(), Neko_Portfolio::VERSION );
		}

	}

	/**
	 * Register and enqueue admin-specific JavaScript.
	 * @since     1.0.0
	 * @return    null    Return early if no settings page is registered.
	 */
	public function enqueue_admin_scripts() {

		// if ( ! isset( $this->plugin_screen_hook_suffix ) ) {
		// 	return;
		// }

		$screen = get_current_screen();
		if ( $this->plugin_screen_hook_suffix == $screen->id || 'edit-neko_portfolio_category' == $screen->id) {
			wp_enqueue_script( $this->plugin_slug . '-admin-script', plugins_url( 'assets/js/admin.js', __FILE__ ), array( 'jquery' ), Neko_Portfolio::VERSION );
		}

	}



	/**
	 * Register and enqueue custom posts admin-specific style sheet.
	 * @since     1.0.0
	 * @return    null    Return early if no settings page is registered.
	 */
	public function enqueue_admin_custom_post_styles(){

		$screen = get_current_screen();
		$portfolio_items='edit-'.str_replace('-', '_', $this->plugin_slug);
		if ( $portfolio_items == $screen->id ) {
			wp_enqueue_style( $this->plugin_slug .'-admin-styles', plugins_url( 'assets/css/columns.css', __FILE__ ), array(), Neko_Portfolio::VERSION );
		}

	}


	/**
	 * Register the administration menu for this plugin into the WordPress Dashboard menu.
	 *
	 * @since    1.0.0
	 */
	public function add_plugin_admin_menu() {

		/*
		 * Add a settings page for this plugin to the Settings menu.
		 *
		 * NOTE:  Alternative menu locations are available via WordPress administration menu functions.
		 *        Administration Menus: http://codex.wordpress.org/Administration_Menus.
		 */

		//add_options_page
		$this->plugin_screen_hook_suffix = add_submenu_page(
			'edit.php?post_type=neko_portfolio',
			esc_html__( 'Neko Portfolio Setting Page', 'neko-portfolio'),
			esc_html__( 'Settings', 'neko-portfolio' ),
			'manage_options',
			$this->plugin_slug,
			array( $this, 'display_plugin_admin_page' )
		);

	}


	/**
	 * Render the settings page for this plugin.
	 *
	 * @since    1.0.0
	 */	

	public function display_plugin_admin_page() {
		include_once( 'views/admin.php' );	
	}

	/**
	 * Add settings action link to the plugins page.
	 *
	 * @since    1.0.0
	 */
	public function add_action_links( $links ) {

		return array_merge(
			array(
				'settings' => '<a href="' . admin_url( 'options-general.php?page=' . $this->plugin_slug ) . '">' . esc_html__( 'Settings', 'neko-portfolio' ) . '</a>'
			),
			$links
		);

	}

	/**
	 * Add images sizes.
	 *
	 * @since    1.0.0
	 */

	public function addNekoPortfolioImageizes(){


		if (!in_array('img-xx-large-ms', get_intermediate_image_sizes())){
			add_image_size( 'img-xx-large-ms', 1140  );
		}

		if (!in_array('img-xx-large', get_intermediate_image_sizes())){
			add_image_size( 'img-xx-large', 1140,  800, true );
		}

		if (!in_array('img-x-large-ms', get_intermediate_image_sizes())){
			add_image_size( 'img-x-large-ms', 750 );
		}		


		if (!in_array('img-x-large', get_intermediate_image_sizes())){
			add_image_size( 'img-x-large', 750, 526, true );
		}		

		if (!in_array('img-large', get_intermediate_image_sizes())){
			add_image_size( 'img-large', 570, 400, true );
		}

		if (!in_array('img-large-ms', get_intermediate_image_sizes())){
			add_image_size( 'img-large-ms', 570 );
		}

		if (!in_array('img-medium', get_intermediate_image_sizes())){
			add_image_size( 'img-medium', 368, 258, true );
		}

		if (!in_array('img-medium-ms', get_intermediate_image_sizes())){
			add_image_size( 'img-medium-ms', 368 );
		}

		if (!in_array('img-small', get_intermediate_image_sizes())){
			add_image_size( 'img-small', 270, 189, true );
		}

		if (!in_array('img-small-ms', get_intermediate_image_sizes())){
			add_image_size( 'img-small-ms', 270);
		}

		if (!in_array('img-x-small', get_intermediate_image_sizes())){
			add_image_size( 'img-x-small', 62, 62, true);
		}

		if (!in_array('img-admin-thumbnail', get_intermediate_image_sizes())){
			add_image_size( 'img-admin-thumbnail',  100, 100, true );
		}
	}


	/**
	 * NOTE:     Actions are points in the execution of a page or process
	 *           lifecycle that WordPress fires.
	 *
	 *           Actions:    http://codex.wordpress.org/Plugin_API#Actions
	 *           Reference:  http://codex.wordpress.org/Plugin_API/Action_Reference
	 *
	 * @since    1.0.0
	 */
	
	/**
	 * Includes metaboxe engine and cutom meta boxes
	 */

	public function neko_init(){

		require_once( self::NP_INCLUDES . 'metabox-post/portfolio_item.php');
		require_once( self::NP_INCLUDES . 'metabox-taxonomy/portfolio.php');
	}

	 /**
	 * Add admin columns
	 *
	 * @since    1.0.0
	 */

	public function set_custom_neko_portfolio_columns($columns) {
		$column_thumbnail = array( 'thumbnail' => 'Thumbnail' );
		$columns = array_slice( $columns, 0, 1, true ) + $column_thumbnail + array_slice( $columns, 1, NULL, true );
		
		return $columns;

	}

	public function custom_neko_portfolio_column( $column ) {
		global $post;
		switch ( $column ) {

			case 'thumbnail' :
			if (get_the_post_thumbnail( $post->ID, 'img-admin-thumbnail')){
				echo '<a href="'.get_edit_post_link( $post->ID).'" title="edit">';
				echo get_the_post_thumbnail( $post->ID, 'img-admin-thumbnail', array('class' => 'neko_portfolio_thumbnail'));
				echo '</a>';
			
			} else {
				echo '<div class="neko_portfolio_no_thumbnail">';
				esc_html_e( 'No thumbnail', 'neko-portfolio' );
				echo '</div>';
			}

			break;

		}
	}

	

	/**
	 * After custom taxonomy delete hook
	 * Add all actions that needs to be executed within the after theme setup hook
	 * @since    1.0.0
	 */
	public function neko_delete_tax($tax_id){
		delete_option('tax_meta_'.$tax_id);
	}


//END OF CLASS	
}
