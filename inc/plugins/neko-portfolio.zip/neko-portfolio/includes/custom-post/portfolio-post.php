<?php 

global $neko_portfolio_nb_thumbs;


add_action( 'init', 'neko_register_cpt_portfolio', 3);

function neko_register_cpt_portfolio() {

	$labels = array( 
		'name'               => esc_html__( 'Portfolio Items', 'neko-portfolio' ),
		'singular_name'      => esc_html__( 'Portfolio', 'neko-portfolio' ),
		'all_items'          => esc_html__( 'Portfolio items', 'neko-portfolio' ),
		'add_new'            => esc_html__( 'Add Portfolio Item', 'neko-portfolio' ),
		'add_new_item'       => esc_html__( 'Add Portfolio Item', 'neko-portfolio' ),
		'edit_item'          => esc_html__( 'Edit Portfolio Item', 'neko-portfolio' ),
		'new_item'           => esc_html__( 'New Portfolio Item', 'neko-portfolio' ),
		'view_item'          => esc_html__( 'View Portfolio Item', 'neko-portfolio' ),
		'search_items'       => esc_html__( 'Search portfolio Items', 'neko-portfolio' ),
		'not_found'          => esc_html__( 'No portfolio item found', 'neko-portfolio' ),
		'not_found_in_trash' => esc_html__( 'No portfolio item found in Trash', 'neko-portfolio' ),
		'parent_item_colon'  => esc_html__( 'Parent portfolio:', 'neko-portfolio' ),
		'menu_name'          => esc_html__( 'Neko Portfolio', 'neko-portfolio' ),
		);

	$args = array(
		'menu_icon' => 'dashicons-format-gallery', 
		'labels' => $labels,
		'hierarchical' => false,  
		'supports' => array( 'title', 'editor', 'thumbnail', 'comments', 'excerpt', 'revisions' ),
		'public' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'menu_position' => 28,
		'show_in_nav_menus' => true,
		'publicly_queriable' => true,
		'exclude_from_search' => false,
		'has_archive' => false,
		'query_var' => true,
		'can_export' => true,
		'capability_type' => 'post',
		'rewrite' => array('slug' => 'portfolio-item')
		);

	register_post_type( 'neko_portfolio', $args  );
}


if (class_exists('Neko_Portfolio_MultiPostThumbnails')) {

	for ($i = 1; $i <= $neko_portfolio_nb_thumbs; $i++) {
		new Neko_Portfolio_MultiPostThumbnails(

			array(
				'label' => 'Featured Image '.($i + 1),
				'id' => 'image'.$i,
				'post_type' => 'neko_portfolio'
				)   
			);
	}


}



?>