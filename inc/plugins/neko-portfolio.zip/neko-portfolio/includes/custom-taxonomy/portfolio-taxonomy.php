<?php
add_action( 'init', 'neko_portfolio_category_taxonomies' );
add_action( 'init', 'neko_portfolio_filter_taxonomies' );

function neko_portfolio_category_taxonomies() 
{
  		// Add new taxonomy, make it hierarchical (like categories)
	$labels = array(
		'name'                       => esc_html__( 'Portfolios', 'neko-portfolio' ),
		'singular_name'              => esc_html__( 'Portfolio', 'neko-portfolio' ),
		'menu_name'                  => esc_html__( 'Portfolios', 'neko-portfolio' ),
		'name_admin_bar'             => esc_html__( 'Portfolio', 'neko-portfolio' ),
		'search_items'               => esc_html__( 'Search Portfolios', 'neko-portfolio' ),
		'popular_items'              => esc_html__( 'Popular Portfolios',  'neko-portfolio' ),
		'all_items'                  => esc_html__( 'All Portfolios', 'neko-portfolio' ),
		'edit_item'                  => esc_html__( 'Edit Portfolio', 'neko-portfolio' ),
		'view_item'                  => esc_html__( 'View Portfolio', 'neko-portfolio' ),
		'update_item'                => esc_html__( 'Update Portfolio', 'neko-portfolio' ),
		'add_new_item'               => esc_html__( 'Add New Portfolio', 'neko-portfolio' ),
		'new_item_name'              => esc_html__( 'New Portfolio Name', 'neko-portfolio' ),
		);    

$args = array(
	'labels'              => $labels,
	'public'              => true,
	'show_ui'             => true,
	'show_admin_column'   => true,
	'show_in_nav_menus'	  => false,
	'show_tagcloud'       => false,
	'query_var'           => true,
	'hierarchical'        => false,
	'rewrite'             => array( 
		'slug' => 'portfolio',
		'with_front'   => false,
		'hierarchical' => false,
		'ep_mask'      => EP_NONE
		)
	);
register_taxonomy( 'neko_portfolio_category', array( 'neko_portfolio' ), $args );
}

function neko_portfolio_filter_taxonomies() 
{
  		// Add new taxonomy, make it hierarchical (like categories)
	$labels = array(
		'name'                       => esc_html__( 'Filters', 'neko-portfolio' ),
		'singular_name'              => esc_html__( 'Filters', 'neko-portfolio' ),
		'search_items'               => esc_html__( 'Search Filters', 'neko-portfolio' ),
		'all_items'                  => esc_html__( 'All Filters', 'neko-portfolio' ),
		'parent_item'                => esc_html__( 'Parent Filter', 'neko-portfolio' ),
		'parent_item_colon'          => esc_html__( 'Parent Filter:', 'neko-portfolio' ),
		'edit_item'                  => esc_html__( 'Edit Filter', 'neko-portfolio' ), 
		'update_item'                => esc_html__( 'Update Filters', 'neko-portfolio' ),
		'add_new_item'               => esc_html__( 'Add New Filter', 'neko-portfolio' ),
		'new_item_name'              => esc_html__( 'New Filter Name', 'neko-portfolio' ),
		'menu_name'                  => esc_html__( 'Filters', 'neko-portfolio' ),
		'separate_items_with_commas' => esc_html__( 'Separate filters with commas', 'neko-portfolio' ),
		'add_or_remove_items'        => esc_html__( 'Add or remove filters', 'neko-portfolio' ),
		'choose_from_most_used'      => esc_html__( 'Choose from the most used filters', 'neko-portfolio' )
		);    

/* TODO Hierachical for reorder purposes ??*/
$args = array(
	'hierarchical'        => false,
	'labels'              => $labels,
	'show_ui'             => true,
	'show_admin_column'   => false,
	'show_tagcloud'       => true,
	'show_in_nav_menus'	  => false,
	'query_var'           => true,
	'rewrite'             => array( 'slug' => 'neko_portfolio_filters' )
	);

register_taxonomy( 'neko_portfolio_filters', array( 'neko_portfolio' ), $args );
}


add_action( 'admin_menu', 'neko_portfolio_remove_meta_box');  
function neko_portfolio_remove_meta_box(){  
	remove_meta_box( 'tagsdiv-neko_portfolio_category', 'neko_portfolio', 'side' ); 
}


add_action( 'add_meta_boxes', 'neko_portfolio_addmeta_boxes' );


function neko_portfolio_addmeta_boxes( ) {

	add_meta_box( 'tagsdiv-neko_portfolio_category', 'Portfolios', 'portfolio_selector', 'neko_portfolio', 'side' );
}

function portfolio_selector( $post, $meta_box ) {

	$taxonomy = 'neko_portfolio_category';
	$tax      = get_taxonomy( $taxonomy );
	$name = 'tax_input[' . $taxonomy . '][]'; 

	$terms = get_terms($taxonomy,array('hide_empty' => 0)); 

	$postterms = get_the_terms( $post->ID,$taxonomy );  


	$current = array();

	if(!empty($postterms)){
		foreach ($postterms as $checkedKey => $checkedValue) {
			array_push($current, $checkedValue->slug);
		}
	}

	$popular = get_terms( $taxonomy, array( 'orderby' => 'count', 'order' => 'DESC', 'number' => 10, 'hierarchical' => false ) );
	
	?>

	<div id="taxonomy-<?php echo esc_attr($taxonomy); ?>" class="categorydiv">

		<!-- Display tabs-->  
		<ul id="<?php echo esc_attr($taxonomy); ?>-tabs" class="category-tabs">  
			<li class="tabs">
				<a href="#<?php echo esc_attr($taxonomy); ?>-all" tabindex="3"><?php echo $tax->labels->all_items; ?></a>
			</li>  
			<li class="hide-if-no-js">
				<a href="#<?php echo esc_attr($taxonomy); ?>-pop" tabindex="3"><?php esc_html_e( 'Most Used', 'neko-portfolio' ); ?></a>
			</li>  
		</ul>

		<!-- Display taxonomy terms -->  
		<div id="<?php echo esc_attr($taxonomy); ?>-all" class="tabs-panel">  
			<ul id="<?php echo esc_attr($taxonomy); ?>checklist" class="list:<?php echo esc_attr($taxonomy)?> categorychecklist form-no-clear">  
				<?php   
				foreach($terms as $term){  
					$checked = in_array( $term->slug, $current ) ? ' checked="checked" ' : ''; 
					$id = $taxonomy.'-'.$term->term_id;  
					echo "<li id='$id'><label class='selectit'>";  
					echo "<input type='checkbox' id='in-esc_attr($id)' name='{$name}' ".$checked." value='$term->slug' />&nbsp;$term->name<br />";  
					echo "</label></li>"; 
				}
				?>  
			</ul>  
		</div>  		

		<!-- Display popular taxonomy terms -->  
		<div id="<?php echo esc_attr($taxonomy); ?>-pop" class="tabs-panel" style="display: none;">  
			<ul id="<?php echo esc_attr($taxonomy); ?>checklist-pop" class="categorychecklist form-no-clear" >  
				<?php   foreach($popular as $term){ 
					$checked = in_array( $term->slug, $current ) ? ' checked="checked" ' : '';  
					$id = 'popular-'.$taxonomy.'-'.$term->term_id;  
					echo "<li id='$id'><label class='selectit'>";  
					echo "<input type='checkbox' id='in-esc_attr($id)' ".$checked." value='$term->slug' />&nbsp;$term->name<br />";  
					echo "</label></li>";  
				}?>  
			</ul>  
		</div>  
	</div>
<?php } ?>