<?php

class recent_portfolio extends WP_Widget {
    
    function recent_portfolio()
    {
        $widget_ops = array('classname' => 'recent_works', 'description' => 'Recent works from the portfolio.');

        $control_ops = array('id_base' => 'recent_works-widget');

        parent::__construct('recent_works-widget', '[ NEKO ] Recent Portfolio', $widget_ops, $control_ops);
    }
    
    function widget($args, $instance)
    {
        extract($args);
        $title_text = ( !empty($instance['title']) ) ? $instance['title'] : esc_html__('Latest work', 'neko-portfolio') ; 
        $title = apply_filters( 'widget_title', $title_text );

        $number = ( !empty($instance['number']) ) ? $instance['number'] : 4 ;
        
        echo $before_widget;

        if($title) {
            echo $before_title . $title . $after_title;
        }
        ?>
        <div class="neko-recent-portfolio-items clearfix neko-cols-<?php echo $number; ?>">
        <?php
        $args = array(
            'post_type' => 'neko_portfolio',
            'posts_per_page' => $number
        );
        $portfolio = new WP_Query($args);
        if($portfolio->have_posts()):
        ?>
        <?php while($portfolio->have_posts()): $portfolio->the_post(); ?>
        <?php 
        	if(has_post_thumbnail()): 
        		switch ( @$instance['link'] ) {
        			case 1:
	        			$link = get_permalink();
	        			$class ='';
        			break;
        			case 2:
								$link  = wp_get_attachment_image_src( get_post_thumbnail_id(), 'img-x-large');
								$link = $link[0];
								$class ='neko-portfolio-magnific-pop-gallery-inline';
        			break;
        			default:
	        			$link = get_permalink();
	        			$class ='';
        		}
        ?>

        <a href="<?php echo esc_url($link) ; ?>" title="<?php the_title(); ?>" class="tips recentWorkLink <?php echo $class; ?>" data-placement="top" data-original-title="<?php the_title(); ?>">
            <?php the_post_thumbnail('img-x-small'); ?> 
        </a>

        <?php endif; endwhile; endif; ?>
        </div>

        <?php echo $after_widget;
    }
    
    function update($new_instance, $old_instance)
    {
        $instance = $old_instance;

		$instance['title']  = strip_tags($new_instance['title']);
		$instance['number'] = strip_tags($new_instance['number']);
		$instance['link']   =  strip_tags($new_instance['link']);
        return $instance;
    }

    function form($instance)
    {
        $defaults = array('title' => esc_html__('Latest work', 'neko-portfolio'), 'number' => 4);
        $instance = wp_parse_args((array) $instance, $defaults); 
        $linkType = array(1 => esc_html__('page', 'neko-portfolio'),2 =>  esc_html__('popin', 'neko-portfolio'));

       
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php esc_html_e('Title', 'neko-portfolio');?> :</label>
            <input class="widefat"  type="text" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $instance['title']; ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('number'); ?>"><?php esc_html_e('Number of items to show', 'neko-portfolio');?> :</label>
            <input class="widefat"  type="text" id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" value="<?php echo $instance['number']; ?>" />
        </p>

        <p>

            <label for="<?php echo $this->get_field_id('link'); ?>"><?php esc_html_e('Link type', 'neko-portfolio');?> :</label>
            <select class="widefat" name="<?php echo $this->get_field_name('link'); ?>" id="<?php echo $this->get_field_id('link'); ?>">

            <?php
            	foreach ($linkType as $key => $value) {

            		$selected = ($instance['link'] == $key) ?'selected="selected"':'';
            		echo '<option value="'.$key.'" '.$selected.'>'.esc_html__($value, 'neko-portfolio').'</option>';
            	}
            ?>
            	
            </select>
           
        </p>
    <?php
    }
}