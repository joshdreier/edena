<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @package   WP Owl Carousel
 * @author    Little Neko <contact@little-neko.com>
 * @license   GPL-2.0+
 * @link      http://example.com
 * @copyright 2013 Little Neko
 */

// If uninstall not called from WordPress, then exit
if ( !defined('ABSPATH') && ! defined( 'WP_UNINSTALL_PLUGIN' ) ) exit;


// @TODO: Define uninstall functionality here
global $wpdb;
$custom_post      = 'neko_portfolio';
$custom_taxonomy  = 'neko_portfolio_category';
$custom_taxonomy1 = 'neko_portfolio_filters';

if ( is_multisite() ) {
  
	$blogs = $wpdb->get_results( "SELECT blog_id FROM {$wpdb->blogs}", ARRAY_A );

			/* @TODO: delete all transient, options and files you may have added */

			//Delete the main custom post data
			$posts = get_posts( array(
				'numberposts' => -1,
				'post_type' => $custom_post,
				'post_status' => 'any' ) );

			foreach ( $posts as $post ) wp_delete_post( $post->ID, true );

			//Delete the main custom taxonomy data
			$taxonomies_sql = "SELECT `term_taxonomy_id`,`term_id` FROM `".$wpdb->prefix."term_taxonomy` WHERE `taxonomy` IN ('$custom_taxonomy', '$custom_taxonomy1')";
			$taxonomies = $wpdb->get_results($taxonomies_sql,ARRAY_A);
			foreach( $taxonomies as $taxonomy ) {

				$wpdb->query("DELETE FROM `".$wpdb->prefix."term_relationships` WHERE `term_taxonomy_id` = ".$taxonomy['term_taxonomy_id']);
				$wpdb->query("DELETE FROM `".$wpdb->prefix."terms` WHERE `term_id` = ".$taxonomy['term_id']);
				delete_option('tax_meta_'.$taxonomy['term_id']);
			}
			$wpdb->query("DELETE FROM `".$wpdb->prefix."term_taxonomy` WHERE `taxonomy` IN ('wpsc_product_category','product_tag')");

			$GLOBALS['wpdb']->query("OPTIMIZE TABLE `" .$GLOBALS['wpdb']->prefix."options`");
			$GLOBALS['wpdb']->query("OPTIMIZE TABLE `" .$GLOBALS['wpdb']->prefix."term_relationships`");
			$GLOBALS['wpdb']->query("OPTIMIZE TABLE `" .$GLOBALS['wpdb']->prefix."terms`");


			//Flush Rewrite Rules
			flush_rewrite_rules();

	if ( $blogs ) {

	 	foreach ( $blogs as $blog ) {

			switch_to_blog( $blog['blog_id'] );

			/* @TODO: delete all transient, options and files you may have added */
	


			//Delete the main custom post data
			$posts = get_posts( array(
				'numberposts' => -1,
				'post_type' => $custom_post,
				'post_status' => 'any' ) );

			foreach ( $posts as $post ) wp_delete_post( $post->ID, true );

			//Delete the main custom taxonomy data
			$taxonomies_sql = "SELECT `term_taxonomy_id`,`term_id` FROM `".$wpdb->prefix."term_taxonomy` WHERE `taxonomy` IN ('$custom_taxonomy', '$custom_taxonomy1')";
			$taxonomies = $wpdb->get_results($taxonomies_sql,ARRAY_A);
			foreach( $taxonomies as $taxonomy ) {

				$wpdb->query("DELETE FROM `".$wpdb->prefix."term_relationships` WHERE `term_taxonomy_id` = ".$taxonomy['term_taxonomy_id']);
				$wpdb->query("DELETE FROM `".$wpdb->prefix."terms` WHERE `term_id` = ".$taxonomy['term_id']);
				delete_option('tax_meta_'.$taxonomy['term_id']);
			}
			$wpdb->query("DELETE FROM `".$wpdb->prefix."term_taxonomy` WHERE `taxonomy` IN ('wpsc_product_category','product_tag')");

			$GLOBALS['wpdb']->query("OPTIMIZE TABLE `" .$GLOBALS['wpdb']->prefix."options`");
			$GLOBALS['wpdb']->query("OPTIMIZE TABLE `" .$GLOBALS['wpdb']->prefix."term_relationships`");
			$GLOBALS['wpdb']->query("OPTIMIZE TABLE `" .$GLOBALS['wpdb']->prefix."terms`");

			//Flush Rewrite Rules
			flush_rewrite_rules();

			restore_current_blog();
		}
	}

} else {
	
	/* @TODO: delete all transient, options and files you may have added */



	//Delete the main custom post data
	$posts = get_posts( array(
		'numberposts' => -1,
		'post_type' => $custom_post,
		'post_status' => 'any' ) );

	foreach ( $posts as $post ) wp_delete_post( $post->ID, true );

	//Delete the main custom taxonomy data
	$taxonomies_sql = "SELECT `term_taxonomy_id`,`term_id` FROM `".$wpdb->prefix."term_taxonomy` WHERE `taxonomy` IN ('$custom_taxonomy', '$custom_taxonomy1')";
	$taxonomies = $wpdb->get_results($taxonomies_sql,ARRAY_A);
	foreach( $taxonomies as $taxonomy ) {

		$wpdb->query("DELETE FROM `".$wpdb->prefix."term_relationships` WHERE `term_taxonomy_id` = ".$taxonomy['term_taxonomy_id']);
		$wpdb->query("DELETE FROM `".$wpdb->prefix."terms` WHERE `term_id` = ".$taxonomy['term_id']);
		delete_option('tax_meta_'.$taxonomy['term_id']);
	}
	$wpdb->query("DELETE FROM `".$wpdb->prefix."term_taxonomy` WHERE `taxonomy` IN ('wpsc_product_category','product_tag')");

	$GLOBALS['wpdb']->query("OPTIMIZE TABLE `" .$GLOBALS['wpdb']->prefix."options`");
	$GLOBALS['wpdb']->query("OPTIMIZE TABLE `" .$GLOBALS['wpdb']->prefix."term_relationships`");
	$GLOBALS['wpdb']->query("OPTIMIZE TABLE `" .$GLOBALS['wpdb']->prefix."terms`");

	//Flush Rewrite Rules
	flush_rewrite_rules();

}