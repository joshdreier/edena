<?php
require_once('engine/my-meta-box-custom-class.php');

if ( ! class_exists( 'Neko_Gmap_Meta_extends_Class') ){

	class Neko_Gmap_Meta_extends_Class extends Neko_Gmap_AT_Meta_Box{

		public function __contruct( $meta_box ){
			parent::__construct( $meta_box ); 
		}


		  /**
		   * Show Posts field.
		   * used creating a posts/pages/custom types checkboxlist or a select dropdown
		   * @param string $field 
		   * @param string $meta 
		   * @since 1.0
		   * @access public 
		   */
		   public function show_field_posts($field, $meta) {
		   	global $post;

		   	if (!is_array($meta)) $meta = (array) $meta;
		   	$this->show_field_begin($field, $meta);
		   	$options = $field['options'];
		   	$posts = get_posts($options['args']);
    		// checkbox_list
		   	if ('checkbox_list' == $options['type']) {
		   		foreach ($posts as $p) {
		   			echo "<input type='checkbox' ".( isset($field['style'])? "style='{$field['style']}' " : '' )." class='at-posts-checkbox".( isset($field['class'])? ' ' . $field['class'] : '' )."' name='{$field['id']}[]' value='$p->ID'" . checked(in_array($p->ID, $meta), true, false) . " /> $p->post_title<br/>";
		   		}
		   	}
    		// select
		   	else {
		   		echo "<select ".( isset($field['style'])? "style='{$field['style']}' " : '' )." class='at-posts-select".( isset($field['class'])? ' ' . $field['class'] : '' )."' name='{$field['id']}" . ($field['multiple'] ? "[]' multiple='multiple' style='height:auto'" : "'") . ">";
		   		//if (isset($field['emptylabel']))
		   		echo '<option value="-1">'.(isset($field['emptylabel'])? $field['emptylabel']: esc_html__('Select ...','neko-gmap')).'</option>';
		   		foreach ($posts as $p) {
		   			echo "<option value='$p->ID'" . selected(in_array($p->ID, $meta), true, false) . ">$p->post_title</option>";
		   		}
		   		echo "</select>";
		   	}

		   	$this->show_field_end($field, $meta);
		   }



	}/* END OF CLASS */

} /* End Check Class Exists */