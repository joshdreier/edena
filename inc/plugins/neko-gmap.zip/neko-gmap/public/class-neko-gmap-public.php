<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://little-neko.com/
 * @since      1.0.0
 *
 * @package    Neko_Gmap
 * @subpackage Neko_Gmap/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Neko_Gmap
 * @subpackage Neko_Gmap/public
 * @author     Thomas Bechier
 */
class Neko_Gmap_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/neko-gmap-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/neko-gmap-public.js', array( 'jquery' ), $this->version, true );
		//wp_enqueue_script( $this->plugin_name.'_googlemapapi', 'http://maps.google.com/maps/api/js?sensor=false&amp;callback=initialize_neko_gmap', array($this->plugin_name), $this->version, false );
		
	}




	/**
	 * Shortcode Activation
	 * @since    1.0.0
	 */
	public function neko_gmap_shortcode( $atts, $content = null ) {
		
		extract(
			shortcode_atts(
				array(
					'slug' => ''
					), $atts
				)
			);

		$args = array(
			'name'        => $slug,
			'post_type'   => 'neko-gmap',
			'post_status' => 'publish',
			'numberposts' => 1
			);

		$gmap_posts = get_posts( $args );
		//echo '<pre>'; print_r($gmap_posts); echo '</pre>';

		$neko_gmap_id = $gmap_posts[0]->ID;

		ob_start();

		include(plugin_dir_path( __FILE__ ) . 'partials/neko-gmap-public-display.php');

		$content = ob_get_clean();

		return $content;

	}

	/**
	 * Get gmap
	 */
	public function neko_add_shortcode_to_vc() {

		$output = array();
		$args = array(
			'posts_per_page'   => '-1',
			'orderby'          => 'date',
			'order'            => 'DESC',
			'post_type'        => 'neko-gmap',
			'post_status'      => 'publish'
			);

		$gmap_posts = get_posts( $args );
		//echo '<pre>'; print_r($gmap_posts); echo '</pre>'; 

		$count = count($gmap_posts);

		if ( $count > 0 ){
			foreach ( $gmap_posts as $g_post ){
				$output[$g_post->post_title] = $g_post->post_name;
			}
		}

		vc_map( 
			array(
				"name" => esc_html__( "Neko gmap", "neko-gmap" ),
				"base" => "NEKO_GMAP",
				"class" => "",
				"category" => esc_html__( "Neko shortcodes", "neko-gmap"),
				"icon" => plugins_url( '/assets/image/icon-neko-gmap.png', __FILE__ ),
				"params" => array(

				/**
				 * TITLE
				 */			
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => esc_html__( "Select your Google Map", "neko-gmap" ),
					"param_name" => "slug",
					"value" => $output,
					"description" => esc_html__( "Select the Google Map you wan to show here", "neko-gmap" )
					)

				)
				)
			);

		add_shortcode('NEKO_GMAP', array( $this, 'neko_gmap_shortcode'));

	}	






} // END OF CLASS
?>