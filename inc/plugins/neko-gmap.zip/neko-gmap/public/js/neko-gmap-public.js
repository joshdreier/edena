(function( $ ) {
	'use strict';

  /* DOC READY */
	$(function() { });


   /* WIN LOAD */
	$( window ).load(function() {
    appendGmapApi();
	});


})( jQuery );

var $mapType    = '';
var $mapStyle   = '';
var $mapSize    = '';
var $mapCtrlPos = '';
function appendGmapApi() {
	"use strict";
	if(jQuery('.neko-gmap').length){

		var script = document.createElement("script");
		script.type = "text/javascript";
		script.src = "https://maps.googleapis.com/maps/api/js?callback=initialize_neko_gmap";
		document.body.appendChild(script);



	}
}  // end of function appendGmapApi()


/*
|--------------------------------------------------------------------------
| Google maps
|--------------------------------------------------------------------------
*/	

function initialize_neko_gmap(id) {
	"use strict";

	var myMarkerImage = new google.maps.MarkerImage('images/icon-map.png');

	var image = {
		url: 'images/icon-map.png',
		size: new google.maps.Size(71, 71),
		origin: new google.maps.Point(0, 0),
		anchor: new google.maps.Point(17, 34),
		scaledSize: new google.maps.Size(25, 25)
	};

	var overlayTitle = 'Agencies';


	/*** DON'T CHANGE ANYTHING PASSED THIS LINE ***/
	jQuery('.neko-gmap').each(function(index, el) {
		
		var $this = jQuery(this);
		var unic_id = $this.data('nekomapid');
		var $mapZoom = window['mapZoom_'+unic_id];
		var locations = window['locations_'+unic_id];

		/* Map Type */
		if($this.hasClass('neko_gmap_satellite')){ $mapType = 'SATELLITE';}
		else if($this.hasClass('.neko_gmap_hybrid')){ $mapType = 'HYBRID';}
		else if($this.hasClass('.neko_gmap_terrain')){ $mapType = 'TERRAIN';}
		else{ $mapType = 'ROADMAP';}

		/* Map Style */
		if($this.hasClass('neko_gmap_light')){ $mapStyle = 'light';}
		else if($this.hasClass('neko_gmap_dark')){ $mapStyle = 'dark';}
		else if($this.hasClass('neko_gmap_grey')){ $mapStyle = 'gray';}
		else if($this.hasClass('neko_gmap_flat')){ $mapStyle = 'flat';}
		else{ $mapStyle = 'DEFAULT';}

		/* Map Size */
		if($this.hasClass('neko_gmap_small')){ $mapSize = 'SMALL'; $mapCtrlPos = 'LEFT_BOTTOM';}
		else if($this.hasClass('.neko_gmap_medium')){ $mapSize = 'LARGE'; ; $mapCtrlPos = 'LEFT_CENTER';}
		else if($this.hasClass('.neko_gmap_large')){ $mapSize = 'LARGE'; ; $mapCtrlPos = 'LEFT_CENTER';}
		else if($this.hasClass('.neko_gmap_fullscreen')){ $mapSize = 'LARGE'; ; $mapCtrlPos = 'LEFT_CENTER';}
		else{ $mapSize = 'LARGE'; ; $mapCtrlPos = 'LEFT_CENTER';}


		var map = new google.maps.Map($this[0], {
			scrollwheel: false,
			zoomControl: true,
			zoomControlOptions: {
				style: google.maps.ZoomControlStyle.$mapSize
			},
			streetViewControl:true,
			scaleControl:false,
			zoom: $mapZoom
		});


		if($mapType == 'SATELLITE'){
			map.setMapTypeId(google.maps.MapTypeId.SATELLITE);
		}else if($mapType == 'HYBRID'){
			map.setMapTypeId(google.maps.MapTypeId.HYBRID);
		}else if($mapType == 'TERRAIN'){
			map.setMapTypeId(google.maps.MapTypeId.TERRAIN);
		}else{
			map.setMapTypeId(google.maps.MapTypeId.ROADMAP);
		}


		if($mapStyle == 'light' && $mapType == 'ROADMAP'){

			var $lightMap = [{"featureType":"landscape","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"poi","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"stylers":[{"hue":"#00aaff"},{"saturation":-100},{"gamma":2.15},{"lightness":12}]},{"featureType":"road","elementType":"labels.text.fill","stylers":[{"visibility":"on"},{"lightness":24}]},{"featureType":"road","elementType":"geometry","stylers":[{"lightness":57}]}];

			var styledMap = new google.maps.StyledMapType($lightMap, {name: "light"});

		}else if($mapStyle == 'dark' && $mapType == 'ROADMAP'){

			var $darkMap = [{"featureType":"all","elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#000000"},{"lightness":40}]},{"featureType":"all","elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#000000"},{"lightness":16}]},{"featureType":"all","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":17},{"weight":1.2}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":20}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":21}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":16}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":19}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":17}]}];
			var styledMap = new google.maps.StyledMapType($darkMap, {name: "dark"});

		}else if($mapStyle == 'gray' && $mapType == 'ROADMAP'){

			var $grayMap = [{"featureType":"landscape","stylers":[{"saturation":-100},{"lightness":65},{"visibility":"on"}]},{"featureType":"poi","stylers":[{"saturation":-100},{"lightness":51},{"visibility":"simplified"}]},{"featureType":"road.highway","stylers":[{"saturation":-100},{"visibility":"on"}]},{"featureType":"road.arterial","stylers":[{"saturation":-100},{"lightness":30},{"visibility":"on"}]},{"featureType":"road.local","stylers":[{"saturation":-100},{"lightness":40},{"visibility":"on"}]},{"featureType":"transit","stylers":[{"saturation":-100},{"visibility":"simplified"}]},{"featureType":"administrative.province","stylers":[{"visibility":"on"}]},{"featureType":"water","elementType":"labels","stylers":[{"visibility":"on"},{"lightness":-25},{"saturation":-100}]},{"featureType":"water","elementType":"geometry","stylers":[{"hue":"#ffff00"},{"lightness":-25},{"saturation":-97}]}];
			var styledMap = new google.maps.StyledMapType($grayMap, {name: "grey"});

		}else if($mapStyle == 'flat' && $mapType == 'ROADMAP'){

			var $flatMap = [{"elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"landscape.natural","elementType":"geometry.fill","stylers":[{"color":"#f5f5f2"},{"visibility":"on"}]},{"featureType":"administrative","stylers":[{"visibility":"off"}]},{"featureType":"transit","stylers":[{"visibility":"off"}]},{"featureType":"poi.attraction","stylers":[{"visibility":"off"}]},{"featureType":"landscape.man_made","elementType":"geometry.fill","stylers":[{"color":"#ffffff"},{"visibility":"on"}]},{"featureType":"poi.business","stylers":[{"visibility":"off"}]},{"featureType":"poi.medical","stylers":[{"visibility":"off"}]},{"featureType":"poi.place_of_worship","stylers":[{"visibility":"off"}]},{"featureType":"poi.school","stylers":[{"visibility":"off"}]},{"featureType":"poi.sports_complex","stylers":[{"visibility":"off"}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"color":"#ffffff"},{"visibility":"simplified"}]},{"featureType":"road.arterial","stylers":[{"visibility":"simplified"},{"color":"#ffffff"}]},{"featureType":"road.highway","elementType":"labels.icon","stylers":[{"color":"#ffffff"},{"visibility":"off"}]},{"featureType":"road.highway","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"road.arterial","stylers":[{"color":"#ffffff"}]},{"featureType":"road.local","stylers":[{"color":"#ffffff"}]},{"featureType":"poi.park","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"poi","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"water","stylers":[{"color":"#71c8d4"}]},{"featureType":"landscape","stylers":[{"color":"#e5e8e7"}]},{"featureType":"poi.park","stylers":[{"color":"#8ba129"}]},{"featureType":"road","stylers":[{"color":"#ffffff"}]},{"featureType":"poi.sports_complex","elementType":"geometry","stylers":[{"color":"#c7c7c7"},{"visibility":"off"}]},{"featureType":"water","stylers":[{"color":"#a0d3d3"}]},{"featureType":"poi.park","stylers":[{"color":"#91b65d"}]},{"featureType":"poi.park","stylers":[{"gamma":1.51}]},{"featureType":"road.local","stylers":[{"visibility":"off"}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"visibility":"on"}]},{"featureType":"poi.government","elementType":"geometry","stylers":[{"visibility":"off"}]},{"featureType":"landscape","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"visibility":"simplified"}]},{"featureType":"road.local","stylers":[{"visibility":"simplified"}]},{"featureType":"road"},{"featureType":"road"},{},{"featureType":"road.highway"}];


			var styledMap = new google.maps.StyledMapType($flatMap, {name: "flat"});

		}

		if( $mapStyle != 'DEFAULT' && $mapType == 'ROADMAP'){
			map.mapTypes.set('map_style', styledMap);
			map.setMapTypeId('map_style');
		}

		var myLatlng;
		var marker, i;
		var bounds = new google.maps.LatLngBounds();
		var infowindow = new google.maps.InfoWindow({ content: "loading..." });

		for (i = 0; i < locations.length; i++) { 


			if(locations[i].mlat !== undefined && locations[i].mlongi !== undefined ){

				var content = '<div class="infoWindow"><h3>'+locations[i].mtitle+'</h3><p>'+locations[i].maddr+'</p></div>';
				(function(content) {
					myLatlng = new google.maps.LatLng(locations[i].mlat, locations[i].mlongi);

					marker = new google.maps.Marker({
						position: myLatlng, 
						title: overlayTitle,
						map: map
					});


					if(locations[i].mimg !== undefined ){
						marker.setIcon(locations[i].mimg);
					}			

					google.maps.event.addListener(marker, 'click', (function() {
						return function() {
							infowindow.setContent(content);
							infowindow.open(map, this);
						};

					})(this, i));

					if(locations.length > 1){
						bounds.extend(myLatlng);
						map.fitBounds(bounds);
					}else{
						map.setCenter(myLatlng);
					}



				})(content);
			}else{


				
				var geocoder  = new google.maps.Geocoder();
				var info      = locations[i].mtitle;
				var addr      = locations[i].maddr;
				var latLng    = locations[i].maddr;
				var markerimg = locations[i].mimg;

				(function(info, addr) {

					geocoder.geocode( {

						'address': latLng

					}, function(results) {

						myLatlng = results[0].geometry.location;


						marker = new google.maps.Marker({
							position: myLatlng, 
							title: overlayTitle,
							map: map
						});


						var $content = '<div class="infoWindow"><h3>'+info+'</h3><p>'+addr+'</p></div>';
						google.maps.event.addListener(marker, 'click', (function() {
							return function() {
								infowindow.setContent($content);
								infowindow.open(map, this);
							};
						})(this, i));




						if(locations.length > 1){
							bounds.extend(myLatlng);
							map.fitBounds(bounds);
						}else{
							map.setCenter(myLatlng);
						}

						if( markerimg !== undefined ){
							marker.setIcon(markerimg);
						}	

					});
				})(info, addr);

			}
		}



	});


}