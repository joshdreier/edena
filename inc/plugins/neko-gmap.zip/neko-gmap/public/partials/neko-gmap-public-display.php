<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       http://little-neko.com/
 * @since      1.0.0
 *
 * @package    Neko_Gmap
 * @subpackage Neko_Gmap/public/partials
 */
?>

<?php

// init vars
$neko_gmap_type   = get_post_meta( $neko_gmap_id,'neko_gmap_type', true );
$neko_gmap_skin   = get_post_meta( $neko_gmap_id,'neko_gmap_skin', true );
$neko_gmap_size   = get_post_meta( $neko_gmap_id,'neko_gmap_size', true );
$neko_gmap_zoom   = get_post_meta( $neko_gmap_id,'neko_gmap_zoom', true );
$neko_gmap_marker = get_post_meta( $neko_gmap_id,'neko_gmap_re_marker', true );
$unic_id = uniqid();
?>


<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div data-nekomapid="<?php echo esc_attr($unic_id); ?>" class="neko-gmap <?php echo esc_attr($neko_gmap_skin); ?> <?php echo esc_attr($neko_gmap_size); ?> <?php echo esc_attr($neko_gmap_type); ?> <?php echo esc_attr($neko_gmap_zoom); ?>"></div>

<script type="text/javascript">
	<?php if( !empty($neko_gmap_marker) ){ ?>
	window['<?php echo 'locations_'.esc_attr($unic_id);?>'] = [
		<?php
				foreach ($neko_gmap_marker as $marker) {
					$lat = ( !empty($marker['neko_gmap_re_latitude_marker']) ) ? ", mlat:  '".$marker['neko_gmap_re_latitude_marker']."'"  : '' ; 
					$long = ( !empty($marker['neko_gmap_re_longitude_marker']) ) ? ", mlongi:  '".$marker['neko_gmap_re_longitude_marker']."'"  : '' ;
					$image = ( !empty($marker['neko_gmap_re_image_marker']) ) ? ", mimg:  '".$marker['neko_gmap_re_image_marker']['url']."'"  : '' ;
					echo "{mtitle: '".esc_attr($marker['neko_gmap_re_title_marker'])."', maddr:  '".esc_attr($marker['neko_gmap_re_address_marker'])."' ".$lat." ".$long." ".$image."},";
				}	
		?>
	];
	<?php  }else{ ?>
		window['<?php echo 'locations_'.esc_attr($unic_id);?>'] = [{mtitle:'Empire State Building', maddr:'350 5th Ave NY 10118', mlat:'40.7170707', mlongi:'-74.0859825', mimg:''},];
	<?php  } ?>
	window['<?php echo 'mapZoom_'.esc_attr($unic_id);?>']= <?php echo $neko_gmap_zoom = ( !empty($neko_gmap_zoom) ) ?  $neko_gmap_zoom :  14 ; ?> ;
</script>