<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://little-neko.com/
 * @since      1.0.0
 *
 * @package    Neko_Gmap
 * @subpackage Neko_Gmap/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Neko_Gmap
 * @subpackage Neko_Gmap/admin
 * @author     Gaël Renault
 */
class Neko_Gmap_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/neko-gmap-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/neko-gmap-admin.js', array( 'jquery' ), $this->version, false );

	}


	/**
	 * Add Neko gmap custom post type.
	 *
	 * @since    1.0.0
	 */
	public function create_gmap_posttype(){

		$labels = array( 
			'name'               => esc_html__( 'Neko gmap', 'neko-gmap' ),
			'singular_name'      => esc_html__( 'gmap', 'neko-gmap' ),
			'all_items'          => esc_html__( 'gmaps', 'neko-gmap' ),
			'add_new'            => esc_html__( 'Add a gmap', 'neko-gmap' ),
			'add_new_item'       => esc_html__( 'Add gmap', 'neko-gmap' ),
			'edit_item'          => esc_html__( 'Edit gmap', 'neko-gmap' ),
			'new_item'           => esc_html__( 'New gmap', 'neko-gmap' ),
			'view_item'          => esc_html__( 'View gmaps', 'neko-gmap' ),
			'search_items'       => esc_html__( 'Search gmaps', 'neko-gmap' ),
			'not_found'          => esc_html__( 'No gmap found', 'neko-gmap' ),
			'not_found_in_trash' => esc_html__( 'No gmap found in Trash', 'neko-gmap' ),
			'menu_name'          => esc_html__( 'Neko Gmap', 'neko-gmap' ),
			);

		$args = array( 
			'labels'              => $labels,
			'menu_icon'           => 'dashicons-location-alt',
			'hierarchical'        => false,  
			'supports'            => array( 'title' ),
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'menu_position'       => 32,
			'show_in_nav_menus'   => false,
			'publicly_queryable'  => false,
			'exclude_from_search' => false,
			'has_archive'         => false,
			'query_var'           => true,
			'can_export'          => true,
			'capability_type'     => 'post',
			'rewrite'             => array('slug' => 'neko-gmap-item')
			);

		register_post_type( 'neko-gmap', $args );

	}

	/**
	 * Add Neko gmap option metabox.
	 *
	 * @since    1.0.0
	 */
	public function create_gmapoption_metabox(){

		$configSkin = array(
			'id'             => 'neko_gmap_option_metabox', 
			'title'          => esc_html__('Google map settings', 'neko-gmap'),
			'pages'          => array('neko-gmap'), 
			'context'        => 'normal',  
			'priority'       => 'high',                         
			'fields'         => array(),                     
			'local_images'   => false,                        
			'use_with_theme' => plugins_url() . '/neko-gmap/includes/libs/neko-metabox-generator/engine'
			);

		$prefix = 'neko_gmap_';



		
		$my_meta =  new Neko_Gmap_Meta_extends_Class( $configSkin );

		/* Type */
		$title_typemap = esc_html__( 'Google map type', 'neko-gmap' );
		$desc_typemap  = esc_html__( 'Choose the type of your Google map', 'neko-gmap' );
		$my_meta->addSelect($prefix.'type',
			array(
				'neko_gmap_roadmap'   =>esc_html__('Road map','neko-gmap'),
				'neko_gmap_satellite' =>esc_html__('Satellite','neko-gmap'),
				'neko_gmap_terrain'   =>esc_html__('Terrain','neko-gmap'),
				'neko_gmap_hybrid'    =>esc_html__('Hybrid','neko-gmap'),
				),

			array(
				'name'=> $title_typemap,
				'desc'=> $desc_typemap,
				'std'=> 'neko_gmap_roadmap', 
				'class' => 'no-fancy'
				)
			);



		/* Skin */
		$title_skinmap = esc_html__( 'Google map skin', 'neko-gmap' );
		$desc_skinmap  = esc_html__( 'the skin of your maps had an influence only on Road map type', 'neko-gmap' );
		$my_meta->addSelect($prefix.'skin',
			array(
				'neko_gmap_default'    =>esc_html__('Default','neko-gmap'),
				'neko_gmap_light'      =>esc_html__('light','neko-gmap'),
				'neko_gmap_dark'       =>esc_html__('dark','neko-gmap'),
				'neko_gmap_grey'       =>esc_html__('grey','neko-gmap'),
				'neko_gmap_flat'       =>esc_html__('flat','neko-gmap'),
				),

			array(
				'name'=> $title_skinmap,
				'desc'=> $desc_skinmap,
				'std'=> 'neko_gmap_default', 
				'class' => 'no-fancy'
				)
			);


		/* size */
		$title_sizemap = esc_html__( 'Google map size', 'neko-gmap' );
		$desc_sizemap  = esc_html__( 'Choose the size of your Google map', 'neko-gmap' );
		

		$my_meta->addSelect($prefix.'size',
			array(
				'neko_gmap_small'       =>esc_html__('small','neko-gmap'),
				'neko_gmap_medium'      =>esc_html__('medium','neko-gmap'),
				'neko_gmap_large'       =>esc_html__('large','neko-gmap')
				),

			array(
				'name'=> $title_sizemap,
				'desc'=> $desc_sizemap,
				'std'=> 'neko_gmap_medium', 
				'class' => 'no-fancy'
				)
			);


		/* Zoom */
		$title_zoommap = esc_html__( 'Google map zoom', 'neko-gmap' );
		$desc_zoommap  = esc_html__( 'Choose the zoom of your Google map. 20 is the bigger and 0 is the smallest', 'neko-gmap' );
		$my_meta->addSelect($prefix.'zoom',
			array(
				'' =>esc_html__('Default','neko-gmap'),
				20 =>esc_html__('20','neko-gmap'),
				19 =>esc_html__('19','neko-gmap'),
				18 =>esc_html__('18','neko-gmap'),
				17 =>esc_html__('17','neko-gmap'),
				16 =>esc_html__('16','neko-gmap'),
				15 =>esc_html__('15','neko-gmap'),
				14 =>esc_html__('14','neko-gmap'),
				13 =>esc_html__('13','neko-gmap'),
				12 =>esc_html__('12','neko-gmap'),
				11 =>esc_html__('11','neko-gmap'),
				10 =>esc_html__('10','neko-gmap'),
				9  =>esc_html__('9','neko-gmap'),
				8  =>esc_html__('8','neko-gmap'),
				7  =>esc_html__('7','neko-gmap'),
				6  =>esc_html__('6','neko-gmap'),
				5  =>esc_html__('5','neko-gmap'),
				4  =>esc_html__('4','neko-gmap'),
				3  =>esc_html__('3','neko-gmap'),
				2  =>esc_html__('2','neko-gmap'),
				),

			array(
				'name'=> $title_zoommap,
				'desc'=> $desc_zoommap,
				'std'=> '', 
				'class' => 'no-fancy'
				)
			);

		$my_meta->Finish();




	}

	/**
	 * Add Neko gmap marker option metabox.
	 *
	 * @since    1.0.0
	 */
	public function create_gmapmarkeroption_metabox(){

		$config = array(
			'id'             => 'neko_gmap_marker_option_metabox', 
			'title'          => esc_html__('Google map marker settings', 'neko-gmap'),
			'pages'          => array('neko-gmap'), 
			'context'        => 'normal',  
			'priority'       => 'high',                         
			'fields'         => array(),                     
			'local_images'   => false,                        
			'use_with_theme' => plugins_url() . '/neko-gmap/includes/libs/neko-metabox-generator/engine'
			);

		$prefix = 'neko_gmap_';

		/**
		* Initiate your meta box
		*/
		$my_meta =  new Neko_Gmap_Meta_extends_Class($config);


		/**
		* Add fields to your meta box
		*/
		$title = esc_html__('title', 'neko-gmap');
		$address = esc_html__('address', 'neko-gmap');
		$desc_address  = esc_html__( 'eg : 55 Rue du Faubourg Saint-Honoré, 75008 Paris France', 'neko-gmap' );
		$latitude = esc_html__('latitude', 'neko-gmap');
		$longitude = esc_html__('longitude', 'neko-gmap');
		$marker_image = esc_html__('Set the marker Image', 'neko-gmap');

		$repeater_fields[] = $my_meta->addText($prefix.'re_title_marker',array('name'=> $title),true);
		$repeater_fields[] = $my_meta->addText($prefix.'re_address_marker',array('name'=> $address, 'desc' => $desc_address ), true);
		$repeater_fields[] = $my_meta->addText($prefix.'re_latitude_marker',array('name'=> $latitude ),true);
		$repeater_fields[] = $my_meta->addText($prefix.'re_longitude_marker',array('name'=> $longitude ),true);
		$repeater_fields[] = $my_meta->addImage($prefix.'re_image_marker',array('name'=> $marker_image), true);


		$my_meta->addRepeaterBlock($prefix.'re_marker',array('inline' => true, 'name' => 'Add title, address and gps coordinates for each marker','fields' => $repeater_fields));




		$my_meta->Finish();


	}
}

