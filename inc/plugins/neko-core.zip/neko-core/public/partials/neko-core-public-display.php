<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       http://little-neko.com
 * @since      1.0.0
 *
 * @package    Neko_Core
 * @subpackage Neko_Core/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
