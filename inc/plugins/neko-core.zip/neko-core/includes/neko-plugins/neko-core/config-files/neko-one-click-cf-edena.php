<?php
defined( 'ABSPATH' ) or die( 'You cannot access this script directly' );

/** All plugins for this theme 
 * array('name' => 'Visual Composer', 'classes' => '', 'functions' => '', 'constants' => 'WPB_VC_VERSION')
 * array('name' => 'Visual Composer Clipboard', 'classes' => '', 'functions' => 'vc_clipboard', 'constants' => '')
 * array('name' => 'Contact form 7', 'classes' => '', 'functions' => '', 'constants' => 'WPCF7_VERSION')
 * array('name' => 'Tweetscroll widget', 'classes' => '', 'functions' => 'pi_tweet_scroll', 'constants' => '')
 * array('name' => 'Post types order', 'classes' => '', 'functions' => '', 'constants' => 'CPTPATH')
 * array('name' => 'Revolution slider', 'classes' => '', 'functions' => 'set_revslider_as_theme', 'constants' => '')
 * array('name' => 'Neko portfolio', 'classes' => 'Neko_Portfolio', 'functions' => '', 'constants' => '')
 * array('name' => 'Neko pricing tables', 'classes' => 'Neko_Pricing_Tables', 'functions' => '', 'constants' => '')
 * array('name' => 'Wp owl carousel', 'classes' => 'Wp_Owl_Carousel', 'functions' => '', 'constants' => '')
 * array('name' => 'Neko SLider', 'classes' => 'Neko_Slider', 'functions' => '', 'constants' => '')
 * array('name' => 'Neko team', 'classes' => 'Neko_Team', 'functions' => '', 'constants' => '')
 * array('name' => 'Neko gmap', 'classes' => 'Neko_Gmap', 'functions' => '', 'constants' => '')
 * array('name' => 'Neko Vc Addons', 'classes' => 'Neko_Vcaddons', 'functions' => '', 'constants' => '')
 * array('name' => 'Flickr badges widget', 'classes' => 'Flickr_Badges_Widget', 'functions' => '', 'constants' => '')
 * array('name' => 'Woocommerce', 'classes' => 'WooCommerce', 'functions' => '', 'constants' => '')
 */

if(!function_exists('neko_register_oneclickinstall')){
	function neko_register_oneclickinstall() {
		$neko_one_click_cf = array(

		/* END DEMO 01 */	
		'edena-demo-1' => array(
				'name' => 'Edena Original',
				'img'  => 'screenshot-original.jpg',
				'urldemo' => 'http://wp-themes-premium.little-neko.com/edena-demo-01/',

				'sidebars_settings' => '',
				'widgets_settings' => 'wp-themes-premium.little-neko.com-edena-demo-01-widgets.txt',
				
				'plugins' => array(
					array('name' => 'Visual Composer', 'classes' => '', 'functions' => '', 'constants' => 'WPB_VC_VERSION'),
					array('name' => 'Visual Composer Clipboard', 'classes' => '', 'functions' => 'vc_clipboard', 'constants' => ''),
					array('name' => 'Revolution slider', 'classes' => '', 'functions' => 'set_revslider_as_theme', 'constants' => ''),
					array('name' => 'Neko portfolio', 'classes' => 'Neko_Portfolio', 'functions' => '', 'constants' => ''),
					array('name' => 'Neko pricing tables', 'classes' => 'Neko_Pricing_Tables', 'functions' => '', 'constants' => ''),
					array('name' => 'Neko Slider', 'classes' => 'Neko_Slider', 'functions' => '', 'constants' => ''),
					array('name' => 'Neko team', 'classes' => 'Neko_Team', 'functions' => '', 'constants' => ''),
					array('name' => 'Neko gmap', 'classes' => 'Neko_Gmap', 'functions' => '', 'constants' => ''),
					array('name' => 'Neko Vc Addons', 'classes' => 'Neko_Vcaddons', 'functions' => '', 'constants' => ''),
					array('name' => 'Post types order', 'classes' => '', 'functions' => '', 'constants' => 'CPTPATH'),
					array('name' => 'Contact form 7', 'classes' => '', 'functions' => '', 'constants' => 'WPCF7_VERSION')
				),

				'dummycontent' =>'edenademo01-default.wordpress.2016-03-08-BLUR.xml',
				'skin'         =>'neko-edena-demo-01.json',

				'taxmetabosoptions' => array(

					/* NEko Portfolios */

					'grid/neko_portfolio_category' => 'a:7:{s:30:"neko_portfolio_portfolio_style";s:1:"1";s:31:"neko_portfolio_portfolio_layout";s:1:"2";s:35:"neko_portfolio_portfolio_hover_type";s:1:"3";s:30:"neko_portfolio_portfolio_title";s:1:"0";s:32:"neko_portfolio_portfolio_excerpt";s:1:"1";s:35:"neko_portfolio_portfolio_filterable";s:1:"0";s:37:"neko_portfolio_portfolio_enhancedzoom";s:1:"0";}',	

					'grid-3-columns/neko_portfolio_category' => 'a:7:{s:30:"neko_portfolio_portfolio_style";s:1:"1";s:31:"neko_portfolio_portfolio_layout";s:1:"3";s:35:"neko_portfolio_portfolio_hover_type";s:1:"1";s:30:"neko_portfolio_portfolio_title";s:1:"1";s:32:"neko_portfolio_portfolio_excerpt";s:1:"1";s:35:"neko_portfolio_portfolio_filterable";s:1:"0";s:37:"neko_portfolio_portfolio_enhancedzoom";s:1:"0";}',	

					'grid-4-columns/neko_portfolio_category' => 'a:7:{s:30:"neko_portfolio_portfolio_style";s:1:"1";s:31:"neko_portfolio_portfolio_layout";s:1:"4";s:35:"neko_portfolio_portfolio_hover_type";s:1:"2";s:30:"neko_portfolio_portfolio_title";s:1:"1";s:32:"neko_portfolio_portfolio_excerpt";s:1:"0";s:35:"neko_portfolio_portfolio_filterable";s:1:"0";s:37:"neko_portfolio_portfolio_enhancedzoom";s:1:"0";}',	

					'grid-4-columns-filterable/neko_portfolio_category' => 'a:7:{s:30:"neko_portfolio_portfolio_style";s:1:"1";s:31:"neko_portfolio_portfolio_layout";s:1:"4";s:35:"neko_portfolio_portfolio_hover_type";s:1:"2";s:30:"neko_portfolio_portfolio_title";s:1:"1";s:32:"neko_portfolio_portfolio_excerpt";s:1:"1";s:35:"neko_portfolio_portfolio_filterable";s:1:"1";s:37:"neko_portfolio_portfolio_enhancedzoom";s:1:"0";}',

					'grid-6-columns/neko_portfolio_category' => 'a:7:{s:30:"neko_portfolio_portfolio_style";s:1:"1";s:31:"neko_portfolio_portfolio_layout";s:1:"6";s:35:"neko_portfolio_portfolio_hover_type";s:1:"1";s:30:"neko_portfolio_portfolio_title";s:1:"0";s:32:"neko_portfolio_portfolio_excerpt";s:1:"0";s:35:"neko_portfolio_portfolio_filterable";s:1:"0";s:37:"neko_portfolio_portfolio_enhancedzoom";s:1:"0";}',	
					
					'masonry/neko_portfolio_category' => 'a:7:{s:30:"neko_portfolio_portfolio_style";s:1:"4";s:31:"neko_portfolio_portfolio_layout";s:1:"3";s:35:"neko_portfolio_portfolio_hover_type";s:1:"1";s:30:"neko_portfolio_portfolio_title";s:1:"0";s:32:"neko_portfolio_portfolio_excerpt";s:1:"0";s:35:"neko_portfolio_portfolio_filterable";s:1:"1";s:37:"neko_portfolio_portfolio_enhancedzoom";s:1:"0";}',

					'masonry-4-columns/neko_portfolio_category' => 'a:7:{s:30:"neko_portfolio_portfolio_style";s:1:"4";s:31:"neko_portfolio_portfolio_layout";s:1:"4";s:35:"neko_portfolio_portfolio_hover_type";s:1:"2";s:30:"neko_portfolio_portfolio_title";s:1:"0";s:32:"neko_portfolio_portfolio_excerpt";s:1:"0";s:35:"neko_portfolio_portfolio_filterable";s:1:"0";s:37:"neko_portfolio_portfolio_enhancedzoom";s:1:"0";}',	

					'masonry-6-columns/neko_portfolio_category' => 'a:7:{s:30:"neko_portfolio_portfolio_style";s:1:"4";s:31:"neko_portfolio_portfolio_layout";s:1:"6";s:35:"neko_portfolio_portfolio_hover_type";s:1:"3";s:30:"neko_portfolio_portfolio_title";s:1:"0";s:32:"neko_portfolio_portfolio_excerpt";s:1:"0";s:35:"neko_portfolio_portfolio_filterable";s:1:"0";s:37:"neko_portfolio_portfolio_enhancedzoom";s:1:"0";}',	

					'mosaic-3-columns/neko_portfolio_category' => 'a:7:{s:30:"neko_portfolio_portfolio_style";s:1:"4";s:31:"neko_portfolio_portfolio_layout";s:1:"3";s:35:"neko_portfolio_portfolio_hover_type";s:1:"1";s:30:"neko_portfolio_portfolio_title";s:1:"0";s:32:"neko_portfolio_portfolio_excerpt";s:1:"0";s:35:"neko_portfolio_portfolio_filterable";s:1:"0";s:37:"neko_portfolio_portfolio_enhancedzoom";s:1:"0";}',

					'mosaic-4-columns/neko_portfolio_category' => 'a:7:{s:30:"neko_portfolio_portfolio_style";s:1:"4";s:31:"neko_portfolio_portfolio_layout";s:1:"4";s:35:"neko_portfolio_portfolio_hover_type";s:1:"3";s:30:"neko_portfolio_portfolio_title";s:1:"0";s:32:"neko_portfolio_portfolio_excerpt";s:1:"0";s:35:"neko_portfolio_portfolio_filterable";s:1:"0";s:37:"neko_portfolio_portfolio_enhancedzoom";s:1:"0";}',

					'mosaic-4-columns-filterable/neko_portfolio_category' => 'a:7:{s:30:"neko_portfolio_portfolio_style";s:1:"4";s:31:"neko_portfolio_portfolio_layout";s:1:"4";s:35:"neko_portfolio_portfolio_hover_type";s:1:"2";s:30:"neko_portfolio_portfolio_title";s:1:"0";s:32:"neko_portfolio_portfolio_excerpt";s:1:"0";s:35:"neko_portfolio_portfolio_filterable";s:1:"1";s:37:"neko_portfolio_portfolio_enhancedzoom";s:1:"0";}',

					'mosaic-6-columns/neko_portfolio_category' => 'a:7:{s:30:"neko_portfolio_portfolio_style";s:1:"4";s:31:"neko_portfolio_portfolio_layout";s:1:"6";s:35:"neko_portfolio_portfolio_hover_type";s:1:"2";s:30:"neko_portfolio_portfolio_title";s:1:"0";s:32:"neko_portfolio_portfolio_excerpt";s:1:"0";s:35:"neko_portfolio_portfolio_filterable";s:1:"0";s:37:"neko_portfolio_portfolio_enhancedzoom";s:1:"0";}',



					/* NEko Pricing table */
					'pricing-table-default/neko_pricing_tables_groups' => 'a:1:{s:30:"neko_pricing_table_group_theme";s:15:"neko_pt_style_1";}',

					'pricing-table-style-2/neko_pricing_tables_groups' => 'a:1:{s:30:"neko_pricing_table_group_theme";s:15:"neko_pt_style_2";}',

					'pricing-table-style-3/neko_pricing_tables_groups' => 'a:1:{s:30:"neko_pricing_table_group_theme";s:15:"neko_pt_style_3";}',

					'pricing-table-style-4/neko_pricing_tables_groups' => 'a:1:{s:30:"neko_pricing_table_group_theme";s:15:"neko_pt_style_4";}',

					'pricing-table-style-5/neko_pricing_tables_groups' => 'a:1:{s:30:"neko_pricing_table_group_theme";s:15:"neko_pt_style_5";}',

					'pricing-table-style-6/neko_pricing_tables_groups' => 'a:1:{s:30:"neko_pricing_table_group_theme";s:15:"neko_pt_style_6";}',

					'pricing-table-style-7/neko_pricing_tables_groups' => 'a:1:{s:30:"neko_pricing_table_group_theme";s:15:"neko_pt_style_7";}',

					/* NEko team */
					'team-rounded/neko_team_category' => 'a:7:{s:22:"neko_team_display_type";s:1:"6";s:24:"neko_team_display_skills";s:1:"0";s:30:"neko_team_display_skills_value";s:1:"0";s:25:"neko_team_display_content";s:1:"0";s:23:"neko_team_display_email";s:1:"1";s:24:"neko_team_display_social";s:1:"0";s:27:"neko_team_social_icon_style";s:1:"0";}',

					'team-mosaic/neko_team_category' => 'a:7:{s:22:"neko_team_display_type";s:1:"2";s:24:"neko_team_display_skills";s:1:"1";s:30:"neko_team_display_skills_value";s:1:"1";s:25:"neko_team_display_content";s:1:"0";s:23:"neko_team_display_email";s:1:"1";s:24:"neko_team_display_social";s:1:"1";s:27:"neko_team_social_icon_style";s:1:"1";}',

					'team-columns-no-padding/neko_team_category' => 'a:7:{s:22:"neko_team_display_type";s:1:"4";s:24:"neko_team_display_skills";s:1:"0";s:30:"neko_team_display_skills_value";s:1:"0";s:25:"neko_team_display_content";s:1:"0";s:23:"neko_team_display_email";s:1:"1";s:24:"neko_team_display_social";s:1:"1";s:27:"neko_team_social_icon_style";s:1:"1";}',

					'team-rollover-no-padding/neko_team_category' => 'a:7:{s:22:"neko_team_display_type";s:1:"3";s:24:"neko_team_display_skills";s:1:"0";s:30:"neko_team_display_skills_value";s:1:"0";s:25:"neko_team_display_content";s:1:"1";s:23:"neko_team_display_email";s:1:"0";s:24:"neko_team_display_social";s:1:"1";s:27:"neko_team_social_icon_style";s:1:"1";}',

					'team-1/neko_team_category' => 'a:7:{s:22:"neko_team_display_type";s:1:"3";s:24:"neko_team_display_skills";s:1:"0";s:30:"neko_team_display_skills_value";s:1:"0";s:25:"neko_team_display_content";s:1:"1";s:23:"neko_team_display_email";s:1:"0";s:24:"neko_team_display_social";s:1:"1";s:27:"neko_team_social_icon_style";s:1:"1";}',					

					'team-2/neko_team_category' => 'a:7:{s:22:"neko_team_display_type";s:1:"0";s:24:"neko_team_display_skills";s:1:"0";s:30:"neko_team_display_skills_value";s:1:"0";s:25:"neko_team_display_content";s:1:"0";s:23:"neko_team_display_email";s:1:"0";s:24:"neko_team_display_social";s:1:"0";s:27:"neko_team_social_icon_style";s:1:"0";}',	


					/* NEko Slider */
					'home-slider-testimonials/neko-sliders' => 'a:12:{s:16:"neko_slider_skin";s:19:"neko-slider-theme-1";s:17:"neko_slider_items";s:1:"1";s:22:"neko_slider_slidespeed";s:3:"200";s:27:"neko_slider_transitionstyle";s:5:"slide";s:22:"neko_slider_navigation";s:4:"true";s:30:"neko_slider_navigationTextPrev";s:33:"<i class=neko-icon-glyph-205></i>";s:30:"neko_slider_navigationTextNext";s:33:"<i class=neko-icon-glyph-204></i>";s:22:"neko_slider_pagination";s:4:"true";s:29:"neko_slider_paginationnumbers";s:5:"false";s:22:"neko_slider_autoheight";s:5:"false";s:20:"neko_slider_autoplay";s:5:"false";s:25:"neko_slider_imgresponsive";s:5:"false";}',

					'home-slider-2/neko-sliders' => 'a:12:{s:16:"neko_slider_skin";s:25:"neko-slider-theme-default";s:17:"neko_slider_items";s:1:"1";s:22:"neko_slider_slidespeed";s:3:"200";s:27:"neko_slider_transitionstyle";s:5:"slide";s:22:"neko_slider_navigation";s:5:"false";s:30:"neko_slider_navigationTextPrev";s:3:"←";s:30:"neko_slider_navigationTextNext";s:3:"→";s:22:"neko_slider_pagination";s:4:"true";s:29:"neko_slider_paginationnumbers";s:5:"false";s:22:"neko_slider_autoheight";s:5:"false";s:20:"neko_slider_autoplay";s:5:"false";s:25:"neko_slider_imgresponsive";s:4:"true";}',	

					'logo-slider/neko-sliders' => 'a:12:{s:16:"neko_slider_skin";s:25:"neko-slider-theme-default";s:17:"neko_slider_items";s:1:"4";s:22:"neko_slider_slidespeed";s:3:"200";s:27:"neko_slider_transitionstyle";s:5:"slide";s:22:"neko_slider_navigation";s:5:"false";s:30:"neko_slider_navigationTextPrev";s:3:"←";s:30:"neko_slider_navigationTextNext";s:3:"→";s:22:"neko_slider_pagination";s:4:"true";s:29:"neko_slider_paginationnumbers";s:5:"false";s:22:"neko_slider_autoheight";s:5:"false";s:20:"neko_slider_autoplay";s:5:"false";s:25:"neko_slider_imgresponsive";s:4:"true";}',

					'about-us-slider/neko-sliders' => 'a:12:{s:16:"neko_slider_skin";s:19:"neko-slider-theme-1";s:17:"neko_slider_items";s:1:"1";s:22:"neko_slider_slidespeed";s:3:"200";s:27:"neko_slider_transitionstyle";s:5:"slide";s:22:"neko_slider_navigation";s:4:"true";s:30:"neko_slider_navigationTextPrev";s:3:"←";s:30:"neko_slider_navigationTextNext";s:3:"→";s:22:"neko_slider_pagination";s:4:"true";s:29:"neko_slider_paginationnumbers";s:5:"false";s:22:"neko_slider_autoheight";s:4:"true";s:20:"neko_slider_autoplay";s:5:"false";s:25:"neko_slider_imgresponsive";s:5:"false";}',																

				)
		    ),  
		/* END DEMO 01 */

		/* Edena light */
		'edena-light' => array(
				'name' => 'Edena Light',
				'img'  => 'screenshot-demo-light.jpg',
				'urldemo' => 'http://wp-themes-premium.little-neko.com/edena-demo-01/',

				'sidebars_settings' => '',
				'widgets_settings' => 'wp-themes-premium.little-neko.com-edena-demo-03-widgets.txt',
				
				'plugins' => array(
					array('name' => 'Visual Composer', 'classes' => '', 'functions' => '', 'constants' => 'WPB_VC_VERSION'),
					array('name' => 'Visual Composer Clipboard', 'classes' => '', 'functions' => 'vc_clipboard', 'constants' => ''),
					array('name' => 'Revolution slider', 'classes' => '', 'functions' => 'set_revslider_as_theme', 'constants' => ''),
					array('name' => 'Neko portfolio', 'classes' => 'Neko_Portfolio', 'functions' => '', 'constants' => ''),
					array('name' => 'Neko pricing tables', 'classes' => 'Neko_Pricing_Tables', 'functions' => '', 'constants' => ''),
					array('name' => 'Neko Slider', 'classes' => 'Neko_Slider', 'functions' => '', 'constants' => ''),
					array('name' => 'Neko team', 'classes' => 'Neko_Team', 'functions' => '', 'constants' => ''),
					array('name' => 'Neko gmap', 'classes' => 'Neko_Gmap', 'functions' => '', 'constants' => ''),
					array('name' => 'Neko Vc Addons', 'classes' => 'Neko_Vcaddons', 'functions' => '', 'constants' => ''),
					array('name' => 'Post types order', 'classes' => '', 'functions' => '', 'constants' => 'CPTPATH'),
					array('name' => 'Contact form 7', 'classes' => '', 'functions' => '', 'constants' => 'WPCF7_VERSION')
				),

				'dummycontent' =>'edena-demo-light.xml',
				'skin'         =>'neko-edena-demo-light.json',

				'taxmetabosoptions' => array(

					/* Neko Portfolios */
					'masonry-4-columns/neko_portfolio_category' => 'a:7:{s:30:"neko_portfolio_portfolio_style";s:1:"4";s:31:"neko_portfolio_portfolio_layout";s:1:"4";s:35:"neko_portfolio_portfolio_hover_type";s:1:"1";s:30:"neko_portfolio_portfolio_title";s:1:"0";s:32:"neko_portfolio_portfolio_excerpt";s:1:"0";s:35:"neko_portfolio_portfolio_filterable";s:1:"0";s:37:"neko_portfolio_portfolio_enhancedzoom";s:1:"0";}',


					
					/* Neko Pricing table */
					'pricing-table/neko_pricing_tables_groups' => 'a:1:{s:30:"neko_pricing_table_group_theme";s:15:"neko_pt_style_4";}',

					/* Neko team */
					'team/neko_team_category' => 'a:7:{s:22:"neko_team_display_type";s:1:"3";s:24:"neko_team_display_skills";s:1:"0";s:30:"neko_team_display_skills_value";s:1:"0";s:25:"neko_team_display_content";s:1:"1";s:23:"neko_team_display_email";s:1:"0";s:24:"neko_team_display_social";s:1:"1";s:27:"neko_team_social_icon_style";s:1:"1";}',

					/* Neko Slider */
					'home-slider-2/neko-sliders' => 'a:12:{s:16:"neko_slider_skin";s:25:"neko-slider-theme-default";s:17:"neko_slider_items";s:1:"1";s:22:"neko_slider_slidespeed";s:3:"200";s:27:"neko_slider_transitionstyle";s:5:"slide";s:22:"neko_slider_navigation";s:5:"false";s:30:"neko_slider_navigationTextPrev";s:3:"←";s:30:"neko_slider_navigationTextNext";s:3:"→";s:22:"neko_slider_pagination";s:4:"true";s:29:"neko_slider_paginationnumbers";s:5:"false";s:22:"neko_slider_autoheight";s:5:"false";s:20:"neko_slider_autoplay";s:5:"false";s:25:"neko_slider_imgresponsive";s:4:"true";}',
					
					'home-slider-testimonials/neko-sliders' => 'a:12:{s:16:"neko_slider_skin";s:19:"neko-slider-theme-1";s:17:"neko_slider_items";s:1:"1";s:22:"neko_slider_slidespeed";s:3:"200";s:27:"neko_slider_transitionstyle";s:5:"slide";s:22:"neko_slider_navigation";s:4:"true";s:30:"neko_slider_navigationTextPrev";s:3:"←";s:30:"neko_slider_navigationTextNext";s:3:"→";s:22:"neko_slider_pagination";s:4:"true";s:29:"neko_slider_paginationnumbers";s:5:"false";s:22:"neko_slider_autoheight";s:5:"false";s:20:"neko_slider_autoplay";s:5:"false";s:25:"neko_slider_imgresponsive";s:4:"true";}',												
				)
		    ), 
		/* END Edena light */

		/* END DEMO Creative green skin */
		'edena-dcreative-green-skin' => array(
				'name' => 'Edena Creative green skin',
				'img'  => 'screenshot-demo-creative-green-skin.jpg',
				'urldemo' => 'http://wp-themes-premium.little-neko.com/edena-creative-green-skin',

				'sidebars_settings' => '',
				'widgets_settings' => 'wp-themes-premium.little-neko.com-edena-demo-05-widgets.txt',
				
				'plugins' => array(
					array('name' => 'Visual Composer', 'classes' => '', 'functions' => '', 'constants' => 'WPB_VC_VERSION'),
					array('name' => 'Visual Composer Clipboard', 'classes' => '', 'functions' => 'vc_clipboard', 'constants' => ''),
					array('name' => 'Revolution slider', 'classes' => '', 'functions' => 'set_revslider_as_theme', 'constants' => ''),
					array('name' => 'Neko portfolio', 'classes' => 'Neko_Portfolio', 'functions' => '', 'constants' => ''),
					array('name' => 'Neko pricing tables', 'classes' => 'Neko_Pricing_Tables', 'functions' => '', 'constants' => ''),
					array('name' => 'Neko Slider', 'classes' => 'Neko_Slider', 'functions' => '', 'constants' => ''),
					array('name' => 'Neko team', 'classes' => 'Neko_Team', 'functions' => '', 'constants' => ''),
					array('name' => 'Neko gmap', 'classes' => 'Neko_Gmap', 'functions' => '', 'constants' => ''),
					array('name' => 'Neko Vc Addons', 'classes' => 'Neko_Vcaddons', 'functions' => '', 'constants' => ''),
					array('name' => 'Post types order', 'classes' => '', 'functions' => '', 'constants' => 'CPTPATH'),
					array('name' => 'Contact form 7', 'classes' => '', 'functions' => '', 'constants' => 'WPCF7_VERSION')
				),

				'dummycontent' =>'edena-creative-green-skin-install.xml',
				'skin'         =>'neko-edena-creative-green-skin.json',

				'taxmetabosoptions' => array(

					/* Neko Portfolios */
					'masonry/neko_portfolio_category' => 'a:7:{s:30:"neko_portfolio_portfolio_style";s:1:"4";s:31:"neko_portfolio_portfolio_layout";s:1:"3";s:35:"neko_portfolio_portfolio_hover_type";s:1:"1";s:30:"neko_portfolio_portfolio_title";s:1:"0";s:32:"neko_portfolio_portfolio_excerpt";s:1:"0";s:35:"neko_portfolio_portfolio_filterable";s:1:"0";s:37:"neko_portfolio_portfolio_enhancedzoom";s:1:"0";}',

					'mosaic-6-columns/neko_portfolio_category' => 'a:7:{s:30:"neko_portfolio_portfolio_style";s:1:"3";s:31:"neko_portfolio_portfolio_layout";s:1:"6";s:35:"neko_portfolio_portfolio_hover_type";s:1:"1";s:30:"neko_portfolio_portfolio_title";s:1:"0";s:32:"neko_portfolio_portfolio_excerpt";s:1:"0";s:35:"neko_portfolio_portfolio_filterable";s:1:"0";s:37:"neko_portfolio_portfolio_enhancedzoom";s:1:"0";}',	
					
					/* Neko Pricing table */
					'pricing-table/neko_pricing_tables_groups' => 'a:1:{s:30:"neko_pricing_table_group_theme";s:15:"neko_pt_style_2";}',

					/* Neko team */
					'team/neko_team_category' => 'a:7:{s:22:"neko_team_display_type";s:1:"0";s:24:"neko_team_display_skills";s:1:"0";s:30:"neko_team_display_skills_value";s:1:"0";s:25:"neko_team_display_content";s:1:"0";s:23:"neko_team_display_email";s:1:"0";s:24:"neko_team_display_social";s:1:"0";s:27:"neko_team_social_icon_style";s:1:"0";}',

					/* Neko Slider */
					'slider-about/neko-sliders' => 'a:12:{s:16:"neko_slider_skin";s:25:"neko-slider-theme-default";s:17:"neko_slider_items";s:1:"1";s:22:"neko_slider_slidespeed";s:3:"200";s:27:"neko_slider_transitionstyle";s:5:"slide";s:22:"neko_slider_navigation";s:5:"false";s:30:"neko_slider_navigationTextPrev";s:3:"←";s:30:"neko_slider_navigationTextNext";s:3:"→";s:22:"neko_slider_pagination";s:4:"true";s:29:"neko_slider_paginationnumbers";s:5:"false";s:22:"neko_slider_autoheight";s:5:"false";s:20:"neko_slider_autoplay";s:5:"false";s:25:"neko_slider_imgresponsive";s:4:"true";}',
															
				)
		    ), 
		/* END DEMO Creative green skin */

		/* END shop */
		'edena-shop' => array(
				'name' => 'Edena Shop demo',
				'img'  => 'screenshot-demo-shop.jpg',
				'urldemo' => 'http://wp-themes-premium.little-neko.com/edena-demo-shop/',

				'sidebars_settings' => '',
				'widgets_settings' => 'wp-themes-premium.little-neko.com-edena-shop-widgets.txt',
				
				'plugins' => array(
					array('name' => 'Visual Composer', 'classes' => '', 'functions' => '', 'constants' => 'WPB_VC_VERSION'),
					array('name' => 'Visual Composer Clipboard', 'classes' => '', 'functions' => 'vc_clipboard', 'constants' => ''),
					array('name' => 'Neko Vc Addons', 'classes' => 'Neko_Vcaddons', 'functions' => '', 'constants' => ''),
					array('name' => 'Revolution slider', 'classes' => '', 'functions' => 'set_revslider_as_theme', 'constants' => ''),
					array('name' => 'Woocommerce', 'classes' => 'WooCommerce', 'functions' => '', 'constants' => ''),
					array('name' => 'Post types order', 'classes' => '', 'functions' => '', 'constants' => 'CPTPATH'),
					array('name' => 'Contact form 7', 'classes' => '', 'functions' => '', 'constants' => 'WPCF7_VERSION')
				),

				'dummycontent' =>'edena-demo-shop-install.xml',
				'skin'         =>'neko-edena-demo-shop-install.json',

				'taxmetabosoptions' => array()

		    ), 
			/* END shop */


		/* END DEMO Black & White */
		'edena-black-white' => array(
				'name' => 'Edena Black & White',
				'img'  => 'screenshot-demo-black-and-white.jpg',
				'urldemo' => 'http://wp-themes-premium.little-neko.com/edena-demo-black-and-white/',

				'sidebars_settings' => '',
				'widgets_settings' => 'wp-themes-premium.little-neko.com-edena-demo-black-and-white-install-widgets.txt',
				
				'plugins' => array(
					array('name' => 'Visual Composer', 'classes' => '', 'functions' => '', 'constants' => 'WPB_VC_VERSION'),
					array('name' => 'Visual Composer Clipboard', 'classes' => '', 'functions' => 'vc_clipboard', 'constants' => ''),
					array('name' => 'Neko Vc Addons', 'classes' => 'Neko_Vcaddons', 'functions' => '', 'constants' => ''),
					array('name' => 'Revolution slider', 'classes' => '', 'functions' => 'set_revslider_as_theme', 'constants' => ''),
					array('name' => 'Post types order', 'classes' => '', 'functions' => '', 'constants' => 'CPTPATH'),
					array('name' => 'Contact form 7', 'classes' => '', 'functions' => '', 'constants' => 'WPCF7_VERSION')
				),

				'dummycontent' =>'edena-demo-black-and-white-install.xml',
				'skin'         =>'neko-edena-demo-black-white-install.json',

				'taxmetabosoptions' => array(

					/* Neko Portfolios */
					'Mosaic-6-columns/neko_portfolio_category' => 'a:7:{s:30:"neko_portfolio_portfolio_style";s:1:"3";s:31:"neko_portfolio_portfolio_layout";s:1:"6";s:35:"neko_portfolio_portfolio_hover_type";s:1:"3";s:30:"neko_portfolio_portfolio_title";s:1:"0";s:32:"neko_portfolio_portfolio_excerpt";s:1:"0";s:35:"neko_portfolio_portfolio_filterable";s:1:"0";s:37:"neko_portfolio_portfolio_enhancedzoom";s:1:"0";}',

					/* Neko Pricing table */
					'pricing-table/neko_pricing_tables_groups' => 'a:1:{s:30:"neko_pricing_table_group_theme";s:15:"neko_pt_style_4";}',

					/* Neko team */
					'team/neko_team_category' => 'a:7:{s:22:"neko_team_display_type";s:1:"2";s:24:"neko_team_display_skills";s:1:"1";s:30:"neko_team_display_skills_value";s:1:"1";s:25:"neko_team_display_content";s:1:"1";s:23:"neko_team_display_email";s:1:"1";s:24:"neko_team_display_social";s:1:"1";s:27:"neko_team_social_icon_style";s:1:"0";}',
					),

		    ), 
			/* END DEMO Black & White */	


		); /* End main array */

		return $neko_one_click_cf;	
	}
}