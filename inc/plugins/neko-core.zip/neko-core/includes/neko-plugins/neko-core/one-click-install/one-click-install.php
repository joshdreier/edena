<?php
defined( 'ABSPATH' ) or die( 'You cannot access this script directly' );

if (!class_exists('Neko_One_Click_Install')) {

	$dir = ( !defined('__DIR__') ) ? dirname(__FILE__) : __DIR__ ; 
	require_once ( plugin_dir_path( $dir ) . 'neko-theme-tool.php' );

	class Neko_One_Click_Install extends Neko_Theme_Tool{

		private $_mainConfig = array();
		private $_pluginConfig = array();

		public function __construct() {

			$current_theme = wp_get_theme();
			
			/* detect child theme for valid config file inclusion */
			if( is_child_theme() ){
				$theme_name = strtolower( $current_theme->parent()->Name );
			}else{
				$theme_name = strtolower( $current_theme->get( 'Name' ) );
			}

			require_once ( plugin_abs_path . 'includes/neko-plugins/neko-core/config-files/neko-one-click-cf-'.$theme_name.'.php' );

			require_once ( plugin_abs_path . 'includes/neko-plugins/neko-core/skin-management/import-skin.php' );
			//require_once (get_template_directory() . '/framework/tgm-plugin-activation/neko-tgm-plugins.php' );

			$this->get_config_files();
		}


		private function get_config_files($config_type = 'main'){
			$this->_mainConfig   =  (is_array(neko_register_oneclickinstall()))?neko_register_oneclickinstall():'error';
			//$this->_pluginConfig =  (is_array(neko_register_required_plugins(true)))?neko_register_required_plugins(true):'error';
		}


		public function one_click_install_view(){

			$demo_number_class = ( sizeof($this->_mainConfig) <= 1 ) ? 'one-demo' : '' ;

			$dir = ( !defined('__DIR__') ) ? dirname(__FILE__) : __DIR__ ; 

			$html ='<div class="demo-selector-wrapper '.esc_attr($demo_number_class).'">';


			/* DEMO INSTALL HELP & REQUIREMENTS */
			$html .='<div class="neko-one-click-info error">
			<h3 class="error-txt">Please make sure to read the following message before installing the demo!!!</h3>

			<p>
			<strong class="error-txt">IMPORTANT: visit this page before installing a demo!</strong>&nbsp;&nbsp;
			<a class="button button-primary" target="_blank" href="'.admin_url( 'themes.php?page=neko-welcome-page&tab=configuration' ).'">Theme configuration page</a>
			</p>
			<br/>	

			<p>
				Installing a Little Neko demo provides pages, posts, theme options, widgets and more. The process can take some time to complete depending on your server configuration and ressources. It is very important to wait until the end of the process without reloading the page. Do not do the process more than once as it will duplicate the imported content.
			</p>

			</div>';
			/* DEMO INSTALL HELP & REQUIREMENTS */


			/* Demo install process */

			$html .='
			<div id="one-click-install-result">
				<div class="neko-oneclick-progressbar">
					<div class="neko-oneclick-progressbar-inner"></div>
				</div>
				<div id="one-click-install-result-info"></div>
				<img src="'. plugin_dir_url( $dir ) . 'assets/img/ajax-loader.gif" id="neko-ajax-loader" alt="">
			</div>
			';

			/* Demo install process */
			foreach ($this->_mainConfig as $key => $value) {

				$all_plugs = '<div class="plugin-needed"><h3>The following plugins are required</h3><div class="plugin-list">';
				$notInstalled =0;
				foreach ($this->_mainConfig[$key]['plugins'] as $key1 => $value1) {

					if(!$this->neko_detect_plugin($value1)){
						$all_plugs .= '<span class="not-installed"> '.$value1['name'].' ('.esc_html__('Not Installed' , 'neko').')</span><br>';
						$notInstalled = 1;
					}else{
						$all_plugs .= '<span class="installed"> '.$value1['name'].'  ('.esc_html__('Installed' , 'neko').')</span><br>';
					}

				}
			
				$blog_id = get_current_blog_id();
				$all_plugs .= '</div><p class="hide_on_mobile">'.esc_html__('Install the required plugins and come back here to install the demo.', 'neko').' <a href="'. admin_url( 'themes.php?page=neko-welcome-page&tab=plugininstall' ).'" title="">Go to the plugin installation page</a></p></div>';


				$html .= '<div class="demoSelector">';
				
				$html .= $all_plugs;

				$html .= '<div class="demo_pics"><img src="' . plugin_dir_url( $dir ) . '_demo-content/demo-pics/'.$value['img'].'" alt=""  width="323"/>';

				$html .= '</div>';

				$html .= '<h3 class="demo-title">'.$value['name'].'</h3>';

				$html .= '<div class="preview">';

				

				$trigger_class =(0 === $notInstalled)?'one-click-install':'tigger-plugin-alert';
		
				$html .='<a href="?page=nekomanager&c='.$key.'" class="'.$trigger_class.' button button-secondary" title="Install this demo" data-demo="'.$key.'" >'.esc_html__('Install' , 'neko').'</a>';


				$html .='&nbsp;<a target="_blank" href="'.$value['urldemo'].'" class="button button-primary">'.esc_html__('Live Preview' , 'neko').'</a>';

	

				$html .= '</div></div>';	
			}



			$html .='</div>';
			echo trim( $html );
		}

		/*
		 * one click install functionalities
		 */
		public function one_click_install($installConf, $switch = null){

			$all_plugs_not_active = '';
			foreach ($this->_mainConfig[$installConf]['plugins'] as $key => $value) {

				if(!$this->neko_detect_plugin($value)){
					$all_plugs_not_active .= '- '.$value['name'].'<br>';
				}
			}	


			if( empty($all_plugs_not_active) ){

				/* Skin install */
				if('sk' == $switch){

					$this->show_message(esc_html__('importing skin ... ( Do not reload this page ! )' , 'neko'), 'updating');

					$skin_importer = new Neko_Skin_Importer();
					$install_skin = $skin_importer->import_skin($this->_mainConfig[$installConf]['skin']);

					$this->show_message(esc_html__('importing content ... ( Do not reload this page ! )' , 'neko'), 'updating');

				}


				/* Dummy content install */
				if('dc' == $switch){

					$install_dummy = $this->import_Dummy_Content(
						$this->_mainConfig[$installConf]['dummycontent'], 
						$this->_mainConfig[$installConf]['taxmetabosoptions'],
						$this->_mainConfig[$installConf]['sidebars_settings'],
						$this->_mainConfig[$installConf]['widgets_settings']
					);

				}

			}else{
				esc_html_e('Error : All the required plugins for this demo are not installed and activated. Please proceed to installation and activation of these missing plugins before intalling demo content! <br/>All necessary plugins are located in the package under plugins folder.<br/><br/> Missing plugins for this demo :<br>' , 'neko').$all_plugs_not_active;
			}

		}



		private function import_Dummy_Content($xml_file_name, $taxometaoption = null, $sidebarsettings = null, $widgetsettings = null){

			global $wpdb;

			add_option('neko_ocimport_performed');

			if ( !defined('WP_LOAD_IMPORTERS') ) define('WP_LOAD_IMPORTERS', true);

	
			if ( ! class_exists('Neko_WP_Import') ) { 

				$class_wp_import = plugin_abs_path . 'includes/neko-plugins/neko-core/cwp-importer/wordpress-importer.php';
				if ( file_exists( $class_wp_import ) ) {
					include $class_wp_import;
				}
			}

			if ( class_exists( 'WP_Importer' ) && class_exists( 'Neko_WP_Import' ) ) {
				
				/* Import XML */
				$wp_imp = new Neko_WP_Import();
				$xml_file_name = sanitize_file_name($xml_file_name);
				$xml_file_path =  plugin_abs_path . 'includes/neko-plugins/neko-core/_demo-content/dummy-content/';

				if ( file_exists( $xml_file_path.$xml_file_name )  ) {

					/* Importer */

					$wp_imp->fetch_attachments = true;
					
					ob_start();
					$wp_imp->import($xml_file_path.$xml_file_name);
					ob_end_clean();	

					/* End importer */

					/* Set Primary Menu */
					$locations = get_theme_mod( 'nav_menu_locations' ); 
					$menus = wp_get_nav_menus(); 

					if( is_array($menus) ) {
						foreach($menus as $menu) { 
							if( $menu->name == 'Menu 1' ) {
								$locations['primary'] = $menu->term_id;
							}
						}
					}
					
					set_theme_mod( 'nav_menu_locations', $locations );
					/* End set Primary Menu */

					/* Home and blog page */
					$home = get_page_by_path( 'home' );
					$blog = get_page_by_path( 'home-blog' );

					if( !empty($home) || !empty($blog) ){
						update_option('show_on_front', 'page');

						if( !empty($home) ){
							update_option('page_on_front',  $home->ID);
						}

						if( !empty($blog) ){
							update_option('page_for_posts', $blog->ID);
						}

					}				
					/* End home and blog page */

					/* Custom sidebars */
					if( !empty($sidebarsettings) ){

						$sidebars = unserialize($sidebarsettings);
						update_option('sbg_sidebars', unserialize($sidebarsettings));

						foreach ($sidebars as $key => $value) {
							register_sidebar(array(
								'name'=>$key,
								'id'=>'default_'.$i,
								'before_widget' => '<div id="%1$s" class="widget %2$s">',
								'after_widget' => '</div>',
								'before_title' => '<div class="heading"><h3>',
								'after_title' => '</h3></div>',
							));
						}
						
					}
					/* End custom sidebars */


					/* Update taxo metabox options */
					if( !empty($taxometaoption) ){

						//echo '<pre>';print_r($taxometaoption);echo '</pre>';

						if(!empty($taxometaoption)){

							foreach ($taxometaoption as $key => $option) {
								$slug_cat = explode('/', $key);
								$terms = get_term_by('slug', $slug_cat[0], $slug_cat[1]);
								$array_option = unserialize($option);
								//echo '<pre>';print_r($terms);echo '</pre>';
								add_option( 'tax_meta_'.$terms->term_id, $array_option );		
							}

						}

					}
					/* End update taxo metabox options */

					/* set up wigets for sidbars or if none create default widgets and default sidebar */

					if( empty($widgetsettings) ){

						$default_widgets = array (

							'sidebar-1' => 
							array (
								0 => 'search-2',
								1 => 'recent-posts-2',
								2 => 'recent-comments-2',
								3 => 'archives-2',
								4 => 'categories-2',
								5 => 'meta-2'
								),
							'footer-area' => 
							array (
								0 => 'recent-posts-2',
								1 => 'categories-2',
								2 => 'archives-2',
								3 => 'meta-2'
								),
						);

						update_option( 'sidebars_widgets', $default_widgets );
					}else{

						require_once ( plugin_abs_path . 'includes/neko-plugins/neko-core/import-widgets/import.php' );

						// OLD $file = get_template_directory() . '/inc/neko-theme-manager/widget-conf/'.$widgetsettings;
						$file = plugin_uri . 'includes/neko-plugins/neko-core/_demo-content/widget-conf/'.$widgetsettings;

						neko_upload_import_file($file);

					}

					/* End set up wigets for sidbars or if none create default widgets and default sidebar */

				}else{
					$this->show_message(esc_html__('Error while importing demo content' , 'neko'), 'error');
				}

				update_option('neko_ocimport_performed', 'yes');
				$this->show_message(esc_html__('Demo content successfully installed. Your Little Neko theme is ready to use!' , 'neko'), 'updated');
				return true;
			}
			return false;
		}				



		private function neko_detect_plugin( $plugins ) {

			

			/** Check for classes */
			if ( !empty( $plugins['classes'] ) ) {
				if ( class_exists( $plugins['classes']  ) ) return true;
			}

			/** Check for functions */
			if ( !empty( $plugins['functions'] ) ) {
				if ( function_exists( $plugins['functions']  ) ) return true;
			}

			/** Check for constants */
			if ( !empty( $plugins['constants'] ) ) {
				if ( defined( $plugins['constants']  ) ) return true;
			}

			/** No class, function or constant found to exist */
			return false;

		}




	}/* end class */
	
}/* end class exist */