<?php
/*
Plugin Name: Multiple Post Thumbnails
Plugin URI: http://wordpress.org/extend/plugins/multiple-post-thumbnails/
Description: Adds the ability to add multiple post thumbnails to a post type.
Version: 1.6
Author: Chris Scott
Author URI: http://voceplatforms.com/
*/

/*  Copyright 2010 Chris Scott (cscott@voceconnect.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
defined( 'ABSPATH' ) or die( 'You cannot access this script directly' );

if (!class_exists('Neko_Theme_Manager')) {

	require_once ( plugin_dir_path( __FILE__ ) . 'neko-theme-tool.php' );


	class Neko_Theme_Manager extends Neko_Theme_Tool{

		private $_activate_quick_install = true;

		public function __construct() {

			add_action("admin_menu", array( $this, 'add_menu'));
			add_action('admin_enqueue_scripts', array( $this, 'neko_enqueue_scripts' ) );	

		}

		/*
		 * builds and adds the admin menu for neko themem manager
		 */
		public function add_menu(){


			if( true ===  $this->_activate_quick_install ){

				
				/*add_theme_page('Neko Quick Install', 'Quick Demo install', 'manage_options', 'nekomanager', array( $this, 'display_admin_manager')  );
				add_theme_page('Neko Import Skin','Import Skin', 'manage_options', 'import-skin', array( $this, 'display_admin_manager' ) );
				add_theme_page('Neko Export Skin', 'Export Skin','manage_options', 'export-skin', array( $this, 'display_admin_manager' ));*/

				add_menu_page('Neko Manager', 'Neko Manager', 'manage_options', 'nekomanager', array( $this, 'display_admin_manager' ), 'dashicons-editor-kitchensink', 81  );
				add_submenu_page('nekomanager', 'Demo install', 'Demo install', 'manage_options', 'nekomanager' );
				add_submenu_page('nekomanager','Import Skin', 'Import Skin','manage_options', 'import-skin', array( $this, 'display_admin_manager' ) );
				add_submenu_page('nekomanager', 'Export Skin', 'Export Skin','manage_options', 'export-skin', array( $this, 'display_admin_manager' )); //array( $this, 'display_admin_manager')

			}else{

				add_menu_page('Neko Manager', 'Neko Manager', 'manage_options', 'export-skin', array( $this, 'display_admin_manager' ), 'dashicons-editor-kitchensink', 81 );
				add_submenu_page('export-skin', 'Export Skin', 'Export Skin','manage_options', 'export-skin', array( $this, 'display_admin_manager' ));
				add_submenu_page('export-skin','Import Skin', 'Import Skin','manage_options', 'import-skin', array( $this, 'display_admin_manager' ) );

				/*add_theme_page('Neko Import Skin','Import Skin', 'manage_options', 'import-skin', array( $this, 'display_admin_manager' ) );
				add_theme_page('Neko Export Skin', 'Export Skin','manage_options', 'export-skin', array( $this, 'display_admin_manager' ));*/
			}



		}

		/*
		 * enqueue scripts and css for neko themem manager 
		 */
		public function neko_enqueue_scripts(){
			wp_enqueue_style( 'neko-theme-manager-admin', plugin_dir_url( __FILE__ ) . 'assets/css/neko-theme-manager.css');
			wp_enqueue_script( 'neko-theme-manager-admin', plugin_dir_url( __FILE__ ) . 'assets/js/neko-theme-manager.js', array( 'jquery' ), '1.0.0', true );
			wp_localize_script( 'neko-theme-manager-admin',  'ajax_object',
				array( 
					'ajaxurl' => admin_url( 'admin-ajax.php' )
					)
				);
		}


		/*
		 * generates views for neko theme manager 
		 */
		public function display_admin_manager($current_demo = null, $switch = null) {

			if (!current_user_can('manage_options'))  {
				wp_die( esc_html__('You do not have sufficient permissions to access this page.', 'neko') );
			}

			if(!defined('DOING_AJAX') || !DOING_AJAX )
				echo '<div id="neko-theme-manager-wrapper" class="wrap clearfix"><h2>'.get_admin_page_title().'</h2>';

			/* one click install */
			if(!empty($_GET['page']) && 'nekomanager' === $_GET['page'] || defined('DOING_AJAX') && DOING_AJAX ){
				
				require_once ( plugin_dir_path( __FILE__ ) . 'one-click-install/one-click-install.php' );

				//MAIN CONFIG
				$one_click_install = new Neko_One_Click_Install();


				if(!empty($current_demo) && is_string($current_demo)){

					$c = sanitize_text_field($current_demo); 
					$switch = sanitize_text_field($switch);
		
					$one_click_install->one_click_install($c, $switch);	


				}else{

					$upload_dir = wp_upload_dir();
					if(!is_writable($upload_dir['basedir'].'/')){
						$this->show_message(esc_html__('Your ulpoad diretory is not writable. Make sure it is before performing a one click install!' , 'neko'), 'error');
					}else{

						if('yes' ===  get_option('neko_ocimport_performed')){
							$this->show_message(esc_html__('You already have performed a one click install. Running this operation again will duplicate the imported content!' , 'neko'), 'error');
						}

						$one_click_install->one_click_install_view();
					}

				}		
				

			/* Skin import */	
			}elseif(!empty($_GET['page']) && 'import-skin' === $_GET['page']){

				require_once ( plugin_dir_path( __FILE__ ) . 'skin-management/import-skin.php' );
				$skin_importer = new Neko_Skin_Importer();

				if ( isset( $_FILES['import'] ) && check_admin_referer( 'neko-customizer-import' ) ) {

					if ( $_FILES['import']['error'] > 0 ) {
						wp_die( 'An error occured.' );
					}else{
						$skin_importer->import_skin($_FILES);	
					}

				}else{
					$skin_importer->import_skin_view();
				}


				
			/* Skin export */	
			}elseif(!empty($_GET['page']) && 'export-skin' === $_GET['page']){

				require_once ( plugin_dir_path( __FILE__ ) . 'skin-management/export-skin.php' );
				$skin_exporter = new Neko_Skin_Exporter();

				$skin_exporter->export_skin_view($echo = true);
		
			}

			echo '</div>';

		}






	}/* end class */
	
}/* end class exist */



if ( is_admin() && !defined('DOING_AJAX') || ( defined('DOING_AJAX') && !DOING_AJAX ) ){
	$neko_theme_manager = new Neko_Theme_Manager;
}

	


