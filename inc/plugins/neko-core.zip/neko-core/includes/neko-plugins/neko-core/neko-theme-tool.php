<?php
defined( 'ABSPATH' ) or die( 'You cannot access this script directly' );
if (!class_exists('Neko_Theme_Tool')) {


	class Neko_Theme_Tool{

		public function __construct() {}
		
		public function show_message($mess, $type){

			echo '<div class="'.$type.'"><p>'.$mess.'</p></div>';

		}


		/*public function is__writable($path) {


			if ($path{strlen($path)-1}=='/') 
				return $this->is__writable($path.uniqid(mt_rand()).'.tmp');
			else if (is_dir($path))
				return $this->is__writable($path.'/'.uniqid(mt_rand()).'.tmp');

			$rm = file_exists($path);
			$f = @fopen($path, 'a');
			if ($f===false)
				return false;
			fclose($f);
			if (!$rm)
				unlink($path);
			return true;
		

		}*/



	}/* end class */
	
}/* end class exist */