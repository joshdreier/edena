<?php
defined( 'ABSPATH' ) or die( 'You cannot access this script directly' );

if (!class_exists('Neko_Skin_Importer')) {
	$dir = ( !defined('__DIR__') ) ? dirname(__FILE__) : __DIR__ ; 
	require_once ( plugin_dir_path( $dir ) . 'neko-theme-tool.php' );

	class Neko_Skin_Importer extends Neko_Theme_Tool{


		public function __construct() {

		}
		

	
		public function import_skin_view(){


			echo '<form method="post" enctype="multipart/form-data">
			'.wp_nonce_field( 'neko-customizer-import' ).'
			<p>Choose a .json file to upload, then click Upload file and import.</p>
			<p>Choose a file from your computer: <input type="file" id="customizer-upload" name="import"></p>
			<p class="submit">
				<input type="submit" name="submit" id="customizer-submit" class="button" value="Upload file and import" >
			</p>
			</form>';

		}

		public function import_skin($skin_file){


			if ( is_array($skin_file)) {

				$is_valid_nonce = ( isset( $_POST[ '_wpnonce' ] ) && wp_verify_nonce( $_POST[ '_wpnonce' ], 'neko-customizer-import' ) );

				if(true === $is_valid_nonce){
					$file_name    = $_FILES['import']['name'];
					$file_content = $_FILES['import']['tmp_name'];

					if ( ! function_exists( 'wp_handle_upload' ) ) require_once( ABSPATH . 'wp-admin/includes/file.php' );
					$uploadedfile = $_FILES['import'];
					$upload_overrides = array( 'test_form' => false );
					$movefile = wp_handle_upload( $uploadedfile, $upload_overrides );
					if ( $movefile ) {
						//print_r( $movefile);exit();
						$file = wp_remote_get( $movefile['url']  );

						if ( is_wp_error( $file ) ) {
							$error_message = $file->get_error_message();
							echo "<div class=\"error\"><p>".esc_html__("Something went wrong").": $error_message</p></div>";
							return;
						} 
						
						$file_size = $file['headers']['content-length'];
						$encode_options = wp_remote_retrieve_body($file);
						$file_name_exploded = explode('.',$file_name);
						unlink($movefile['file']);	
					}	
				}else{
					wp_die( esc_html__('Secuity breach.', 'neko') );
				}

				
			}else{

				$file_content = plugin_uri . 'includes/neko-plugins/neko-core/_demo-content/skins/'.$skin_file;
				$file = wp_remote_get( $file_content );
				$file_size = $file['headers']['content-length'];	
				$encode_options = wp_remote_retrieve_body($file);
				$file_name_exploded = explode('.',$file_content);	
			}
			
			
			$file_ext  = strtolower( end( $file_name_exploded ) );

			if ( ( $file_ext == 'json' ) && ( $file_size < 500000 ) ) {

				$options = json_decode( $encode_options, true ); 

				//echo 'result : '.print_r($options); exit();
				/* The option already exists, we delete it. */
				$option_name = 'thsp_cbp_theme_options' ;

				if ( get_option( $option_name ) !== false ) {
					delete_option( $option_name );
				} 


				/* The option hasn't been added yet. We'll add it with $autoload set to 'no'. */
				$deprecated = null;
				$autoload = 'no';

				if(add_option( $option_name, $options, $deprecated, $autoload)){
					$this->show_message(esc_html__('All options were installed successfully' , 'neko'), 'updated');
				}else{
					$this->show_message(esc_html__('An error occured while restoring your theme option' , 'neko'), 'error');
				}

			} else {
				$this->show_message(esc_html__('Invalid file or file size too big.' , 'neko'), 'error');
			}
		}
		


	}/* end class */
	
}/* end class exist */