<?php
defined( 'ABSPATH' ) or die( 'You cannot access this script directly' );

if (!class_exists('Neko_Skin_Exporter')) {
	$dir = ( !defined(__DIR__) ) ? dirname(__FILE__) : __DIR__ ; 
	require_once ( plugin_dir_path( $dir ) . 'neko-theme-tool.php' );

	class Neko_Skin_Exporter extends Neko_Theme_Tool{


		public function __construct() {
			 
		}
		

	
		public function export_skin_view($echo = false){

			$exportURL = add_query_arg(array(
				'action' => 'exportskin',
    			'nc' => time(),     // cache buster
    		), admin_url('admin-ajax.php'));



			if ($echo === true){
				echo '
				<p>'.esc_html__('When you click the button below WordPress will create a JSON file for you to save to your computer', 'neko').'.</p>
				<p>'.esc_html__('Once you\'ve saved the download file, you can use the Import skin page to import the previously exported settings', 'neko').'.</p>
				<a href="'.esc_url($exportURL).'" class="button">Download Export</a>';


				/* CHECK CURRENT USER CAPABILITES			
				$data = get_userdata( get_current_user_id() );
				if ( is_object( $data) ) {
					$current_user_caps = $data->allcaps;
					echo '<pre>' . print_r( $current_user_caps, true ) . '</pre>';
				}
				*/

			}elseif ($echo == 'url'){

				return $export_url;
			}



		}


		public function export_skin(){


		    $options = thsp_cbp_get_options_values();
		    $content = json_encode($options);
		    $file_name = 'neko-options-export.json';
		    

		    if ( !current_user_can('manage_options') ){
		        wp_die('<p>'.esc_html__('You do not have sufficient permissions to edit templates for this siteer.', 'neko').'</p>');
		    }

		    if ($content === null || $file_name === null){
		        wp_die('<p>'.esc_html__('Error Downloading file.', 'neko').'</p>');     
		    }

		    $fsize = strlen($content);
		    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		    header('Content-Description: File Transfer');
		    header("Content-Disposition: attachment; filename=" . $file_name);
		    header("Content-Length: ".$fsize);
		    header("Expires: 0");
		    header("Pragma: public");
		    echo sanitize_text_field( $content );

		    exit;
		}
		


	}/* end class */
	
}/* end class exist */
