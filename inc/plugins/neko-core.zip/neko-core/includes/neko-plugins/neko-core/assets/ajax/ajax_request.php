<?php

add_action( 'wp_ajax_oneclickinstallskin', 'text_ajax_process_requestskin' );	
function text_ajax_process_requestskin() {

	if (defined('DOING_AJAX') && DOING_AJAX ){

		require_once ( plugin_abs_path . 'includes/neko-plugins/neko-core/neko-theme-manager.php' );


		$neko_theme_manager = new Neko_Theme_Manager;
		$neko_theme_manager->display_admin_manager($_POST['demo'], $_POST['sw']);
		die();
	}
}


add_action( 'wp_ajax_oneclickinstallcontent', 'text_ajax_process_requestcontent' );	
function text_ajax_process_requestcontent() {
	/* To force error to check error message*/
	//header("HTTP/1.0 500 Forbidden");

	if (defined('DOING_AJAX') && DOING_AJAX ){
		require_once ( plugin_abs_path . 'includes/neko-plugins/neko-core/neko-theme-manager.php' );
		$neko_theme_manager = new Neko_Theme_Manager;
		$neko_theme_manager->display_admin_manager($_POST['demo'], $_POST['sw']);

		die();
	}
}

add_action('wp_ajax_exportskin',  'export_skin' );	
function export_skin() {

	if (defined('DOING_AJAX') && DOING_AJAX ){
		require_once ( plugin_abs_path . 'includes/neko-plugins/neko-core/skin-management/export-skin.php' );
		$neko_theme_manager = new Neko_Skin_Exporter;
		$neko_theme_manager->export_skin();

		die();
	}
}

