jQuery(function($){ 
   
	$('.one-click-install').click(function(event) {
		event.preventDefault();
		var $this = $(this),
		$start = 0;

		$('.plugin-needed').slideUp('fast');

		$('.demoSelector').not($(this).parents('.demoSelector')).fadeOut('300', function() {
			$start = 1;
			$('.demo-selector-wrapper').parent().addClass('one-demo');
		});


		
		$('#one-click-install-result').fadeIn('fast');
		$('#one-click-install-result>#one-click-install-result-info').html('');
		$('#neko-ajax-loader').css('display', 'block');

		

			var data = {
				action: 'oneclickinstallskin',
				demo:$this.data('demo'),
				sw: 'sk'
			};


		 	$.ajax({

		 		url:  ajax_object.ajaxurl,
		 		data :  data,
		 		type : 'POST'
		 	})
		 	.done(function(data) {
			 	
				 	
				 	if(data.toLowerCase().indexOf("error") < 0){
				 		
						/*
				 		setTimeout(function(){	
				 		$('.neko-oneclick-progressbar-inner').width('50%');
				 		
				 		}, 1000);
						*/

				 		$('#one-click-install-result>#one-click-install-result-info').append(data);

					 	var data = {
					 		action: 'oneclickinstallcontent',
					 		demo:$this.data('demo'),
					 		sw: 'dc'
					 	};

					 	$.ajax({
					 		url: ajax_object.ajaxurl,
					 		type: 'POST',
					 		data: data,
					 	})
					 	.done(function(data) {

					 		/*$('.neko-oneclick-progressbar-inner').width('100%');*/
					 		$('.neko-oneclick-progressbar-inner').addClass('neko-progress-done');

					 		$('#one-click-install-result>#one-click-install-result-info').append(data);
					 		$('#neko-ajax-loader').css('display', 'none');
					 	})
					 	.fail(function() {

					 		console.log("error");
					 		$('#neko-ajax-loader').css('display', 'none');
					 		$('.neko-oneclick-progressbar-inner').addClass('neko-progress-error');

					 		var error_content_message = '<div class="error"><h2>Server configuration error!</h2><p>Usually the demo import takes 5 to 10 minutes depending on the server speed & ram. If it loads forever this is 100% due to the server configuration or a security setting that does not allow to import content to your server. please refer to edena configuration page to know what you need to do to resolve your issue.<br/><br/><a class="button button-primary" href="wp-admin/themes.php?page=neko-welcome-page&tab=configuration" target="_blank">Theme configuration page</a></p></div>';

					 		$('#one-click-install-result>#one-click-install-result-info').append(error_content_message);

					 	})
					 	.always(function() {
					 		console.log("complete");
					 	});


				 	}else{
				 		$('#neko-ajax-loader').css('display', 'none');
				 		$('#one-click-install-result>#one-click-install-result-info').append('<div class="error"><p>'+data+'</p></div>');

				 	}


		 	})
		 	.fail(function() {
				//console.log("error");
			})
		 	.always(function() {
				//console.log("complete");
			});

		});


		$('.tigger-plugin-alert').click(function(event) {
			event.preventDefault();
			var $this = $(this);

				

			$this.parent().parents('.demoSelector').find('.plugin-needed').slideToggle('fast');

			/* All other demo behavior */
			$this.parent().parents('.demoSelector').siblings().find('.plugin-needed').slideUp('fast');
			$this.parent().parents('.demoSelector').siblings().find('.tigger-plugin-alert').text('Install');
			/* All other demo behavior */
			
			if($this.text() == 'Install'){
				$this.text('close');
			}else{
				$this.text('Install');
			}
		});
		

}); /* End Doucment ready */

/*
var data = {
				 			action: 'oneclickinstallplugins',
				 			demo:$this.data('demo'),
				 			sw: 'pi'
				 		};

				 		$.ajax({
				 			url: ajax_object.ajaxurl,
				 			type: 'POST',
				 			data: data,
				 		})

				 		.done(function(data) {
						 			$('#one-click-install-result>#one-click-install-result-info').append(data);

						 		
						 			var data = {
						 				action: 'oneclickinstallcontent',
						 				demo:$this.data('demo'),
						 				sw: 'dc'
						 			};

						 			$.ajax({
						 				url: ajax_object.ajaxurl,
						 				type: 'POST',
						 				data: data,
						 			})
						 			.done(function(data) {
						 				$('#one-click-install-result>#one-click-install-result-info').append(data);
						 				$('#neko-ajax-loader').css('display', 'none');
						 			})
						 			.fail(function() {
						 				console.log("error");
						 			})
						 			.always(function() {
						 				console.log("complete");
						 			});


				 		})
				 		.fail(function() {
				 			console.log("error");
				 		})
				 		.always(function() {
				 			console.log("complete");
				 		});
		 		
*/