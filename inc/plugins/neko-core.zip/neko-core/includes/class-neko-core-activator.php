<?php

/**
 * Fired during plugin activation
 *
 * @link       http://little-neko.com
 * @since      1.0.0
 *
 * @package    Neko_Core
 * @subpackage Neko_Core/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Neko_Core
 * @subpackage Neko_Core/includes
 * @author     Thomas Bechier
 */
class Neko_Core_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
