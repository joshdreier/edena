=== NEKO CORE ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: http://little-neko.com/
Tags: neko core system
Requires at least: 4.0.0
Tested up to: 4.5.3
Stable tag: 4.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
