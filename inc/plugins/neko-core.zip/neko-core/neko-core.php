<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://little-neko.com
 * @since             1.0.0
 * @package           Neko_Core
 *
 * @wordpress-plugin
 * Plugin Name:       Neko core
 * Plugin URI:        http://little-neko.com/
 * Description:       Add core functionalities to your Little Neko theme.
 * Version:           1.0.2
 * Author:            Little Neko
 * Author URI:        http://little-neko.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       neko-core
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/** Custom constants **/
define('plugin_abs_path', plugin_dir_path( __FILE__ ) );
define('plugin_uri', plugins_url( 'neko-core'  ) . '/' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-neko-core-activator.php
 */
function activate_neko_core() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-neko-core-activator.php';
	Neko_Core_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-neko-core-deactivator.php
 */
function deactivate_neko_core() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-neko-core-deactivator.php';
	Neko_Core_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_neko_core' );
register_deactivation_hook( __FILE__, 'deactivate_neko_core' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-neko-core.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_neko_core() {

	$plugin = new Neko_Core();
	$plugin->run();

}
run_neko_core();
