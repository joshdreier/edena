<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://little-neko.com
 * @since      1.0.0
 *
 * @package    Neko_Vcaddons
 * @subpackage Neko_Vcaddons/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Neko_Vcaddons
 * @subpackage Neko_Vcaddons/includes
 * @author     Your Name <email@example.com>
 */
class Neko_Vcaddons_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
