<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://little-neko.com
 * @since      1.0.0
 *
 * @package    Neko_Vcaddons
 * @subpackage Neko_Vcaddons/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Neko_Vcaddons
 * @subpackage Neko_Vcaddons/public
 * @author     Your Name <email@example.com>
 */
class Neko_Vcaddons_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Neko_Vcaddons_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Neko_Vcaddons_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/neko-vc-shortcode.css', array(), $this->version, 'all' );
		//wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/neko-vcaddons-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Neko_Vcaddons_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Neko_Vcaddons_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/neko-vcaddons-public.js', array( 'jquery' ), $this->version, false );

	}


	/**
	 * Check if visual composer is installed and activated.
	 *
	 * @since    1.0.0
	 */

	public function is_visualcomposer_ok(){

		if(  !defined( 'WPB_VC_VERSION' ) ){
		?>
		    <div class="error notice">
		        <p><?php esc_html_e( 'Visual Composer must be installed for Neko Vc Addons to work!', 'neko-vcaddons' ); ?></p>
		    </div>
		<?php
		}

	}

	/**
	 * Add custom values to visual composer shortocde.
	 *
	 * @since    1.0.0
	 */
	public function add_custom_field_values_to_vc() {

		$param_color = WPBMap::getParam( 'vc_btn', 'color' );
		$param_color['value'][esc_html__( 'Theme Color', 'neko' )] = 'neko-btn-theme';
		vc_update_shortcode_param( 'vc_btn', $param_color );


		$param_style = WPBMap::getParam( 'vc_btn', 'style' );
		$param_style['value'][esc_html__( 'Theme Style', 'neko' )] = 'neko-btn-style';
		vc_update_shortcode_param( 'vc_btn', $param_style );
		
	}




	/**
	 * Add neko stylish heading shortocde.
	 *
	 * @since    1.0.0
	 */
	public function neko_shortcodes_heading ( $atts, $content = null ) {
		return include(plugin_dir_path( __FILE__ ) . 'partials/neko-vc-heading.php');
	}

	/**
	 * Add neko stylish heading vc map.
	 *
	 * @since    1.0.0
	 */
	public function neko_heading_to_vc() {
		include(plugin_dir_path( __FILE__ ) . 'include/neko-heading-to-vc.php');
	}






	/**
	 * Add neko featured box shortocde.
	 *
	 * @since    1.0.0
	 */
	public function neko_shortcodes_featuredbox ( $atts, $content = null ) {
		return include(plugin_dir_path( __FILE__ ) . 'partials/neko-vc-featuredbox.php');
	}

	/**
	 * Add neko featured box vc map.
	 *
	 * @since    1.0.0
	 */
	public function neko_featuredbox_to_vc() {
		include(plugin_dir_path( __FILE__ ) . 'include/neko-featuredbox-to-vc.php');
	}





	/**
	 * Add neko icon box shortocde.
	 *
	 * @since    1.0.0
	 */
	public function neko_shortcodes_iconbox ( $atts, $content = null ) {
		return include(plugin_dir_path( __FILE__ ) . 'partials/neko-vc-iconbox.php');
	}

	/**
	 * Add neko icon box vc map.
	 *
	 * @since    1.0.0
	 */
	public function neko_iconbox_to_vc() {
		include(plugin_dir_path( __FILE__ ) . 'include/neko-iconbox-to-vc.php');
	}

	/**
	 * Add neko icon box shortocde.
	 *
	 * @since    1.0.0
	 */
	public function neko_shortcodes_imagebox ( $atts, $content = null ) {
		return include(plugin_dir_path( __FILE__ ) . 'partials/neko-vc-imagebox.php');
	}

	/**
	 * Add neko icon box vc map.
	 *
	 * @since    1.0.0
	 */
	public function neko_imagebox_to_vc() {
		include(plugin_dir_path( __FILE__ ) . 'include/neko-imagebox-to-vc.php');
	}



	/**
	 * Add neko icon list shortocde.
	 *
	 * @since    1.0.0
	 */
	public function neko_shortcodes_iconlist_ul ( $atts, $content = null ) {
		return include(plugin_dir_path( __FILE__ ) . 'partials/neko-vc-iconlist-ul.php');
	}

	/**
	 * Add neko icon list shortocde.
	 *
	 * @since    1.0.0
	 */
	public function neko_shortcodes_iconlist_li ( $atts, $content = null ) {
		return include(plugin_dir_path( __FILE__ ) . 'partials/neko-vc-iconlist-li.php');
	}

	/**
	 * Add neko icon list vc map.
	 *
	 * @since    1.0.0
	 */
	public function neko_iconlist_to_vc() {
		include(plugin_dir_path( __FILE__ ) . 'include/neko-iconlist-to-vc.php');
	}





	/**
	 * Add neko testimonial shortocde.
	 *
	 * @since    1.0.0
	 */
	public function neko_shortcodes_testimonial ( $atts, $content = null ) {
		return include(plugin_dir_path( __FILE__ ) . 'partials/neko-vc-testimonial.php');
	}

	/**
	 * Add neko testimonial vc map.
	 *
	 * @since    1.0.0
	 */
	public function neko_testimonial_to_vc() {
		include(plugin_dir_path( __FILE__ ) . 'include/neko-testimonial-to-vc.php');
	}	





	/**
	 * Add neko call to action shortocde.
	 *
	 * @since    1.0.0
	 */
	public function neko_shortcodes_calltoaction ( $atts, $content = null ) {
		return include(plugin_dir_path( __FILE__ ) . 'partials/neko-vc-calltoaction.php');
	}

	/**
	 * Add neko call to action vc map.
	 *
	 * @since    1.0.0
	 */
	public function neko_calltoaction_to_vc() {
		include(plugin_dir_path( __FILE__ ) . 'include/neko-calltoaction-to-vc.php');
	}	




	/**
	 * Add neko icon spacer shortocde.
	 *
	 * @since    1.0.0
	 */
	public function neko_shortcodes_iconspacer ( $atts, $content = null ) {
		return include(plugin_dir_path( __FILE__ ) . 'partials/neko-vc-iconspacer.php');
	}

	/**
	 * Add neko icon spacer vc map.
	 *
	 * @since    1.0.0
	 */
	public function neko_iconspacer_to_vc() {
		include(plugin_dir_path( __FILE__ ) . 'include/neko-iconspacer-to-vc.php');
	}





	/**
	 * Add neko image spacer shortocde.
	 *
	 * @since    1.0.0
	 */
	public function neko_shortcodes_imagegrid ( $atts, $content = null ) {
		return include(plugin_dir_path( __FILE__ ) . 'partials/neko-vc-imagegrid.php');
	}

	/**
	 * Add neko icon spacer vc map.
	 *
	 * @since    1.0.0
	 */
	public function neko_imagegrid_to_vc() {
		include(plugin_dir_path( __FILE__ ) . 'include/neko-imagegrid-to-vc.php');
	}	





	/**
	 * Add neko banner shortocde.
	 *
	 * @since    1.0.0
	 */
	public function neko_shortcodes_banner ( $atts, $content = null ) {
		return include(plugin_dir_path( __FILE__ ) . 'partials/neko-vc-banner.php');
	}

	/**
	 * Add neko banner vc map.
	 *
	 * @since    1.0.0
	 */
	public function neko_banner_to_vc() {
		
		include(plugin_dir_path( __FILE__ ) . 'include/neko-banner-to-vc.php');
	}	


	/**
	 * Add neko page header shortocde.
	 *
	 * @since    1.0.0
	 */
	public function neko_shortcodes_page_header ( $atts, $content = null ) {
		return include(plugin_dir_path( __FILE__ ) . 'partials/neko-vc-page-header.php');
	}

	/**
	 * Add neko page header vc map.
	 *
	 * @since    1.0.0
	 */
	public function neko_page_header_to_vc() {
		
		include(plugin_dir_path( __FILE__ ) . 'include/neko-page-header-to-vc.php');
	}	

} /* END OF CLASS */
