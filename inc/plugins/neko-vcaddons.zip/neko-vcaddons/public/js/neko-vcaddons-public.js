(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 */
	 $(function() {

	 		/* ICON BOX HOVER COLOR MANAGEMENT */

 			$('.neko-vc_box-icon  a').hover(function() {
 				$(this).parent().find('i').addClass('nk-hovered-icon');
 				$(this).parent().find('.neko-vc_box-icon-content').addClass('nk-hovered-content');
 			}, function() {
 				$(this).parent().find('i').removeClass('nk-hovered-icon');
 				$(this).parent().find('.neko-vc_box-icon-content').removeClass('nk-hovered-content');
 			});	


  		$('.neko-vc_box-image a').hover(function() {
 				$(this).parent().find('.neko-vc_box-image-wrapper').addClass('nk-hovered-image');
 				$(this).parent().find('.neko-vc_box-image-content').addClass('nk-hovered-content');
 			}, function() {
 				$(this).parent().find('.neko-vc_box-image-wrapper').removeClass('nk-hovered-image');
 				$(this).parent().find('.neko-vc_box-image-content').removeClass('nk-hovered-content');
 			});			

	 });

	 /*
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

})( jQuery );
