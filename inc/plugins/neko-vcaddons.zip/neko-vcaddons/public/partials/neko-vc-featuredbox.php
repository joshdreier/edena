<?php 
	$atts = vc_map_get_attributes( 'neko_featurebox', $atts );
	extract($atts);

	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), null, $atts );


	vc_icon_element_fonts_enqueue( $type );

	$position_icon = "neko-vc_media-".$layout;
	$el_id = ( !empty( $el_id ) ) ? 'id="'.esc_attr($el_id).'"' : '' ; 


	/**
	 *  VISUAL COMPOSER CSS3 ANIMATION
	 */
	$animation_class_system = '';
	if ( $css_animation !== '' ) {
			wp_enqueue_script( 'waypoints' );
			$animation_class_system = ' wpb_animate_when_almost_visible wpb_' . $css_animation;
	}


	$featured_box = '<div '.$el_id.' class="neko-vc_feature-box '.esc_attr($position_icon).' '.esc_attr($el_class).' '.esc_attr($animation_class_system).' '.esc_attr($css_class).'">';

	if (!empty($link)) {
		$href = vc_build_link( $link );	
		//echo '<pre>'; print_r($href); echo '</pre>';
		$target = ( !empty($href['target']) ) ? 'target="'.$href['target'].'"': '' ;
		$featured_box .= '<a href="'.esc_url($href['url']).'" title="'.$href['title'].'" '.$target .'>';
	}


	$custom_color = ( !empty($icon_color) ) ? 'color:'.$icon_color.';' : '';
	$custom_bgcolor = ( !empty($icon_bgcolor) ) ? 'background-color:'.$icon_bgcolor.';' : '';	

	$custom_bordercolor = '';
	$custom_borderstyle = '';
	$custom_bordersize  = '';
  if( !empty($iconborder) && true == $iconborder ){
  	$custom_bordercolor = ( !empty($icon_bordercolor) && 'default' !== $icon_bordercolor ) ? 'border-color:'.$icon_bordercolor.';' : 'border-color: #333;';	
  	$custom_borderstyle = ( !empty($icon_borderstyle) ) ? 'border-style:'.$icon_borderstyle.';' : 'border-style:solid;';	
  	$custom_bordersize = ( !empty($icon_bordersize) ) ? 'border-width: '.intval($icon_bordersize).'px;' : 'border-width: 1px;';	
  }	

	$icon_animation = (!empty($icon_anim) && 'yes' === $icon_anim)?'animated':'';

	$featured_box .= '<i class="icon-neko '.${"icon_" . $type}.' '.$icon_size.' '.$icon_shape.' '.$icon_animation.'" style="'.$custom_color.' '.$custom_bgcolor.' '.esc_attr($custom_bordercolor).' '.esc_attr($custom_borderstyle).' '.esc_attr($custom_bordersize).'"></i>';

	if (!empty($link)) { $featured_box .= '</a>'; }

	$featured_box .= '<div class="neko-vc_feature-box-content">';
	$featured_box .= wpb_js_remove_wpautop( $content, true );

	if (!empty($link_txt) && !empty($link)) {
		$featured_box .= '&nbsp;<a href="'.esc_url($href['url']).'" title="'.$href['title'].'" target="'.$href['target'].'" class="box-txt-link">'.$link_txt.'</a>';
	}


	$featured_box .= '</div>'; // end featured-box-content
	$featured_box .= '</div>'; // end featured-box

	return $featured_box;