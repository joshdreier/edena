<?php 
	$atts = vc_map_get_attributes( 'neko_list_li', $atts );
	extract($atts);

	//echo '<pre>'; print_r($atts); echo '</pre>';

	vc_icon_element_fonts_enqueue( $type );

	$el_id = ( !empty( $el_id ) ) ? 'id="'.esc_attr($el_id).'"' : '' ; 

	$icon_list_li = '<li '.$el_id.' class="neko-vc_list-icon-li '.esc_attr($el_class).'">';


	$icon_color = ( !empty($icon_color) ) ? 'style="color:'.esc_attr($icon_color).'"': ''; 
	$icon_list_li .= '<i class="icon-neko '.${"icon_" . $type}.'" '.$icon_color.'></i>';

	$txt_color = ( !empty($txt_color) ) ? 'style="color:'.esc_attr($txt_color).'"': ''; 
	$icon_list_li .= '<span '.$txt_color.'>'.$li_text.'</span>';

	$icon_list_li .= '</li>'; // end icon-box

	return $icon_list_li;