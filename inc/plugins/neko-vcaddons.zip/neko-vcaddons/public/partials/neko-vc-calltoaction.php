<?php 
	$atts = vc_map_get_attributes( 'neko_calltoaction', $atts );
	extract($atts);

	//echo '<pre>'; print_r($atts); echo '</pre>';


	/* INIT & SET VARS (building view) */

	/* styles */
	$titlecolor    = ( !empty($titlecolor) ) ? 'style="color:'.esc_attr( $titlecolor ).'"' : '' ;
	$textcolor     = ( !empty($textcolor) ) ? 'style="color:'.esc_attr( $textcolor ).'"' : '' ;
	$css_class     = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), '', $atts );


	/* title / content / display */
	$hide_txt_bloc = ( empty($title) && empty($content) ) ? true : false ;
	$hide_link_bloc = ( empty($link) && empty($link2) ) ? true : false ;

	$title         = ( !empty($title) ) ? '<h2 '.$titlecolor.'>'.$title.'</h2>' : '' ;
	$spacer		   = ( !empty($content) ) ? ' neko-vc_cta-box-spacer' : '' ;

	/* CLEAN de VC */
	$link = ( $link == '||' ) ? '' : $link ;
	$link2 = ( $link2 == '||' ) ? '' : $link2 ;

	if (!empty($link) ) {
		$href = vc_build_link( $link );
		$target1 = ( !empty($href['target']) ) ? 'target="'.$href['target'].'"': '' ;
		$link = '<a href="'.esc_url($href['url']).'" title="'.$href['title'].'" '. $target1 .' class="btn '.esc_attr( $button_size ).'">'.$href['title'].'</a>';	
	}else{
		$link = '';
	}

	if (!empty($link2) && 'cta-box-centered-2-btn' === $layout ) {
		$href2 = vc_build_link( $link2 );
		$target2 = ( !empty($href['target']) ) ? 'target="'.$href['target'].'"': '' ;
		$link2 = '<a href="'.esc_url($href2['url']).'" title="'.$href2['title'].'" '.$target2.' class="btn primary '.esc_attr( $button_size ).'">'.$href2['title'].'</a>';	
	}else{
		$link2 = '';
	}

	$el_class   = ( !empty( $el_class ) ) ? esc_attr($el_class) : '' ; 
	$el_id      = ( !empty( $el_id ) ) ? 'id="'.esc_attr($el_id).'"' : '' ; 


	/**
	 *  VISUAL COMPOSER CSS3 ANIMATION
	 */
	$animation_class_system = '';
	if ( $css_animation !== '' ) {
			wp_enqueue_script( 'waypoints' );
			$animation_class_system = ' wpb_animate_when_almost_visible wpb_' . $css_animation;
	}


	$calltoaction  = '<div '.$el_id.' class="neko-vc_cta-box neko-vc_'.esc_attr($layout).' '.esc_attr($el_class) .' '.esc_attr( $css_class ).' '.esc_attr($animation_class_system).'">';

		if( false === $hide_txt_bloc ){
			$calltoaction  .= '
			<div class="neko-vc_cta-box-text">			
				'.$title.'
				<div '.$textcolor.' class="neko-vc_cta-box-textfield'.$spacer.'">
					'.wpb_js_remove_wpautop( $content, true ).'
				</div>
			</div>';
		}

		if( false === $hide_link_bloc ){
			$calltoaction  .= '
			<div class="neko-vc_cta-box-btn">
				'.$link.'
				'.$link2.'
			</div>';
		}

	$calltoaction  .= '</div>';

	return $calltoaction;