<?php 
	$atts = vc_map_get_attributes( 'neko_imagebox', $atts );
	extract($atts);

	//echo '<pre>'; print_r($atts); echo '</pre>';
	//
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), null, $atts );

	$el_id = ( !empty( $el_id ) ) ? 'id="'.esc_attr($el_id).'"' : '' ;

	/**
	 *  VISUAL COMPOSER CSS3 ANIMATION
	 */
	$animation_class_system = '';
	if ( $css_animation !== '' ) {
			wp_enqueue_script( 'waypoints' );
			$animation_class_system = ' wpb_animate_when_almost_visible wpb_' . $css_animation;
	}


	$image_box = '<div '.$el_id.' class="neko-vc_box-image clearfix '.esc_attr($el_class).' '.esc_attr($animation_class_system).' neko-vc_box-image-'.esc_attr($image_size).' neko-vc_box-image-'.esc_attr($image_shape).' '.esc_attr($css_class).'"><div class="neko-vc_box-image_wrapper">';

	$link = ( $link == '||' ) ? '' : $link ;
	if (!empty($link)) {
		$href = vc_build_link( $link );	
		$target = ( !empty($href['target']) ) ? 'target="'.$href['target'].'"': '' ;
		$image_box .= '<a href="'.esc_url($href['url']).'" title="'.$href['title'].'" '.$target.'></a>';
	}


	$custom_color = ( !empty($image_color) ) ? 'color:'.$image_color.';' : '';
	$custom_bgcolor = ( !empty($image_bgcolor) && 'default' !== $image_shape ) ? 'background-color:'.$image_bgcolor.';' : '';	
  //$custom_bghovercolor = ( !empty($image_bgcolorhover) && 'default' !== $image_bgcolorhover ) ? 'data-hovercolor="'.esc_attr($image_bgcolorhover).'"' : '';	

  /* image BORDER MANAGEMENT */
	$custom_bordercolor = '';
	$custom_borderstyle = '';
	$custom_bordersize  = '';
  if( !empty($image_border) && true == $image_border ){
  	$custom_bordercolor = ( !empty($image_bordercolor) && 'default' !== $image_bordercolor ) ? 'border-color:'.$image_bordercolor.';' : 'border-color: #333;';	
  	$custom_borderstyle = ( !empty($image_borderstyle) ) ? 'border-style:'.$image_borderstyle.';' : 'border-style:solid;';	
  	$custom_bordersize = ( !empty($image_bordersize) ) ? 'border-width: '.intval($image_bordersize).'px;' : 'border-width: 0px;';	
  }

	$image_animation = (!empty($image_anim) && 'yes' === $image_anim)?'animated':'';


	$img =  wp_get_attachment_url( $image  );
	
  $images_attr = array( 'class'	=> "neko-img-fullwidth" );

  switch ($image_size) {
  	case 'medium':
  		$array_size = array('120', '120');
  		break;
   	case 'large':
  		$array_size = array('150', '150');
  		break;
   	case 'x-large':
  			$array_size = array('190', '190');
  		break;
  	default:
  		$array_size = array('120', '120');
  		break;
  }




	$img =  wp_get_attachment_image( $image , $array_size, 0, $images_attr );

	if( !empty($img) ){

		/*$bg_image = 'background :transparent url('.$img.') no-repeat 50% 50%; background-size: cover; ';*/
		

		$image_box .= '<div class="neko-vc_box-image-wrapper '.esc_attr($image_size).' '.esc_attr($image_shape).' '.esc_attr($image_animation).'" style="'.esc_attr($custom_color).' '.esc_attr($custom_bgcolor).' '.esc_attr($custom_bordercolor).' '.esc_attr($custom_borderstyle).' '.esc_attr($custom_bordersize).' " >';	//'.$bg_image.'
		$image_box .= $img ;
		$image_box .= '</div>';
	}


	$image_box .='<div class="neko-vc_box-image-content">';

	$image_box .= wpb_js_remove_wpautop( $content, true );

	$image_box .= '</div>';

	/*if (!empty($link)) { $image_box .= '</a>'; }*/

	$image_box .= '</div></div>'; // end image-box

	return $image_box;
		