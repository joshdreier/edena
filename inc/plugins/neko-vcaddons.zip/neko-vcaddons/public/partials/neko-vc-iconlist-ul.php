<?php
	$atts = vc_map_get_attributes( 'neko_list_ul', $atts );
	extract($atts);



	$title = ( !empty($ul_title) ) ? '<h3 class="neko-vc_list-icon-title">'.$ul_title.'</h3>' : '' ; 
	$el_id = ( !empty( $el_id ) ) ? 'id="'.esc_attr($el_id).'"' : '' ;


	/**
	 *  VISUAL COMPOSER CSS3 ANIMATION
	 */
	$animation_class_system = '';
	if ( $css_animation !== '' ) {
			wp_enqueue_script( 'waypoints' );
			$animation_class_system = ' wpb_animate_when_almost_visible wpb_' . $css_animation;
	}


	$icon_list_ul = $title.' <ul '.$el_id.' class="neko-vc_list-icon-ul clearfix '.esc_attr($el_class).' '.esc_attr($animation_class_system).'">';


	$icon_list_ul .= wpb_js_remove_wpautop( $content, false );


	$icon_list_ul .= '</ul>'; // end icon-box

	return $icon_list_ul;