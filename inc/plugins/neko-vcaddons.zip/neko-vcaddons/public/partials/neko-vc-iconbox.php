<?php 
	$atts = vc_map_get_attributes( 'neko_iconbox', $atts );
	extract($atts);

	//echo '<pre>'; print_r($atts); echo '</pre>';

 	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), null, $atts );

	vc_icon_element_fonts_enqueue( $type );
	$el_id = ( !empty( $el_id ) ) ? 'id="'.esc_attr($el_id).'"' : '' ;

	/**
	 *  VISUAL COMPOSER CSS3 ANIMATION
	 */
	$animation_class_system = '';
	if ( $css_animation !== '' ) {
			wp_enqueue_script( 'waypoints' );
			$animation_class_system = ' wpb_animate_when_almost_visible wpb_' . $css_animation;
	}


	$icon_box = '<div '.$el_id.' class="neko-vc_box-icon clearfix '.esc_attr($el_class).' '.esc_attr($animation_class_system).' neko-vc_box-icon-'.esc_attr($icon_size).' neko-vc_box-icon-'.esc_attr($icon_shape).' '.esc_attr($css_class).'"><div class="neko-vc_box-icon_wrapper">';

	$link = ( $link == '||' ) ? '' : $link ;
	if (!empty($link)) {
		$href = vc_build_link( $link );	
		$target = ( !empty($href['target']) ) ? 'target="'.$href['target'].'"': '' ;
		$icon_box .= '<a href="'.esc_url($href['url']).'" title="'.$href['title'].'" '.$target.'></a>';
	}


	$custom_color = ( !empty($icon_color) ) ? 'color:'.$icon_color.';' : '';
	$custom_bgcolor = ( !empty($icon_bgcolor) && 'default' !== $icon_shape ) ? 'background-color:'.$icon_bgcolor.';' : '';	
	
  //$custom_bghovercolor = ( !empty($icon_bgcolorhover) && 'default' !== $icon_bgcolorhover ) ? 'data-hovercolor="'.esc_attr($icon_bgcolorhover).'"' : '';	
	//'.$custom_bghovercolor.'

  /* ICON BORDER MANAGEMENT */
	$custom_bordercolor = '';
	$custom_borderstyle = '';
	$custom_bordersize  = '';
  if( !empty($iconborder) && true == $iconborder ){
  	$custom_bordercolor = ( !empty($icon_bordercolor) && 'default' !== $icon_bordercolor ) ? 'border-color:'.$icon_bordercolor.';' : 'border-color: #333;';	
  	$custom_borderstyle = ( !empty($icon_borderstyle) ) ? 'border-style:'.$icon_borderstyle.';' : 'border-style:solid;';	
  	$custom_bordersize = ( !empty($icon_bordersize) ) ? 'border-width: '.intval($icon_bordersize).'px;' : 'border-width: 1px;';	
  }

	$icon_animation = (!empty($icon_anim) && 'yes' === $icon_anim)?'animated':'';
	$icon_box .= '<i class="icon-neko '.${"icon_" . $type}.' '.esc_attr($icon_size).' '.esc_attr($icon_shape).' '.esc_attr($icon_animation).'" style="'.esc_attr($custom_color).' '.esc_attr($custom_bgcolor).' '.esc_attr($custom_bordercolor).' '.esc_attr($custom_borderstyle).' '.esc_attr($custom_bordersize).'" ></i>';

	$icon_box .='<div class="neko-vc_box-icon-content">';

	$icon_box .= wpb_js_remove_wpautop( $content, true );

	$icon_box .= '</div>';

	/*if (!empty($link)) { $icon_box .= '</a>'; }*/

	$icon_box .= '</div></div>'; // end icon-box

	return $icon_box;
		