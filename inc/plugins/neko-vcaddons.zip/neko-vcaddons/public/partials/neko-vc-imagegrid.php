<?php 
	$atts = vc_map_get_attributes( 'neko_imagegrid', $atts );
	extract($atts);

	//echo '<pre>'; print_r($atts); echo '</pre>';

	
	/* Build shortocode */	
	if( !empty($images) ){

		$el_id = ( !empty( $el_id ) ) ? 'id="'.esc_attr($el_id).'"' : '' ; 
		$bordercolor    = ( !empty($bordercolor) ) ? 'style="border-color:'.esc_attr( $bordercolor ).'"' : '' ;

		/* retrieve all images */
		$images = explode(',', $images);
		
		$i = 0;
		
		switch ($colnumber) {

			case 3:
			$bs_cols = 4;
			break;

			case 4:
			$bs_cols = 3;
			break;

			case 6:
			$bs_cols = 2;
			break;

			default:
			$bs_cols = 4;
		}

		$images_attr = array(
			'class'	=> "img-responsive"
			);

		$image_grid = '<div class="neko-border-grid '.esc_attr($el_class) .'">';

		foreach ($images as $key => $img_id) {
			$img =  wp_get_attachment_image( $img_id , 'img-x-large', 0, $images_attr );

			if( $i % $colnumber == 0 ){ $image_grid .= '<div class="row" '.$bordercolor.'>'; }
			
			$image_grid .= '<div class="col-sm-'.$bs_cols.'" '.$bordercolor.'>'.$img.'</div>';

			$i++;
			if( $i % $colnumber == 0 && $i != 0 ){ $image_grid .= '</div>'; }
		}
		$image_grid .= '</div>';
	}

	return  $image_grid;