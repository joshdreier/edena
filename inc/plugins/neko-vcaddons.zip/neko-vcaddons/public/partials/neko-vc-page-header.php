<?php 
	$atts = vc_map_get_attributes( 'neko_page_header', $atts );
	extract($atts);
	//echo '<pre>'; print_r($atts); echo '</pre>';
	//	
	$neko_page_header = '';
	$el_class   = ( !empty( $el_class ) ) ? esc_attr($el_class) : '' ; 
	$el_id      = ( !empty( $el_id ) ) ? 'id="'.esc_attr($el_id).'"' : '' ; 
  $css_class     = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), '', $atts );

	if ( !empty($title_css_animation) || !empty($content_css_animation)  ) {
			wp_enqueue_script( 'waypoints' );
	}

	/*  LAYOUT */
	$layout = ( !empty( $pageheader_layout ) && '2-cols' !== $pageheader_layout ) ? 'neko-vc_page-header-align-'.$pageheader_layout : 'neko-vc_page-header-2-cols' ;
	/* /LAYOUT */
-
	/*  LAYOUT */
	$size = ( !empty( $pageheader_size )  ) ? 'neko-vc_page-header-size-'.$pageheader_size : '' ;
	/* /LAYOUT */

  /* TITLE  */
	  $title_color = ( !empty($title_color) ) ? 'style="color:'.$title_color.'"' : '' ; 
	  $title_css_animation = ( !empty($title_css_animation) ) ? ' wpb_animate_when_almost_visible wpb_' . $title_css_animation : '';

	  $displayed_title = ( !empty($title) ) ? '<h1 '.$title_color.' class="'.esc_attr($title_css_animation).'"> '.$title.' </h1>' : '';
  /* / TITLE  */


  /* CONTENT */
	  $content_css_animation = ( !empty($content_css_animation) ) ? ' wpb_animate_when_almost_visible wpb_' . $content_css_animation : '';
	  $content = wpb_js_remove_wpautop( $content, true );

	  $displayed_content = ( !empty($content) ) ? '<div class="neko-vc_page-header-content '.esc_attr($content_css_animation).'">'.$content.'</div>' :  '' ; 
  /* / CONTENT */


  /* BREADCRUM */
  $displayed_breadcrumb = '';
  if( !empty($breadcrumb) && 'true' == $breadcrumb ){


  $breadcrumb_class = ($breadcrumb_skin) ? 'neko-vc_page-header-breadcrumb-'.$breadcrumb_skin : 'neko-vc_page-header-breadcrumb-light';
  $displayed_breadcrumb = wp_nav_menu( 
									array(
										'theme_location'  => 'primary',
										'container' => 'none', 
										'depth' => 0,
										'walker'=> new neko_BreadCrumbWalker, 
										'items_wrap' => '<div class="neko-vc_page-header-breadcrumb '.esc_attr($breadcrumb_class).' %2$s">%3$s</div>',
										'echo' => false
										)
									);
  }
  /* / BREADCRUM */


  /* PAGE HEADER */

	  $neko_page_header .= '<div '.esc_attr( $el_id ).' class="neko-vc_page-header '.esc_attr($layout).' '.esc_attr($size).' '.esc_attr( $css_class ).'  '.esc_attr( $el_class ).'">';
	  $neko_page_header .= '<div class="container">';
	  $neko_page_header .= '<div class="row">';

	  if( !empty( $pageheader_layout ) && '2-cols' == $pageheader_layout ){

	  	$neko_page_header .= '<div class="col-md-6">'.$displayed_title.' '.$displayed_content.'</div>';
	  	$neko_page_header .= '<div class="col-md-6">'.$displayed_breadcrumb.'</div>';

	  }else{
	  	$neko_page_header .= '<div class="col-md-12">';
	  	$neko_page_header .= $displayed_title;
	  	$neko_page_header .= $displayed_content;
	  	$neko_page_header .= $displayed_breadcrumb;
	  	$neko_page_header .= '</div>';
	  }

	  $neko_page_header .= '</div>';
	  $neko_page_header .= '</div>';
	  $neko_page_header .= '</div>';

  /* / PAGE HEADER */


return $neko_page_header;
