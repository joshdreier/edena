<?php 
	$atts = vc_map_get_attributes( 'neko_spacer', $atts );
	extract($atts);

	//echo '<pre>'; print_r($atts); echo '</pre>';

	$el_id = ( !empty( $el_id ) ) ? 'id="'.esc_attr($el_id).'"' : '' ; 

	/* Icon color setting */
	$nk_bgicon_color = ( !empty($iconbgcolor) ) ? 'background-color:'.$iconbgcolor.';' : '' ;
	$nk_icon_color = ( !empty($iconcolor) ) ? 'color:'.$iconcolor.';'  : '' ;
	

	$nk_icon_syle = '';	
	if( !empty($nk_bgicon_color) || !empty($nk_icon_color) ){
		$nk_icon_syle = 'style="'.esc_attr($nk_bgicon_color).' '.esc_attr($nk_icon_color).' "';
	}

	/* hr border color */
	$nk_bordercolor = ( !empty($bordercolor) ) ? 'style="border-color:'.esc_attr($bordercolor).';"'  : '' ;

	return '<div class="'.esc_attr( $spacersize ).'"><div '.$el_id.' class="neko-hr  '.esc_attr( $el_class ).' " '.$nk_bordercolor.'><i class="'.esc_attr( $iconstyle ).' '.esc_attr( $iconsize ).'" '.$nk_icon_syle.'></i></div></div>';