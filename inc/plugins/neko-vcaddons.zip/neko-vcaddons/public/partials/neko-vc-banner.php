<?php 
	$atts = vc_map_get_attributes( 'neko_banner', $atts );
	extract($atts);
	$neko_banner = '';
	
	
	$el_class   = ( !empty( $el_class ) ) ? esc_attr($el_class) : '' ; 
	$el_id      = ( !empty( $el_id ) ) ? 'id="'.esc_attr($el_id).'"' : '' ; 
  $css_class     = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), '', $atts );


	$animation_class_system = '';
	if ( $css_animation !== '' ) {
			wp_enqueue_script( 'waypoints' );
			$animation_class_system = ' wpb_animate_when_almost_visible wpb_' . $css_animation;
	}

			/* LINK */
		$link = ( $link == '||' ) ? '' : $link ;
		$open_link = '';
		$close_link = '';
		if( !empty($link) ){
			$href = vc_build_link( $link );
			$target = ( !empty($href['target']) ) ? 'target="'.$href['target'].'"': '' ;
			$open_link = '<a href="'.esc_url($href['url']).'" title="'.$href['title'].'" '.$target.'>';
			$close_link = '</a>';
		}



	$neko_banner .= '<div '.esc_attr( $el_id ).' class="neko-banner  '.esc_attr( $css_class ).'  '.esc_attr( $el_class ).' '.esc_attr($animation_class_system).'">'.$open_link;

		if( !empty($activateoverlay) && true == $activateoverlay ){
			  $maskcolor    = ( !empty($overlaycolor) ) ? 'style="background-color:'.esc_attr( $overlaycolor ).'"' : '' ;
				$neko_banner .= '<div class="neko-banner-overlay" '.$maskcolor.'></div>';
		}

		$images_attr = array( 'class'	=> "neko-img-fullwidth" );
		$img =  wp_get_attachment_image( $image , 'img-x-large', 0, $images_attr );

		if( !empty($img) ) $neko_banner .= $img;





		$neko_banner .= '<div class="neko-banner-content">';

		/* TITLE */
		if( !empty($title) ){
				 $titlecolor    = ( !empty($titlecolor) ) ? 'style="color:'.esc_attr( $titlecolor ).'"' : '' ;
				 $neko_banner .= '<h2 '.$titlecolor.'>'.$title.'</h2>';
		}

		/* CONTENT */
		if( !empty($content) ){
			/*$textcolor    = ( !empty($contentcolor) ) ? 'style="color:'.esc_attr( $contentcolor ).'"' : '' ;*/
			$neko_banner .= '<div>'.wpb_js_remove_wpautop( $content, true ).'</div>';
		}

		/* BTN LINK */
		if( !empty($href['title']) ){
			$neko_banner .= '<a href="'.esc_url($href['url']).'" title="'.$href['title'].'" '.$target.' class="btn btn-default">'.$href['title'].'</a>';	
		}
		
	  
	  $neko_banner .= '</div>';

	$neko_banner .= $close_link.'</div>';


	//echo '<pre>'; print_r($atts); echo '</pre>';
	return $neko_banner; 
