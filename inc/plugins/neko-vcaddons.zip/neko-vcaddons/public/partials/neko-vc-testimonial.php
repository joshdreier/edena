<?php 
	$atts = vc_map_get_attributes( 'neko_testimonial', $atts );
	extract($atts);


	$el_id = ( !empty( $el_id ) ) ? 'id="'.esc_attr($el_id).'"' : '' ; 

	$avatar = wp_get_attachment_url( $avatar_id );	
	$avatar_img = ( !empty($avatar) ) ? '<img src="'.$avatar.'" class="avatar" alt="'.$name.' '.$function.'">' : '';


	/**
	 *  VISUAL COMPOSER CSS3 ANIMATION
	 */
	$animation_class_system = '';
	if ( $css_animation !== '' ) {
			wp_enqueue_script( 'waypoints' );
			$animation_class_system = ' wpb_animate_when_almost_visible wpb_' . $css_animation;
	}

	$background_style= (!empty($background_color))? ' style="background-color:'.$background_color.';"' : '';
	$arrow_style= (!empty($background_color))? ' style="border-top-color:'.$background_color.';"' : '';
	$text_style= (!empty($text_color))? ' style="color:'.$text_color.';"' : '';

	return '
	<article '.$el_id.' class="neko-vc_testimonial '.esc_attr( $el_class ).' '.esc_attr($animation_class_system).'">
		<div class="neko-vc_box-arrow"'.$background_style.'>
				<blockquote class="neko-content"'.$text_style.'>
				'.wpb_js_remove_wpautop( $content, true ).'
				</blockquote>
				<div class="neko-arrow"'.$arrow_style.'></div>
		</div>

		'.$avatar_img.'

		<cite>
			<strong>'.$name.'</strong><br>
			<span>'.$function.'</span>
		</cite>
	</article>';