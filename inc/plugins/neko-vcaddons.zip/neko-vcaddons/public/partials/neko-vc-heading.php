<?php

$atts = vc_map_get_attributes( 'neko_heading', $atts );
extract($atts);


$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), null, $atts );

$styles      = explode(',', $titlestyles);
$shadow      = (!empty($styles[0])) ? $styles[0] : '' ; 

$titlecolor_style = 	(!empty($titlecolor)) ? ' style="color:'.esc_attr( $titlecolor ).'"' : '';
$subtitlecolor_style = 	(!empty($subtitlecolor)) ? ' style="color:'.esc_attr( $subtitlecolor ).'"' : '';


$icon_title='';

if( 'neko-icontype-svg' ===  $iconsource){

	if ( 'show-neko-icon-on' == $showicon ){

		$icon_svg = wp_get_attachment_url($iconsvg);
		
		$iconoffset = ( strpos($iconoffset,'px') === false ) ? $iconoffset.'px': $iconoffset;

		if( !empty( $iconoffset ) ){
			
			$original_offset =  -54 ;
			$computed_offset = $original_offset + $iconoffset ;
			$iconoffset_style = 'color:whi top:'.$computed_offset.'px;' ;
		}

		$iconstyle = ( !empty($iconoffset_style) ) ? 'style="'.$iconoffset_style.'"' : '' ;
		
		$icon_title = '<span class="neko-title-icon" '.$iconstyle.'><img src="'.$icon_svg.'" class="icon-svg" alt="heading icon"></span>';
	}


}else{

	if ( 'show-neko-icon-on' == $showicon ){

		$title_icon = ( !empty( $icon_customicons ) ) ? $icon_customicons : 'neko-title-icon-default' ;

		$iconcolor_style = 	( !empty( $iconcolor ) ) ? 'color:'.esc_attr( $iconcolor ).';' : '';

		$iconoffset = ( strpos($iconoffset,'px') === false ) ? $iconoffset.'px': $iconoffset;

		if( !empty( $iconoffset ) ){
			$original_offset =  -54 ;
			$computed_offset = $original_offset + $iconoffset ;
			$iconoffset_style = ' top:'.$computed_offset.'px;' ;
		}


		$iconstyle = ( !empty($iconcolor_style) || !empty($iconoffset_style) ) ? 'style="'.$iconcolor_style.$iconoffset_style.'"' : '' ;

		$icon_title = '<span class="neko-title-icon '.esc_attr( $title_icon ).'" '.$iconstyle.' ></span>';
	} 


}

		/**
		 *  VISUAL COMPOSER CSS3 ANIMATION
		 */
		$animation_class_system = '';
		if ( $css_animation !== '' ) {
			wp_enqueue_script( 'waypoints' );
			$animation_class_system = ' wpb_animate_when_almost_visible wpb_' . $css_animation;
		}


		$el_id = ( !empty( $el_id ) ) ? 'id="'.esc_attr($el_id).'"' : '' ; 

		switch ($titlehierarchy) {

			case 'h1':
			$title_type       = 'h2';
			$title_type_class = ' medium-heading';
			$bloc_type_class  = ' neko-medium-title';
			break;

			case 'h2':
			$title_type       = 'h2';
			$title_type_class = ' small-heading';
			$bloc_type_class  = ' neko-small-title';
			break;

			case 'big-heading':
			$title_type       = 'h2';
			$title_type_class = ' big-heading';
			$bloc_type_class  = ' neko-large-title';
			break;

			default:
			$title_type       = 'h2';
			$title_type_class = ' medium-heading';
			$bloc_type_class  = ' neko-medium-title';
			break;
			
		}
		if (isset($subtitleposition) && $subtitleposition=='under-title') {
			$title_html=$title.'<span'.$subtitlecolor_style.'>'.$subtitle .'</span>';	
			$subtitle_position_class = 'neko-sub-title-under';
		} else {
			$title_html='<span'.$subtitlecolor_style.'>'.$subtitle .'</span>'.$title;
			$subtitle_position_class = 'neko-sub-title-above';
		}

		return '<div '.$el_id.' class="stylish-heading '.esc_attr( $alignment ).' '.esc_attr( $showicon ).' '.esc_attr( $subtitle_position_class  ).' '.esc_attr( $el_class ).' '.esc_attr($bloc_type_class).' '.esc_attr($animation_class_system).' '.esc_attr( $shadow ).' '.esc_attr($css_class).'">
		<'.esc_attr($title_type).' class="'.esc_attr($title_type_class).'"'.$titlecolor_style.'>
		'.$title_html.'
		</'.esc_attr($title_type).'> '.$icon_title.'
	</div>'; 
