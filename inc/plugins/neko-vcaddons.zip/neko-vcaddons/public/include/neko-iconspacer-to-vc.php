<?php 
   vc_map( 
	   	array(
		    'name' => esc_html__( 'Neko Spacer', 'neko-vcaddons' ),
		    'base' => 'neko_spacer',
		    'class' => '',
		    'icon' => plugin_dir_url( dirname( __FILE__ )  ) . 'img/icon_spacer.png',
		    'category' => esc_html__( 'Neko shortcodes', 'neko-vcaddons'),
		    // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
		    // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
		    'params' => array(

				/**
				 * Spacer size
				 */	
				
		         array(
		            'type' => 'dropdown',
		            'class' => '',
		            'heading' => esc_html__( 'Spacer height', 'neko-vcaddons' ),
		            'param_name' => 'spacersize',
					'value' => array(
						esc_html__( 'Default', 'neko-vcaddons' ) => 'neko-spacer-default',
						esc_html__( 'Small', 'neko-vcaddons' ) => 'neko-spacer-small',
						esc_html__( 'Medium', 'neko-vcaddons' )  => 'neko-spacer-medium',
						esc_html__( 'Large', 'neko-vcaddons' )   => 'neko-spacer-large'
						
					),
					'admin_label' => false
		        ),

				/**
				 * icon
				 */	
		         array(
		            'type' => 'dropdown',
		            'class' => '',
		            'heading' => esc_html__( 'Icon', 'neko-vcaddons' ),
		            'param_name' => 'iconstyle',
					'value' => array(
						esc_html__( 'Star', 'neko-vcaddons' )   => 'neko-spacer-icon-star',
						esc_html__( 'Cross', 'neko-vcaddons' )  => 'neko-spacer-icon-cross',
						esc_html__( 'Plus', 'neko-vcaddons' )   => 'neko-spacer-icon-plus',
						esc_html__( 'Dot', 'neko-vcaddons' )    => 'neko-spacer-icon-dot',
						esc_html__( 'Burger', 'neko-vcaddons' ) => 'neko-spacer-icon-burger'	
					),
					'admin_label' => true
		        ),


				/**
				 * Icon size
				 */	
				
		         array(
		            'type' => 'dropdown',
		            'class' => '',
		            'heading' => esc_html__( 'Icon size', 'neko-vcaddons' ),
		            'param_name' => 'iconsize',
					'value' => array(
						esc_html__( 'Default', 'neko-vcaddons' ) => 'neko-icon-default',
						esc_html__( 'Small', 'neko-vcaddons' ) => 'neko-icon-small',
						esc_html__( 'Medium', 'neko-vcaddons' )  => 'neko-icon-medium',
						esc_html__( 'Large', 'neko-vcaddons' )   => 'neko-icon-large'
						
					),
					'admin_label' => false
		        ),



		        /**
				 * ICON BG COLOR
				 */	
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Icon background color', 'neko-vcaddons' ),
					'param_name' => 'iconbgcolor',
					'description' => esc_html__( 'Set the background color for your icon (leave blank for default)', 'neko-vcaddons' )
				),

		         /**
				 * ICON COLOR
				 */	
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Icon color', 'neko-vcaddons' ),
					'param_name' => 'iconcolor',
					'description' => esc_html__( 'Set the icon color (leave blank for default)', 'neko-vcaddons' )
				),

		         /**
				 * BORDER COLOR
				 */	
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Border color', 'neko-vcaddons' ),
					'param_name' => 'bordercolor',
					'description' => esc_html__( 'Set the border color (leave blank for default)', 'neko-vcaddons' )
				),


		         /**
		          *  el class
		          */
		         array(
		         	'type' => 'textfield',
		         	'heading' => esc_html__('Extra class name', 'neko-vcaddons'),
		         	'param_name' => 'el_class',
            		'description' => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'neko-vcaddons')
		         ),

		         /**
		          *  el id
		          */
		         array(
		         	'type' => 'textfield',
		         	'heading' => esc_html__('Extra id name', 'neko-vcaddons'),
		         	'param_name' => 'el_id',
            		'description' => esc_html__('If you wish to style particular content element differently, then use this field to add an id name and then refer to it in your css file.', 'neko-vcaddons')
		        ),

				array(
					'type' => 'css_editor',
					'heading' => esc_html__( 'Css', 'neko-vcaddons' ),
					'param_name' => 'css',
					'group' => esc_html__( 'Design options', 'neko-vcaddons' ),
				)

		    )
	  	)
	);

	add_shortcode('neko_spacer', array( $this, 'neko_shortcodes_iconspacer'));