<?php 
vc_map( 
	array(
		'name' => esc_html__( 'Stylish heading', 'neko-vcaddons' ),
		'base' => 'neko_heading',
		'class' => '',
		'icon' => plugin_dir_url( dirname( __FILE__ )  ) . 'img/icon_heading.png',
		'category' => esc_html__( 'Neko shortcodes', 'neko-vcaddons'),
		'params' => array(

			/**
			 * TITLE HIERARCHY
			 */	
			array(
				'type' => 'dropdown',
				'class' => '',
				'heading' => esc_html__( 'Title size', 'neko-vcaddons' ),
				'param_name' => 'titlehierarchy',
				'value' => array(
					esc_html__( 'Medium Heading', 'neko-vcaddons' ) => 'h1',
					esc_html__( 'Large Heading', 'neko-vcaddons' )  => 'big-heading',
					esc_html__( 'Small Heading', 'neko-vcaddons' )  => 'h2'
					),
				'admin_label' => false
				),

			/**
			 * TITLE
			 */		    	
			array(
				'type' => 'textfield',
				'class' => '',
				'heading' => esc_html__( 'Title text', 'neko-vcaddons' ),
				'param_name' => 'title',
				'admin_label' => true,
				'value' => ''
				),

			/**
			 * SUB TITLE
			 */	
			array(
				'type' => 'textfield',
				'class' => '',
				'heading' => esc_html__( 'Sub-title text', 'neko-vcaddons' ),
				'param_name' => 'subtitle',
				'admin_label' => true,
				'value' => ''
				),

	        /**
			 * SUBTITLE POSITION 
			 */	
	        array(
	        	'type' => 'dropdown',
	        	'class' => '',
	        	'heading' => esc_html__( 'Sub-title position', 'neko-vcaddons' ),
	        	'param_name' => 'subtitleposition',
	        	'value' => array(
	        		esc_html__( 'Above title', 'neko-vcaddons' ) => 'above-title',
	        		esc_html__( 'Under title', 'neko-vcaddons' ) => 'under-title'

	        		),
	        	'admin_label' => false
	        	),


			/**
			 * ALIGNMENT
			 */	
			array(
				'type' => 'dropdown',
				'class' => '',
				'heading' => esc_html__( 'Alignment', 'neko-vcaddons' ),
				'param_name' => 'alignment',
				'value' => array(
					esc_html__( 'Center', 'neko-vcaddons' ) => 'text-center',
					esc_html__( 'Left', 'neko-vcaddons' ) => 'text-left',
					esc_html__( 'Right', 'neko-vcaddons' ) => 'text-right',
					
					),
				'admin_label' => false
				),

	         /**
			 * TITLE COLOR
			 */	
	         array(
	         	'type' => 'colorpicker',
	         	'heading' => esc_html__( 'Title text color', 'neko-vcaddons' ),
	         	'param_name' => 'titlecolor',
	         	'description' => esc_html__( 'Leave blank for default customizer option', 'neko-vcaddons' )
	         	),


	    /**
			 * SUBTITLE COLOR
			 */	
	    array(
	    	'type' => 'colorpicker',
	    	'heading' => esc_html__( 'Sub-title text color', 'neko-vcaddons' ),
	    	'param_name' => 'subtitlecolor',
	    	'description' => esc_html__( 'Leave blank for default customizer option', 'neko-vcaddons' )
	    	),


			/**
			 * TITLE STYLES
			 */	
			array(
				'type' => 'checkbox',
				'class' => '',
				'heading' => esc_html__( 'Text Shadow', 'neko-vcaddons' ),
				'param_name' => 'titlestyles',
				'value' => array(
					esc_html__( 'Add shadow to the title', 'neko-vcaddons' ) => 'neko-text-shadow',	
					),
				'admin_label' => false
				),

			/**
			 * TITLE ANIMATION
			 */	
			array(
				'type' => 'dropdown',
				'heading' => esc_html__( 'CSS Animation', 'neko-vcaddons' ),
				'param_name' => 'css_animation',
				'admin_label' => false,
				'value' => array(
					esc_html__( 'No', 'neko-vcaddons' ) => '',
					esc_html__( 'Top to bottom', 'neko-vcaddons' ) => 'top-to-bottom',
					esc_html__( 'Bottom to top', 'neko-vcaddons' ) => 'bottom-to-top',
					esc_html__( 'Left to right', 'neko-vcaddons' ) => 'left-to-right',
					esc_html__( 'Right to left', 'neko-vcaddons' ) => 'right-to-left',
					esc_html__( 'Appear from center', 'neko-vcaddons' ) => 'appear'
					),
				'description' => esc_html__( 'Select type of animation for element to be animated when it "enters" the browsers viewport (Note: works only in modern browsers).', 'neko-vcaddons' )
				),

			/**
			 * SHOW ICON
			 */	
			array(
				'type' => 'dropdown',
				'class' => '',
				'heading' => esc_html__( 'Display icon behind the title', 'neko-vcaddons' ),
				'param_name' => 'showicon',
				'value' => array(
					esc_html__( 'On', 'neko-vcaddons' ) => 'show-neko-icon-on',
					esc_html__( 'Off', 'neko-vcaddons' ) => 'show-neko-icon-off'	
					),
				'admin_label' => false
				),

			/**
			 * ICON TYPE (font icon or svg)
			 */	
			array(
				'type' => 'dropdown',
				'class' => '',
				'heading' => esc_html__( 'Icon Type', 'neko-vcaddons' ),
				'param_name' => 'iconsource',
				'value' => array(
					esc_html__( 'Theme icon (font icon)', 'neko-vcaddons' ) => 'neko-icontype-font',
					esc_html__( 'SVG icon', 'neko-vcaddons' ) => 'neko-icontype-svg'	
					),
				'admin_label' => false,
				'dependency' => array(
					'element' => 'showicon',
					'value' => 'show-neko-icon-on',
					),
				),	

			/**
			 * UPLOAD ICON SVG
			 */	
			array(
				'type' => 'attach_image',
				'class' => '',
				'heading' => esc_html__( 'Upload SVG Icon', 'neko-vcaddons' ),
				'param_name' => 'iconsvg',
				'admin_label' => false,
				'dependency' => array(
					'element' => 'iconsource',
					'value' => 'neko-icontype-svg',
					),
				),	

	    	/**
			 * ICON FAMILY THEME ICON
			 */	
	    	array(
	    		'type' => 'textfield',
	    		'heading' => esc_html__( 'Icon', 'neko-vcaddons' ),
	    		'param_name' => 'icon_customicons',
	    		'value' => '', 
	    		'dependency' => array(
	    			'element' => 'iconsource',
	    			'value' => 'neko-icontype-font',
	    			),
	    		'description' => sprintf(wp_kses(__( 'Copy and paste the icon class name in this field to use Theme icons. click <a href="%s" target="_blank">here</a> to select the icon that fits your need', 'neko-vcaddons' ), array( 'a' => array( 'href' => array(), 'title' => array(), 'target' => array() ) )), ''.get_stylesheet_directory_uri().'/font-icons/custom-icons/demo.html'),
	    		),


	         /**
			 * ICON COLOR
			 */	
	         array(
	         	'type' => 'colorpicker',
	         	'heading' => esc_html__( 'Icon color', 'neko-vcaddons' ),
	         	'param_name' => 'iconcolor',
	         	'description' => esc_html__( 'Leave blank for default customizer option', 'neko-vcaddons' ),
	         	'dependency' => array(
	         		'element' => 'iconsource',
	         		'value' => 'neko-icontype-font',
	         		),
	         	),

	         /**
			 * ICON OFFSET
			 */	
	         array(
	         	'type' => 'textfield',
	         	'heading' => esc_html__( 'Icon offset', 'neko-vcaddons' ),
	         	'param_name' => 'iconoffset',
	         	'description' => esc_html__( 'Leave blank for default icon position', 'neko-vcaddons' ),
	         	'dependency' => array(
	         		'element' => 'showicon',
	         		'value' => 'show-neko-icon-on',
	         		),
	         	),

	         /**
	          *  el class
	          */
	         array(
	         	'type' => 'textfield',
	         	'heading' => esc_html__('Extra class name', 'neko-vcaddons'),
	         	'param_name' => 'el_class',
	         	'description' => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'neko-vcaddons')
	         	),

	         /**
	          *  el id
	          */
	         array(
	         	'type' => 'textfield',
	         	'heading' => esc_html__('Extra id name', 'neko-vcaddons'),
	         	'param_name' => 'el_id',
	         	'description' => esc_html__('If you wish to style particular content element differently, then use this field to add an id name and then refer to it in your css file.', 'neko-vcaddons')
	         	),

	        /**
	         *  Design option panel
	         */
	        array(
	        	'type' => 'css_editor',
	        	'heading' => esc_html__( 'Css', 'neko-vcaddons' ),
	        	'param_name' => 'css',
	        	'group' => esc_html__( 'Design options', 'neko-vcaddons' ),
	        	)
	        )
)
);

add_shortcode('neko_heading', array( $this, 'neko_shortcodes_heading'));