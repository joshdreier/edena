<?php 
vc_map( 
	array(
		'name' => esc_html__( 'Neko Image Box', 'neko-vcaddons' ),
		'base' => 'neko_imagebox',
		'class' => '',
		'icon' => plugin_dir_url( dirname( __FILE__ )  ) . 'img/icon_image_box.png',
		'category' => esc_html__( 'Neko shortcodes', 'neko-vcaddons'),
		'js_view' => 'VcIconElementView_Backend',
	    // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
	    // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
		"params" => array(

      /**
       *  IMAGE
       */
      array(
      	'type' => 'attach_image',
      	'class' => '',
      	'heading' => esc_html__( 'Image', 'neko-vcaddons' ),
      	'param_name' => 'image',
      	'admin_label' => false,
      	'value' => '',
      	'description' => '',
				'admin_label' => true
      	),


	    /**
			 * IMAGE SHAPE
			 */	
	    array(
	    	'type' => 'dropdown',
	    	'class' => '',
	    	'heading' => esc_html__( 'Image shape', 'neko-vcaddons' ),
	    	'param_name' => 'image_shape',
	    	'value' => array(
	    		'Default' => 'default',
	    		'Circle'  => 'circle',
	    		'Rounded' => 'rounded',
	    		'Squared' => 'squared'
	    		),
	    	'description' => ''
	    	),

		    /**
				 * IMAGE SIZE
				 */	
		    array(
		    	'type' => 'dropdown',
		    	'class' => '',
		    	'heading' => esc_html__( 'Image size', 'neko-vcaddons' ),
		    	'param_name' => 'image_size',
		    	'value' => array(
		    		'Medium'   => 'medium',
		    		'Large'    => 'large',
		    		'X-large'  => 'x-large',
		    		),
		    	'description' =>  ''
		    	),


	    /**
			 * IMAGE ANIMATION
			 */
	    array(
	    	'type' => 'checkbox',
	    	'heading' => esc_html__( 'Animated image on hover', 'neko-vcaddons' ),
	    	'param_name' => 'image_anim',
	    	'value' => array( esc_html__( 'Animate', 'neko-vcaddons' ) => 'yes' )
	    	),		




			/**
			 *  IMAGE BORDER
			 */	
			array(
				'type' => 'checkbox',
				'heading' => esc_html__( 'Image border', 'neko-vcaddons' ),
				'param_name' => 'image_border',
				'admin_label' => false,			
				'dependency' => array(
					'element' => 'image_shape',
					'value' => array('circle', 'rounded', 'squared'),
					),
				'description' => ''
				),


				/**
				 *  BORDER COLOR
				 */	
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__( "Image border color", "neko" ),
					'param_name' => 'image_bordercolor',
					'admin_label' => false,
					'dependency' => array( 'element' => 'image_border', 'value' => 'true', ),
					'description' => ''
					),


				/**
				 *  BORDER STYLE
				 */	
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( "Image border style", "neko" ),
					'param_name' => 'image_borderstyle',
					'admin_label' => false,
					'value' => array(
						esc_html__( 'Solid', 'neko-vcaddons' )  => 'solid',
						esc_html__( 'Dotted', 'neko-vcaddons' ) => 'dotted',
						esc_html__( 'Dashed', 'neko-vcaddons' ) => 'dashed',
						esc_html__( 'Double', 'neko-vcaddons' ) => 'double',
						esc_html__( 'Groove', 'neko-vcaddons' ) => 'groove',
						esc_html__( 'Ridge', 'neko-vcaddons' )  => 'ridge',
						),

					'dependency' => array( 'element' => 'image_border', 'value' => 'true', ),
					'description' => ''
					),

         /**
				 *  BORDER SIZE
				 */	
         array(
         	'type' => 'textfield',
         	'heading' => esc_html__( "Border size", "neko" ),
         	'param_name' => 'image_bordersize',
         	'admin_label' => false,
         	'dependency' => array( 'element' => 'image_border', 'value' => 'true', ),
         	'description' => ''
         	),

         

	    	/**
			 * ICON BOX CONTENT
			 */
	    	array(
	    		'type' => 'textarea_html',
	    		'class' => '',
	    		'heading' => esc_html__( 'Content', 'neko-vcaddons' ),
	    		'param_name' => 'content',
	    		'value' =>  '',
	    		'description' => esc_html__( 'Enter content text here', 'neko-vcaddons' )
	    		),

	    	/**
			 * LINK BUILDER
			 */
	    	array(
	    		'type' => 'vc_link',
	    		'heading' => esc_html__( 'Link (url)', 'neko-vcaddons' ),
	    		'class' => '',
	    		'param_name' => 'link',
	    		'description' => ''
	    		),


			/**
			 * ICON BOX ANIMATION
			 */	
			array(
				'type' => 'dropdown',
				'heading' => esc_html__( 'CSS Animation', 'neko-vcaddons' ),
				'param_name' => 'css_animation',
				'admin_label' => false,
				'value' => array(
					esc_html__( 'No', 'neko-vcaddons' ) => '',
					esc_html__( 'Top to bottom', 'neko-vcaddons' ) => 'top-to-bottom',
					esc_html__( 'Bottom to top', 'neko-vcaddons' ) => 'bottom-to-top',
					esc_html__( 'Left to right', 'neko-vcaddons' ) => 'left-to-right',
					esc_html__( 'Right to left', 'neko-vcaddons' ) => 'right-to-left',
					esc_html__( 'Appear from center', 'neko-vcaddons' ) => 'appear'
					),
				'description' => esc_html__( 'Select type of animation for element to be animated when it "enters" the browsers viewport (Note: works only in modern browsers).', 'neko-vcaddons' )
				),



			array(
				'type'       => 'textfield',
				'heading'    => esc_html__('Extra class name', 'neko-vcaddons'),
				'param_name' => 'el_class',
				'description' => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'neko-vcaddons')
				),

			array(
				'type' => 'textfield',
				'heading' => esc_html__('Extra class name', 'neko-vcaddons'),
				'param_name' => 'el_id',
				'description' => esc_html__('If you wish to style particular content element differently, then use this field to add an id name and then refer to it in your css file.', 'neko-vcaddons')
				),
	  	  /**
	       *  Design option panel
	       */
	  	  array(
	  	  	'type' => 'css_editor',
	  	  	'heading' => esc_html__( 'Css', 'neko-vcaddons' ),
	  	  	'param_name' => 'css',
	  	  	'group' => esc_html__( 'Design options', 'neko-vcaddons' ),
	  	  	)  	
	  	  )
)
);


add_shortcode('neko_imagebox', array( $this, 'neko_shortcodes_imagebox'));
