<?php 
	vc_map( 
		array(
			'name' => esc_html__( 'Neko Call to action', 'neko-vcaddons' ),
			'base' => 'neko_calltoaction',
			'class' => '',
			'icon' => plugin_dir_url( dirname( __FILE__ )  ) . 'img/icon_calltoaction.png',
			'category' => esc_html__( 'Neko shortcodes', 'neko-vcaddons'),
		    // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
		    // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
			'params' => array(


				/**
				 * Layout
				 */	
		         array(
		            'type' => 'dropdown',
		            'class' => '',
		            'heading' => esc_html__( 'Layout', 'neko-vcaddons' ),
		            'param_name' => 'layout',
					'value' => array(
						esc_html__( 'Default', 'neko-vcaddons' ) => 'cta-box-2cols',
						esc_html__( 'Centered', 'neko-vcaddons' ) => 'cta-box-centered',
						esc_html__( 'Centered 2 button', 'neko-vcaddons' ) => 'cta-box-centered-2-btn',
						
					),
					'admin_label' => false,
		            'description' => esc_html__( 'Set the layout of your call to action box', 'neko-vcaddons' )
		        ),


		         /**
				 * TITLE COLOR
				 */	
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Title color', 'neko-vcaddons' ),
					'param_name' => 'titlecolor',
					'description' => esc_html__( 'Set the title color (leave blank for default)', 'neko-vcaddons' )
				),


		         /**
				 * TEXT COLOR
				 */	
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Text color', 'neko-vcaddons' ),
					'param_name' => 'textcolor',
					'description' => esc_html__( 'Set the text color (leave blank for default)', 'neko-vcaddons' )
				),



				/**
				 * Title
				 */		    	
				array(
					'type' => 'textfield',
					'class' => '',
					'heading' => esc_html__( 'Title', 'neko-vcaddons' ),
					'param_name' => 'title',
					'admin_label' => true,
					'value' => '',
					'description' => esc_html__( 'Enter title here', 'neko-vcaddons' )
					),


				/**
				 * Content
				 */	
			    array(
		            'type' => 'textarea_html',
		            'class' => '',
		            'heading' => esc_html__( 'Content', 'neko-vcaddons' ),
		            'param_name' => 'content',
		            'value' => '', //esc_html__( '', 'neko-vcaddons' ),
		            'description' => esc_html__( 'Enter content text here', 'neko-vcaddons' )
		        ),


		    	/**
				 * LINK BUILDER
				 */
			    array(
		            'type' => 'vc_link',
		            'heading' => esc_html__( 'Link', 'neko-vcaddons' ),
		            'class' => '',
		            'param_name' => 'link',
		            'description' => esc_html__( 'Add a link to the calltoaction box', 'neko-vcaddons' )
		        ),		        

		    	/**
				 * LINK BUILDER 2
				 */
			    array(
		            'type' => 'vc_link',
		            'heading' => esc_html__( 'Link button 2', 'neko-vcaddons' ),
		            'class' => '',
		            'param_name' => 'link2',
		            'description' => esc_html__( 'Add a second link to the calltoaction box', 'neko-vcaddons' ),
					'dependency' => array(
						'element' => 'layout',
						'value'   => 'cta-box-centered-2-btn',
					),		        
		        ),	

		        /**
				 * Button size
				 */
			     array(
		            'type' => 'dropdown',
		            'class' => '',
		            'heading' => esc_html__( 'Button size', 'neko-vcaddons' ),
		            'param_name' => 'button_size',
					'value' => array(
						esc_html__( 'Default', 'neko-vcaddons' ) => '',
						esc_html__( 'Large', 'neko-vcaddons' ) => 'btn-lg',
						
					),
					'admin_label' => false,
		            'description' => ''
		        ),



				/**
				 * CALL TO ACTION ANIMATION
				 */	
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'CSS Animation', 'neko-vcaddons' ),
					'param_name' => 'css_animation',
					'admin_label' => false,
					'value' => array(
						esc_html__( 'No', 'neko-vcaddons' ) => '',
						esc_html__( 'Top to bottom', 'neko-vcaddons' ) => 'top-to-bottom',
						esc_html__( 'Bottom to top', 'neko-vcaddons' ) => 'bottom-to-top',
						esc_html__( 'Left to right', 'neko-vcaddons' ) => 'left-to-right',
						esc_html__( 'Right to left', 'neko-vcaddons' ) => 'right-to-left',
						esc_html__( 'Appear from center', 'neko-vcaddons' ) => 'appear'
						),
					'description' => esc_html__( 'Select type of animation for element to be animated when it "enters" the browsers viewport (Note: works only in modern browsers).', 'neko-vcaddons' )
					),



		        /**
		         *  el class
		         */
		        array(
		        	'type' => 'textfield',
		        	'heading' => esc_html__('Extra class name', 'neko-vcaddons'),
		        	'param_name' => 'el_class',
		        	'description' => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'neko-vcaddons')
		        	),

		        /**
		         *  el id
		         */
		        array(
		        	'type' => 'textfield',
		        	'heading' => esc_html__('Extra id name', 'neko-vcaddons'),
		        	'param_name' => 'el_id',
		        	'description' => esc_html__('If you wish to style particular content element differently, then use this field to add an id name and then refer to it in your css file.', 'neko-vcaddons')

		        ),

				array(
					'type' => 'css_editor',
					'heading' => esc_html__( 'Css', 'neko-vcaddons' ),
					'param_name' => 'css',
					'group' => esc_html__( 'Design options', 'neko-vcaddons' ),
				)

		    )
		)
	);

	add_shortcode('neko_calltoaction', array( $this, 'neko_shortcodes_calltoaction'));