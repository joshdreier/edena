<?php
vc_map( 
	array(
		'name' => esc_html__( 'Neko Banner', 'neko-vcaddons' ),
		'base' => 'neko_banner',
		'class' => '',
		'icon' => plugin_dir_url( dirname( __FILE__ )  ) . 'img/icon_banner.png',
		'category' => esc_html__( 'Neko shortcodes', 'neko-vcaddons'),

		'params' => array(


		    /**
				 * TITLE COLOR
				 */	
		    array(
		    	'type' => 'colorpicker',
		    	'heading' => esc_html__( 'Title color', 'neko-vcaddons' ),
		    	'param_name' => 'titlecolor',
		    	'description' => esc_html__( 'Set the title color (leave blank for default)', 'neko-vcaddons' )
		    	),



				/**
				 * Title
				 */		    	
				array(
					'type' => 'textfield',
					'class' => '',
					'heading' => esc_html__( 'Title', 'neko-vcaddons' ),
					'param_name' => 'title',
					'admin_label' => true,
					'value' => '',
					'description' => esc_html__( 'Enter title here', 'neko-vcaddons' )
					),


	      /**
	       *  Images
	       */
	      array(
	      	'type' => 'attach_image',
	      	'class' => '',
	      	'heading' => esc_html__( 'Image', 'neko-vcaddons' ),
	      	'param_name' => 'image',
	      	'admin_label' => false,
	      	'value' => '',
	      	'description' => esc_html__( 'Select or upload an image for the banner', 'neko-vcaddons' ),
					'admin_label' => true
	      	),

	      /**
	       *  Images overlay
	       */
	      array(
	      	'type' => 'checkbox',
	      	'class' => '',
	      	'heading' => esc_html__( 'Image Overlay', 'neko-vcaddons' ),
	      	'param_name' => 'activateoverlay',
	      	'admin_label' => false,
	      	'value' => '',
	      	'description' => esc_html__( 'Activate the banner image overlay', 'neko-vcaddons' )
	      	),

	      /**
	       *  Images overlay color
	       */
	      array(
	      	'type' => 'colorpicker',
	      	'class' => '',
	      	'heading' => esc_html__( 'Image Overlay color', 'neko-vcaddons' ),
	      	'param_name' => 'overlaycolor',
	      	'dependency' => Array('element' => 'activateoverlay', 'value' => array('true')),
	      	'description' => esc_html__( 'Set the banner image overlay color', 'neko-vcaddons' )
	      	),


		    /**
				 * CONTENT COLOR
				 */	
		    /*array(
		    	'type' => 'colorpicker',
		    	'heading' => esc_html__( 'Text color', 'neko-vcaddons' ),
		    	'param_name' => 'contentcolor',
		    	'description' => esc_html__( 'Set the content color (leave blank for default)', 'neko-vcaddons' )
		    	),*/


				/**
				 * Content
				 */	
				array(
					'type' => 'textarea_html',
					'class' => '',
					'heading' => esc_html__( 'Content', 'neko-vcaddons' ),
					'param_name' => 'content',
		            'value' => '', //esc_html__( '', 'neko-vcaddons' ),
		            'description' => esc_html__( 'Enter content text here', 'neko-vcaddons' )
		            ),


			    /**
					 * LINK BUILDER
					 */
		    	array(
		    		'type' => 'vc_link',
		    		'heading' => esc_html__( 'Link', 'neko-vcaddons' ),
		    		'class' => '',
		    		'param_name' => 'link',
		    		'description' => esc_html__( 'Add a link to the calltoaction box', 'neko-vcaddons' )
		    		),		        


					/**
					 *  ANIMATION
					 */	
					array(
						'type' => 'dropdown',
						'heading' => esc_html__( 'CSS Animation', 'neko-vcaddons' ),
						'param_name' => 'css_animation',
						'admin_label' => false,
						'value' => array(
							esc_html__( 'No', 'neko-vcaddons' ) => '',
							esc_html__( 'Top to bottom', 'neko-vcaddons' ) => 'top-to-bottom',
							esc_html__( 'Bottom to top', 'neko-vcaddons' ) => 'bottom-to-top',
							esc_html__( 'Left to right', 'neko-vcaddons' ) => 'left-to-right',
							esc_html__( 'Right to left', 'neko-vcaddons' ) => 'right-to-left',
							esc_html__( 'Appear from center', 'neko-vcaddons' ) => 'appear'
							),
						'description' => esc_html__( 'Select type of animation for element to be animated when it "enters" the browsers viewport (Note: works only in modern browsers).', 'neko-vcaddons' )
						),



		        /**
		         *  el class
		         */
		        array(
		        	'type' => 'textfield',
		        	'heading' => esc_html__('Extra class name', 'neko-vcaddons'),
		        	'param_name' => 'el_class',
		        	'description' => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'neko-vcaddons')
		        	),

		        /**
		         *  el id
		         */
		        array(
		        	'type' => 'textfield',
		        	'heading' => esc_html__('Extra id name', 'neko-vcaddons'),
		        	'param_name' => 'el_id',
		        	'description' => esc_html__('If you wish to style particular content element differently, then use this field to add an id name and then refer to it in your css file.', 'neko-vcaddons')

		        	),


		        /**
		         *  css editor
		         */
		        array(
		        	'type' => 'css_editor',
		        	'heading' => esc_html__( 'Css', 'neko-vcaddons' ),
		        	'param_name' => 'css',
		        	'group' => esc_html__( 'Design options', 'neko-vcaddons' ),
		        	)

		        )
)
);

add_shortcode('neko_banner', array( $this, 'neko_shortcodes_banner'));
