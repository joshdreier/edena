<?php 
	vc_map( 
		array(
			'name' => esc_html__( 'Neko Testimonial', 'neko-vcaddons' ),
			'base' => 'neko_testimonial',
			'class' => '',
			'icon' => plugin_dir_url( dirname( __FILE__ )  ) . 'img/icon_testimonial.png',
			'category' => esc_html__( 'Neko shortcodes', 'neko-vcaddons'),
		    // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
		    // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
			'params' => array(

				/**
				 * Name
				 */		    	
				array(
					'type' => 'textfield',
					'class' => '',
					'heading' => esc_html__( 'Name', 'neko-vcaddons' ),
					'param_name' => 'name',
					'admin_label' => true,
					'value' => '',
					'description' => esc_html__( 'Enter name here', 'neko-vcaddons' )
					),

				/**
				 * FUNCTION
				 */	
				array(
					'type' => 'textfield',
					'class' => '',
					'heading' => esc_html__( 'Function', 'neko-vcaddons' ),
					'param_name' => 'function',
					'admin_label' => false,
					'value' => '',
					'description' => esc_html__( 'Enter function here', 'neko-vcaddons' )
					),


				/**
				 * AVATAR
				 */	
				array(
					'type' => 'attach_image',
					'class' => '',
					'heading' => esc_html__( 'Avatar', 'neko-vcaddons' ),
					'param_name' => 'avatar_id',
					'admin_label' => false,
					'value' => '',
					'description' => esc_html__( 'Set the avatar here', 'neko-vcaddons' )
					),

				/**
				 * BACKGROUND COLOR
				 */	
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__( "Background color", "neko" ),
					'param_name' => 'background_color',
					'description' => esc_html__( "Set the icon background color", "neko" )
				),

				/**
				 * TEXT COLOR
				 */	
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__( "Text color", "neko" ),
					'param_name' => 'text_color',
					'description' => esc_html__( "Set the text color", "neko" )
				),


				/**
				 * Content
				 */	
			    array(
		            'type' => 'textarea_html',
		            'class' => '',
		            'heading' => esc_html__( 'Content', 'neko-vcaddons' ),
		            'param_name' => 'content',
		            'value' =>  '', //esc_html__( '', 'neko-vcaddons' ),
		            'description' => esc_html__( 'Enter content text here', 'neko-vcaddons' )
		        ),



				/**
				 * TESTIMONIAL ANIMATION
				 */	
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'CSS Animation', 'neko-vcaddons' ),
					'param_name' => 'css_animation',
					'admin_label' => false,
					'value' => array(
						esc_html__( 'No', 'neko-vcaddons' ) => '',
						esc_html__( 'Top to bottom', 'neko-vcaddons' ) => 'top-to-bottom',
						esc_html__( 'Bottom to top', 'neko-vcaddons' ) => 'bottom-to-top',
						esc_html__( 'Left to right', 'neko-vcaddons' ) => 'left-to-right',
						esc_html__( 'Right to left', 'neko-vcaddons' ) => 'right-to-left',
						esc_html__( 'Appear from center', 'neko-vcaddons' ) => 'appear'
						),
					'description' => esc_html__( 'Select type of animation for element to be animated when it "enters" the browsers viewport (Note: works only in modern browsers).', 'neko-vcaddons' )
					),




		        /**
		         *  el class
		         */
		        array(
		        	'type' => 'textfield',
		        	'heading' => esc_html__('Extra class name', 'neko-vcaddons'),
		        	'param_name' => 'el_class',
		        	'description' => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'neko-vcaddons')
		        	),

		        /**
		         *  el id
		         */
		        array(
		        	'type' => 'textfield',
		        	'heading' => esc_html__('Extra id name', 'neko-vcaddons'),
		        	'param_name' => 'el_id',
		        	'description' => esc_html__('If you wish to style particular content element differently, then use this field to add an id name and then refer to it in your css file.', 'neko-vcaddons')

		        )
		    )
		)
	);


	add_shortcode('neko_testimonial', array( $this, 'neko_shortcodes_testimonial'));