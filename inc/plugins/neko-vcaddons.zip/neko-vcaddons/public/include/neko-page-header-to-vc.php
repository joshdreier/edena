<?php
vc_map( 
	array(
		'name' => esc_html__( 'Neko Page Header', 'neko-vcaddons' ),
		'base' => 'neko_page_header',
		'class' => '',
		'icon' => plugin_dir_url( dirname( __FILE__ )  ) . 'img/icon_pageheader.png',
		'category' => esc_html__( 'Neko shortcodes', 'neko-vcaddons'),
		'params' => array(

				/**
				 *  LAYOUT
				 */	
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Page header layout', 'neko-vcaddons' ),
					'param_name' => 'pageheader_layout',
					'admin_label' => false,
					'value' => array(
						esc_html__( 'Left', 'neko-vcaddons' ) => 'left',
						esc_html__( 'Center', 'neko-vcaddons' ) => 'center',
						esc_html__( 'Right', 'neko-vcaddons' ) => 'right',
						esc_html__( '2 columns', 'neko-vcaddons' ) => '2-cols'
						),
					'description' => esc_html__( 'Select the layout of your page header', 'neko-vcaddons' )
					),


				/**
				 *  SIZE
				 */	
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Page header size', 'neko-vcaddons' ),
					'param_name' => 'pageheader_size',
					'admin_label' => false,
					'value' => array(
						esc_html__( 'No spacing', 'neko-vcaddons' ) => '',
						esc_html__( 'Small', 'neko-vcaddons' ) => 'small',
						esc_html__( 'Medium', 'neko-vcaddons' ) => 'medium',
						esc_html__( 'Large', 'neko-vcaddons' ) => 'large',
						esc_html__( 'X large', 'neko-vcaddons' ) => 'xlarge'
						),
					'description' => esc_html__( 'Select the size of your page header', 'neko-vcaddons' )
					),




		    /**
				 * TITLE COLOR
				 */	
		    array(
		    	'type' => 'colorpicker',
		    	'heading' => esc_html__( 'Title color', 'neko-vcaddons' ),
		    	'param_name' => 'title_color',
		    	'description' => esc_html__( 'Set the title color (leave blank for default)', 'neko-vcaddons' )
		    	),


				/**
				 *  TITLE ANIMATION
				 */	
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Title CSS Animation', 'neko-vcaddons' ),
					'param_name' => 'title_css_animation',
					'admin_label' => false,
					'value' => array(
						esc_html__( 'No', 'neko-vcaddons' ) => '',
						esc_html__( 'Top to bottom', 'neko-vcaddons' ) => 'top-to-bottom',
						esc_html__( 'Bottom to top', 'neko-vcaddons' ) => 'bottom-to-top',
						esc_html__( 'Left to right', 'neko-vcaddons' ) => 'left-to-right',
						esc_html__( 'Right to left', 'neko-vcaddons' ) => 'right-to-left',
						esc_html__( 'Appear from center', 'neko-vcaddons' ) => 'appear'
						),
					'description' => esc_html__( 'Select type of animation for element to be animated when it "enters" the browsers viewport (Note: works only in modern browsers).', 'neko-vcaddons' )
					),



				/**
				 * TITLE
				 */		    	
				array(
					'type' => 'textfield',
					'class' => '',
					'heading' => esc_html__( 'Title', 'neko-vcaddons' ),
					'param_name' => 'title',
					'admin_label' => true,
					'value' => '',
					'description' => esc_html__( 'Enter title here', 'neko-vcaddons' )
					),


	

				/**
				 *  CONTENT ANIMATION
				 */	
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Content CSS Animation', 'neko-vcaddons' ),
					'param_name' => 'content_css_animation',
					'admin_label' => false,
					'value' => array(
						esc_html__( 'No', 'neko-vcaddons' ) => '',
						esc_html__( 'Top to bottom', 'neko-vcaddons' ) => 'top-to-bottom',
						esc_html__( 'Bottom to top', 'neko-vcaddons' ) => 'bottom-to-top',
						esc_html__( 'Left to right', 'neko-vcaddons' ) => 'left-to-right',
						esc_html__( 'Right to left', 'neko-vcaddons' ) => 'right-to-left',
						esc_html__( 'Appear from center', 'neko-vcaddons' ) => 'appear'
						),
					'description' => esc_html__( 'Select type of animation for element to be animated when it "enters" the browsers viewport (Note: works only in modern browsers).', 'neko-vcaddons' )
					),


				/**
				 * CONTENT
				 */	
				array(
					'type' => 'textarea_html',
					'class' => '',
					'heading' => esc_html__( 'Content', 'neko-vcaddons' ),
					'param_name' => 'content',
					'value' => '',
					'description' => esc_html__( 'Enter content text here', 'neko-vcaddons' )
					),


				/**
				 *  BREADCRUMB
				 */	
				array(
					'type' => 'checkbox',
					'heading' => esc_html__( 'Page header breadcrumb', 'neko-vcaddons' ),
					'param_name' => 'breadcrumb',
					'admin_label' => false,
					'description' => esc_html__( 'Show the breadcrumb for the page', 'neko-vcaddons' )
					),

				/**
				 *  BREADCRUMB SKIN
				 */	
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Breadcrumb skin', 'neko-vcaddons' ),
					'param_name' => 'breadcrumb_skin',
					'admin_label' => false,
					'value' => array(
						esc_html__( 'Light', 'neko-vcaddons' ) => 'light',
						esc_html__( 'Dark', 'neko-vcaddons' ) => 'dark',
						),

					'dependency' => array( 'element' => 'breadcrumb', 'value' => 'true', ),
					'description' => esc_html__( 'Select the skin for your breadcrumb.', 'neko-vcaddons' )
					),

        /**
         *  el class
         */
        array(
        	'type' => 'textfield',
        	'heading' => esc_html__('Extra class name', 'neko-vcaddons'),
        	'param_name' => 'el_class',
        	'description' => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'neko-vcaddons')
        	),


        /**
         *  el id
         */
        array(
        	'type' => 'textfield',
        	'heading' => esc_html__('Extra id name', 'neko-vcaddons'),
        	'param_name' => 'el_id',
        	'description' => esc_html__('If you wish to style particular content element differently, then use this field to add an id name and then refer to it in your css file.', 'neko-vcaddons')

        	),


        /**
         *  css editor
         */
        array(
        	'type' => 'css_editor',
        	'heading' => esc_html__( 'Css', 'neko-vcaddons' ),
        	'param_name' => 'css',
        	'group' => esc_html__( 'Design options', 'neko-vcaddons' ),
        	)

		   )
		)
	);

add_shortcode('neko_page_header', array( $this, 'neko_shortcodes_page_header'));
