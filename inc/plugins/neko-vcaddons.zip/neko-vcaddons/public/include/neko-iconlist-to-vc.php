<?php 
vc_map( array(
	'name' => esc_html__('Neko icon list', 'neko-vcaddons'),
	'base' => 'neko_list_ul',
    'as_parent' => array('only' => 'neko_list_li'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    'icon' => plugin_dir_url( dirname( __FILE__ )  ) . 'img/icon_liste_ul.png',
    'category' => esc_html__( 'Neko shortcodes', 'neko-vcaddons'),
    'is_container' => true,
    'content_element' => true,
    'show_settings_on_create' => true,
    'js_view' => 'VcColumnView',
    'params' => array(
        // add params same as with any other content element
    	array(
    		'type' => 'textfield',
    		'heading' => esc_html__('Title', 'neko-vcaddons'),
    		'param_name' => 'ul_title',
            //'description' => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'neko-vcaddons')
    		),



		/**
		 * UL LIST ICON ANIMATION
		 */	
		array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'CSS Animation', 'neko-vcaddons' ),
			'param_name' => 'css_animation',
			'admin_label' => false,
			'value' => array(
				esc_html__( 'No', 'neko-vcaddons' ) => '',
				esc_html__( 'Top to bottom', 'neko-vcaddons' ) => 'top-to-bottom',
				esc_html__( 'Bottom to top', 'neko-vcaddons' ) => 'bottom-to-top',
				esc_html__( 'Left to right', 'neko-vcaddons' ) => 'left-to-right',
				esc_html__( 'Right to left', 'neko-vcaddons' ) => 'right-to-left',
				esc_html__( 'Appear from center', 'neko-vcaddons' ) => 'appear'
				),
			'description' => esc_html__( 'Select type of animation for element to be animated when it "enters" the browsers viewport (Note: works only in modern browsers).', 'neko-vcaddons' )
			),



    	array(
    		'type' => 'textfield',
    		'heading' => esc_html__('Extra class name', 'neko-vcaddons'),
    		'param_name' => 'el_class',
            "description" => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'neko-vcaddons')
    		),
    	array(
    		'type' => 'textfield',
    		'heading' => esc_html__('Id name', 'neko-vcaddons'),
    		'param_name' => 'el_id',
            "description" => esc_html__('If you wish to style particular content element differently, then use this field to add an id name and then refer to it in your css file.', 'neko-vcaddons')
    		),
    	),
));

add_shortcode('neko_list_ul', array( $this, 'neko_shortcodes_iconlist_ul'));



vc_map( array(
	'name' => esc_html__('Neko list element', 'neko-vcaddons'),
	'base' => 'neko_list_li',
    'as_child' => array('only' => 'neko_list_ul'), // Use only|except attributes to limit parent (separate multiple values with comma)
    'icon' => plugin_dir_url( dirname( __FILE__ )  ) . 'img/icon_liste_li.png',
    'is_container' => false,
    'content_element' => true,
    'js_view' => 'VcIconElementView_Backend',
    'params' => array(

	   /**
		* ICON FAMILY SELECTOR
		*/	
    	array(
    		'type' => 'dropdown',
    		'heading' => esc_html__( 'Icon library', 'neko-vcaddons' ),
    		'value' => array(
    			esc_html__( 'Edena icon', 'neko-vcaddons' ) => 'customicons',
    			esc_html__( 'Font Awesome', 'neko-vcaddons' ) => 'fontawesome',
    			esc_html__( 'Open Iconic', 'neko-vcaddons' ) => 'openiconic',
    			esc_html__( 'Typicons', 'neko-vcaddons' ) => 'typicons',
    			esc_html__( 'Entypo', 'neko-vcaddons' ) => 'entypo',
    			esc_html__( 'Linecons', 'neko-vcaddons' ) => 'linecons'

    			),
    		'admin_label' => false,
    		'param_name' => 'type',
    		'description' => esc_html__( 'Select icon library.', 'neko-vcaddons' ),
    		),

	    	/**
			 * ICON FAMILY FONTAWSOME
			 */	
	    	array(
	    		'type' => 'iconpicker',
	    		'heading' => esc_html__( 'Icon', 'neko-vcaddons' ),
	    		'param_name' => 'icon_fontawesome',
				'value' => 'fa fa-adjust', // default value to backend editor admin_label
				'settings' => array(
					'emptyIcon' => false, // default true, display an "EMPTY" icon?
					'iconsPerPage' => 4000, // default 100, how many icons per/page to display, we use (big number) to display all icons in single page
					),
				'dependency' => array(
					'element' => 'type',
					'value' => 'fontawesome',
					),
				'description' => esc_html__( 'Select icon from library.', 'neko-vcaddons' ),
				),

	    	/**
			 * ICON FAMILY ICONIC
			 */	
	    	array(
	    		'type' => 'iconpicker',
	    		'heading' => esc_html__( 'Icon', 'neko-vcaddons' ),
	    		'param_name' => 'icon_openiconic',
				'value' => 'vc-oi vc-oi-dial', // default value to backend editor admin_label
				'settings' => array(
					'emptyIcon' => false, // default true, display an "EMPTY" icon?
					'type' => 'openiconic',
					'iconsPerPage' => 4000, // default 100, how many icons per/page to display
					),
				'dependency' => array(
					'element' => 'type',
					'value' => 'openiconic',
					),
				'description' => esc_html__( 'Select icon from library.', 'neko-vcaddons' ),
				),

	    	/**
			 * ICON FAMILY TYPICONS
			 */	
	    	array(
	    		'type' => 'iconpicker',
	    		'heading' => esc_html__( 'Icon', 'neko-vcaddons' ),
	    		'param_name' => 'icon_typicons',
				'value' => 'typcn typcn-adjust-brightness', // default value to backend editor admin_label
				'settings' => array(
					'emptyIcon' => false, // default true, display an "EMPTY" icon?
					'type' => 'typicons',
					'iconsPerPage' => 4000, // default 100, how many icons per/page to display
					),
				'dependency' => array(
					'element' => 'type',
					'value' => 'typicons',
					),
				'description' => esc_html__( 'Select icon from library.', 'neko-vcaddons' ),
				),

	    	/**
			 * ICON FAMILY ENTYPO
			 */	
	    	array(
	    		'type' => 'iconpicker',
	    		'heading' => esc_html__( 'Icon', 'neko-vcaddons' ),
	    		'param_name' => 'icon_entypo',
				'value' => 'entypo-icon entypo-icon-note', // default value to backend editor admin_label
				'settings' => array(
					'emptyIcon' => false, // default true, display an "EMPTY" icon?
					'type' => 'entypo',
					'iconsPerPage' => 4000, // default 100, how many icons per/page to display
					),
				'dependency' => array(
					'element' => 'type',
					'value' => 'entypo',
					),
				),

	    	/**
			 * ICON FAMILY LINEICON
			 */	
	    	array(
	    		'type' => 'iconpicker',
	    		'heading' => esc_html__( 'Icon', 'neko-vcaddons' ),
	    		'param_name' => 'icon_linecons',
				'value' => 'vc_li vc_li-heart', // default value to backend editor admin_label
				'settings' => array(
					'emptyIcon' => false, // default true, display an "EMPTY" icon?
					'type' => 'linecons',
					'iconsPerPage' => 4000, // default 100, how many icons per/page to display
					),
				'dependency' => array(
					'element' => 'type',
					'value' => 'linecons',
					),
				'description' => esc_html__( 'Select icon from library.', 'neko-vcaddons' ),
				),


	    	/**
			 * ICON FAMILY THEME ICON
			 */	
	    	array(
	    		'type' => 'textfield',
	    		'heading' => esc_html__( 'Icon', 'neko-vcaddons' ),
	    		'param_name' => 'icon_customicons',
				'value' => '', // default value to backend editor admin_label
				'dependency' => array(
					'element' => 'type',
					'value' => 'customicons',
					),
				'description' => sprintf(wp_kses(__( 'Copy and paste the icon class name in this field to use Theme icons. click <a href="%s" target="_blank">here</a> to select the icon that fits your need', 'neko-vcaddons' ), array( 'a' => array( 'href' => array(), 'title' => array(), 'target' => array() ) )), ''.get_stylesheet_directory_uri().'/font-icons/custom-icons/demo.html'),
				),

	    	array(
	    		'type' => 'colorpicker',
	    		'heading' => esc_html__( 'Icon list icon color', 'neko-vcaddons' ),
	    		'param_name' => 'icon_color',
	    		'description' => esc_html__( 'Configure the color of the icon', 'neko-vcaddons' )
	    		),

	    	array(
	    		'type' => 'colorpicker',
	    		'heading' => esc_html__( 'Icon list text color', 'neko-vcaddons' ),
	    		'param_name' => 'txt_color',
	    		'description' => esc_html__( 'Configure the color of the text', 'neko-vcaddons' )
	    		),

	    	array(
	    		'type'        => 'textfield',
	    		'heading'     => esc_html__('Text', 'neko-vcaddons'),
	    		'param_name'  => 'li_text',
	    		'admin_label' => true,
	    		'description' =>  ''
	    		),

	    	array(
	    		'type'       => 'textfield',
	    		'heading'    => esc_html__('Extra class name', 'neko-vcaddons'),
	    		'param_name' => 'el_class',
	    		"description" => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'neko-vcaddons')
	    		),
	    	array(
	    		'type' => 'textfield',
	    		'heading' => esc_html__('Id name', 'neko-vcaddons'),
	    		'param_name' => 'el_id',
	    		"description" => esc_html__('If you wish to style particular content element differently, then use this field to add an id name and then refer to it in your css file.', 'neko-vcaddons')
	    		),
	    	)
));

add_shortcode('neko_list_li', array( $this, 'neko_shortcodes_iconlist_li'));

//Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
		if ( !class_exists( 'WPBakeryShortCode_neko_list_ul' ) ) {
	    class WPBakeryShortCode_neko_list_ul extends WPBakeryShortCodesContainer {
	    }
  	}
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
	if ( !class_exists( 'WPBakeryShortCode_neko_list_li' ) ) {
    class WPBakeryShortCode_neko_list_li extends WPBakeryShortCode {
    }
  }
}