<?php 
	vc_map( 
		array(
			'name' => esc_html__( 'Neko Image Grid', 'neko-vcaddons' ),
			'base' => 'neko_imagegrid',
			'class' => '',
			'icon' => plugin_dir_url( dirname( __FILE__ )  ) . 'img/icon_imagegrid.png',
			'category' => esc_html__( 'Neko shortcodes', 'neko-vcaddons'),
		    // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
		    // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
			'params' => array(


		        /**
		         *  Images
		         */
				array(
					'type' => 'attach_images',
					'class' => '',
					'heading' => esc_html__( 'Images', 'neko-vcaddons' ),
					'param_name' => 'images',
					'admin_label' => false,
					'value' => '',
					'description' => esc_html__( 'add grid images here', 'neko-vcaddons' )
					),



				/**
				 * nb column
				 */	
		         array(
		            'type' => 'dropdown',
		            'class' => '',
		            'heading' => esc_html__( 'Column number', 'neko-vcaddons' ),
		            'param_name' => 'colnumber',
					'value' => array(
						esc_html__( '4 columns', 'neko-vcaddons' ) => 4,
						esc_html__( '3 columns', 'neko-vcaddons' ) => 3,
						esc_html__( '6 columns', 'neko-vcaddons' ) => 6
						
					),
					'admin_label' => false,
					'std'         => 4,
		            'description' => esc_html__( 'Set the layout of your call to action box', 'neko-vcaddons' )
		        ),



		         /**
				 * BORDER COLOR
				 */	
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Border color', 'neko-vcaddons' ),
					'param_name' => 'bordercolor',
					'description' => esc_html__( 'Set the border color (leave blank for default)', 'neko-vcaddons' )
				),


		        /**
		         *  el class
		         */
		        array(
		        	'type' => 'textfield',
		        	'heading' => esc_html__('Extra class name', 'neko-vcaddons'),
		        	'param_name' => 'el_class',
		        	'description' => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'neko-vcaddons')
		        	),

		        /**
		         *  el id
		         */
		        array(
		        	'type' => 'textfield',
		        	'heading' => esc_html__('Extra id name', 'neko-vcaddons'),
		        	'param_name' => 'el_id',
		        	'description' => esc_html__('If you wish to style particular content element differently, then use this field to add an id name and then refer to it in your css file.', 'neko-vcaddons')

		        )
		    )
		)
	);

	add_shortcode('neko_imagegrid', array( $this, 'neko_shortcodes_imagegrid'));
	