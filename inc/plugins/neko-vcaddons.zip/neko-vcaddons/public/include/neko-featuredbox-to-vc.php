<?php 
vc_map( 
	array(
		'name' => esc_html__( 'Neko Featured Box', 'neko-vcaddons' ),
		'base' => 'neko_featurebox',
		'class' => '',
		'icon' => plugin_dir_url( dirname( __FILE__ )  ) . 'img/icon_featured_box.png',
		'category' => esc_html__( 'Neko shortcodes', 'neko-vcaddons'),
		'js_view' => 'VcIconElementView_Backend',
		'params' => array(

	    /**
			 * FEATURED BOX LAYOUT
			 */	
	    array(
	    	'type' => 'dropdown',
	    	'class' => '',
	    	'heading' => esc_html__( 'Layout', 'neko-vcaddons' ),
	    	'param_name' => 'layout',
	    	'value' => array(
	    		esc_html__( 'Right', 'neko-vcaddons' ) => 'right',
	    		esc_html__( 'Left', 'neko-vcaddons' )  => 'left'
	    		),
	    	'description' => esc_html__( 'Set the position of the icon', 'neko-vcaddons' )
	    	),

	    /**
			 * ICON FAMILY SELECTOR
			 */	
	    	array(
	    		'type' => 'dropdown',
	    		'heading' => esc_html__( 'Icon library', 'neko-vcaddons' ),
	    		'value' => array(
	    			esc_html__( 'Theme icon', 'neko-vcaddons' )   => 'customicons',
	    			esc_html__( 'Font Awesome', 'neko-vcaddons' ) => 'fontawesome',
	    			esc_html__( 'Open Iconic', 'neko-vcaddons' )  => 'openiconic',
	    			esc_html__( 'Typicons', 'neko-vcaddons' )     => 'typicons',
	    			esc_html__( 'Entypo', 'neko-vcaddons' )       => 'entypo',
	    			esc_html__( 'Linecons', 'neko-vcaddons' )     => 'linecons'

	    			),
	    		'admin_label' => true,
	    		'param_name' => 'type',
	    		'description' => '',
	    		),

	    /**
			 * ICON FAMILY FONTAWSOME
			 */	
	    array(
	    	'type' => 'iconpicker',
	    	'heading' => esc_html__( 'Icon', 'neko-vcaddons' ),
	    	'param_name' => 'icon_fontawesome',
	    	'value' => 'fa fa-adjust', 
	    	'settings' => array(
	    		'emptyIcon' => false, 
	    		'iconsPerPage' => 4000, 
	    		),
	    	'dependency' => array(
	    		'element' => 'type',
	    		'value' => 'fontawesome',
	    		),
	    	'description' => esc_html__( 'Select icon from library.', 'neko-vcaddons' ),
	    	),

	    /**
			 * ICON FAMILY ICONIC
			 */	
	    array(
	    	'type' => 'iconpicker',
	    	'heading' => esc_html__( 'Icon', 'neko-vcaddons' ),
	    	'param_name' => 'icon_openiconic',
	    	'value' => 'vc-oi vc-oi-dial', 
	    	'settings' => array(
	    		'emptyIcon' => false, 
	    		'type' => 'openiconic',
	    		'iconsPerPage' => 4000, 
	    		),
	    	'dependency' => array(
	    		'element' => 'type',
	    		'value' => 'openiconic',
	    		),
	    	'description' => esc_html__( 'Select icon from library.', 'neko-vcaddons' ),
	    	),

	    /**
			 * ICON FAMILY TYPICONS
			 */	
	    array(
	    	'type' => 'iconpicker',
	    	'heading' => esc_html__( 'Icon', 'neko-vcaddons' ),
	    	'param_name' => 'icon_typicons',
	    	'value' => 'typcn typcn-adjust-brightness', 
	    	'settings' => array(
	    		'emptyIcon' => false, 
	    		'type' => 'typicons',
	    		'iconsPerPage' => 4000,
	    		),
	    	'dependency' => array(
	    		'element' => 'type',
	    		'value' => 'typicons',
	    		),
	    	'description' => esc_html__( 'Select icon from library.', 'neko-vcaddons' ),
	    	),

	    /**
			 * ICON FAMILY ENTYPO
			 */	
	    array(
	    	'type' => 'iconpicker',
	    	'heading' => esc_html__( 'Icon', 'neko-vcaddons' ),
	    	'param_name' => 'icon_entypo',
	    	'value' => 'entypo-icon entypo-icon-note', 
	    	'settings' => array(
	    		'emptyIcon' => false, 
	    		'type' => 'entypo',
	    		'iconsPerPage' => 4000, 
	    		),
	    	'dependency' => array(
	    		'element' => 'type',
	    		'value' => 'entypo',
	    		),
	    	),

	    /**
			 * ICON FAMILY LINEICON
			 */	
	    array(
	    	'type' => 'iconpicker',
	    	'heading' => esc_html__( 'Icon', 'neko-vcaddons' ),
	    	'param_name' => 'icon_linecons',
	    	'value' => 'vc_li vc_li-heart', 
	    	'settings' => array(
	    		'emptyIcon' => false, 
	    		'type' => 'linecons',
	    		'iconsPerPage' => 4000, 
	    		),
	    	'dependency' => array(
	    		'element' => 'type',
	    		'value' => 'linecons',
	    		),
	    	'description' => esc_html__( 'Select icon from library.', 'neko-vcaddons' ),
	    	),

	    /**
			 * ICON FAMILY THEME ICON
			 */	
	    array(
	    	'type' => 'textfield',
	    	'heading' => esc_html__( 'Icon', 'neko-vcaddons' ),
	    	'param_name' => 'icon_customicons',
	    	'value' => '', 
	    	'dependency' => array(
	    		'element' => 'type',
	    		'value' => 'customicons',
	    		),
	    	'description' => sprintf(wp_kses(__( 'Copy and paste the icon class name in this field to use Theme icons. click <a href="%s" target="_blank">here</a> to select the icon that fits your need', 'neko-vcaddons' ), array( 'a' => array( 'href' => array(), 'title' => array(), 'target' => array() ) )), ''.get_stylesheet_directory_uri().'/font-icons/custom-icons/demo.html'),
	    	),

	    /**
			 * ICON COLOR
			 */	
	    array(
	    	'type' => 'colorpicker',
	    	'heading' => esc_html__( "Icon color", "neko-vcaddons" ),
	    	'param_name' => 'icon_color',
	    	'description' => esc_html__( "Configure the icon color", "neko-vcaddons" )
	    	),

	    /**
			 * ICON SIZE
			 */	
	    array(
	    	'type' => 'dropdown',
	    	'class' => '',
	    	'heading' => esc_html__( 'Icon size', 'neko-vcaddons' ),
	    	'param_name' => 'icon_size',
	    	'value' => array(
	    		esc_html__( 'Small', 'neko-vcaddons' )   => 'small',
	    		esc_html__( 'Medium', 'neko-vcaddons' )   => 'medium',
	    		esc_html__( 'Large', 'neko-vcaddons' )    => 'large',
	    		esc_html__( 'X-large', 'neko-vcaddons' )  => 'x-large',
	    		),
	    	'description' =>  '' 
	    	),


	    /**
			 * ICON SHAPE
			 */	
	    array(
	    	'type' => 'dropdown',
	    	'class' => '',
	    	'heading' => esc_html__( 'Icon shape', 'neko-vcaddons' ),
	    	'param_name' => 'icon_shape',
	    	'value' => array(
	    		esc_html__( 'Default', 'neko-vcaddons' ) => 'default',
	    		esc_html__( 'Circle', 'neko-vcaddons' )  => 'circle',
	    		esc_html__( 'Rounded', 'neko-vcaddons' ) => 'rounded',
	    		esc_html__( 'Squared', 'neko-vcaddons' ) => 'squared'
	    		),
	    	'description' => esc_html__( 'Change the shape of the icon.', 'neko-vcaddons' )
	    	),

	    /**
			 * ICON ANIMATION
			 */
	    array(
	    	'type' => 'checkbox',
	    	'heading' => esc_html__( 'Animated icon on hover', 'neko-vcaddons' ),
	    	'param_name' => 'icon_anim',
	    	'value' => array( esc_html__( 'Animate', 'neko-vcaddons' ) => 'yes' ),
	    	'dependency' => array(
	    		'element' => 'icon_shape',
	    		'value' => array('circle', 'rounded', 'squared'),
	    		),
	    	),	    

	    /**
			 * BACKGROUND COLOR ICON
			 */	
	    array(
	    	'type' => 'colorpicker',
	    	'heading' => esc_html__( 'Icon background color', 'neko-vcaddons' ),
	    	'param_name' => 'icon_bgcolor',
	    	'description' => esc_html__( 'Configure the background color of the icon', 'neko-vcaddons' ),
	    	'dependency' => array(
	    		'element' => 'icon_shape',
	    		'value' => array('circle', 'rounded', 'squared'),
	    		),
	    	),	

			/**
			 *  ICON BORDER
			 */	
			array(
				'type' => 'checkbox',
				'heading' => esc_html__( 'Icon border', 'neko-vcaddons' ),
				'param_name' => 'iconborder',
				'admin_label' => false,
				'dependency' => array(
					'element' => 'icon_shape',
					'value' => array('circle', 'rounded', 'squared'),
					),
				'description' => ''
				),


			/**
			 *  BORDER COLOR
			 */	
			array(
				'type' => 'colorpicker',
				'heading' => esc_html__( "Icon border color", "neko" ),
				'param_name' => 'icon_bordercolor',
				'admin_label' => false,
				'dependency' => array( 'element' => 'iconborder', 'value' => 'true', ),
				'description' => ''
				),


			/**
			 *  BORDER STYLE
			 */	
			array(
				'type' => 'dropdown',
				'heading' => esc_html__( "Icon Border style", "neko" ),
				'param_name' => 'icon_borderstyle',
				'admin_label' => false,
				'value' => array(
					esc_html__( 'Solid', 'neko-vcaddons' )  => 'solid',
					esc_html__( 'Dotted', 'neko-vcaddons' ) => 'dotted',
					esc_html__( 'Dashed', 'neko-vcaddons' ) => 'dashed',
					esc_html__( 'Double', 'neko-vcaddons' ) => 'double',
					esc_html__( 'Groove', 'neko-vcaddons' ) => 'groove',
					esc_html__( 'Ridge', 'neko-vcaddons' )  => 'ridge',
					),

				'dependency' => array( 'element' => 'iconborder', 'value' => 'true', ),
				'description' => ''
				),

	     /**
			 *  BORDER SIZE
			 */	
	     array(
	     	'type' => 'textfield',
	     	'heading' => esc_html__( "Border size for the icon", "neko" ),
	     	'param_name' => 'icon_bordersize',
	     	'admin_label' => false,
	     	'dependency' => array( 'element' => 'iconborder', 'value' => 'true', ),
	     	'description' => ''
	     	),



	    /**
			 * FEATURED BOX CONTENT
			 */
	    array(
	    	'type' => 'textarea_html',
	    	'class' => '',
	    	'heading' => esc_html__( 'Content', 'neko-vcaddons' ),
	    	'param_name' => 'content',
	    	'value' =>  '',
	    	'description' => esc_html__( 'Enter content text here', 'neko-vcaddons' )
	    	),

	    /**
			 * LINK TEXT
			 */
	    array(
	    	'type' => 'textfield',
	    	'class' => '',
	    	'heading' => esc_html__( 'Link text', 'neko-vcaddons' ),
	    	'param_name' => 'link_txt',
	    	'value' =>  '',
	    	'description' => esc_html__( 'This clickable text will appear under the text', 'neko-vcaddons' )
	    	),

	    /**
			 * LINK BUILDER
			 */
	    array(
	    	'type' => 'vc_link',
	    	'heading' => esc_html__( 'Link (url)', 'neko-vcaddons' ),
	    	'class' => '',
	    	'param_name' => 'link',
	    	'description' => esc_html__( 'Add a link to the feature box', 'neko-vcaddons' )
	    	),


			/**
			 * FEATURED BOX ANIMATION
			 */	
			array(
				'type' => 'dropdown',
				'heading' => esc_html__( 'CSS Animation', 'neko-vcaddons' ),
				'param_name' => 'css_animation',
				'admin_label' => false,
				'value' => array(
					esc_html__( 'No', 'neko-vcaddons' ) => '',
					esc_html__( 'Top to bottom', 'neko-vcaddons' ) => 'top-to-bottom',
					esc_html__( 'Bottom to top', 'neko-vcaddons' ) => 'bottom-to-top',
					esc_html__( 'Left to right', 'neko-vcaddons' ) => 'left-to-right',
					esc_html__( 'Right to left', 'neko-vcaddons' ) => 'right-to-left',
					esc_html__( 'Appear from center', 'neko-vcaddons' ) => 'appear'
					),
				'description' => esc_html__( 'Select type of animation for element to be animated when it "enters" the browsers viewport (Note: works only in modern browsers).', 'neko-vcaddons' )
				),

	      /**
	       *  el class
	       */
	      array(
	      	'type' => 'textfield',
	      	'heading' => esc_html__('Extra class name', 'neko-vcaddons'),
	      	'param_name' => 'el_class',
	      	'description' => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'neko-vcaddons')
	      	),

	      /**
	       *  el id
	       */
	      array(
	      	'type' => 'textfield',
	      	'heading' => esc_html__('Extra id name', 'neko-vcaddons'),
	      	'param_name' => 'el_id',
	      	'description' => esc_html__('If you wish to style particular content element differently, then use this field to add an id name and then refer to it in your css file.', 'neko-vcaddons')
	      	),

	      /**
	       *  Design option panel
	       */
	      array(
	      	'type' => 'css_editor',
	      	'heading' => esc_html__( 'Css', 'neko-vcaddons' ),
	      	'param_name' => 'css',
	      	'group' => esc_html__( 'Design options', 'neko-vcaddons' ),
	      	)
	      )
)
);

add_shortcode('neko_featurebox', array( $this, 'neko_shortcodes_featuredbox'));