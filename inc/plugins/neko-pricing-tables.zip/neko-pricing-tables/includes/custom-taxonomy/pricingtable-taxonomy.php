<?php
/**
 * Represents the view for the administration dashboard.
 *
 * This includes the header, options, and other information that should provide
 * The User Interface to the end user.
 *
 * @package   Neko_Pricing_Tables
 * @author    Little Neko <little@little-neko.com>
 * @license   GPL-2.0+
 * @link      http://www.little-neko.com
 * @copyright 2014 Little Neko
 */

add_action( 'init', 'neko_pricing_tables_groups' );


function neko_pricing_tables_groups() 
{
  		// Add new taxonomy, make it hierarchical (like categories)
		$labels          = array(
		'name'           => esc_html__( 'Pricing Tables Groups', 'neko-pricing-tables' ),
		'singular_name'  => esc_html__( 'PricingTableGroups', 'neko-pricing-tables' ),
		'menu_name'      => esc_html__( 'Pricing Tables Groups', 'neko-pricing-tables' ),
		'name_admin_bar' => esc_html__( 'Pricing Table Groups', 'neko-pricing-tables' ),
		'search_items'   => esc_html__( 'Search Pricing Table Groups', 'neko-pricing-tables' ),
		'popular_items'  => esc_html__( 'Popular Pricing Table Groups', 'neko-pricing-tables' ),
		'all_items'      => esc_html__( 'All Pricing Table Groups', 'neko-pricing-tables' ),
		'edit_item'      => esc_html__( 'Edit Pricing Table Group', 'neko-pricing-tables' ),
		'view_item'      => esc_html__( 'View Pricing Table Group', 'neko-pricing-tables' ),
		'update_item'    => esc_html__( 'Update Pricing Table Group', 'neko-pricing-tables' ),
		'add_new_item'   => esc_html__( 'Add New Pricing Table Group', 'neko-pricing-tables' ),
		'new_item_name'  => esc_html__( 'New Pricing Table Group Name', 'neko-pricing-tables' ),
		);    

$args = array(
	'labels'              => $labels,
	'public'              => true,
	'show_ui'             => true,
	'show_admin_column'   => true,
	'show_in_nav_menus'	  => false,
	'show_tagcloud'       => false,
	'query_var'           => false,
	'hierarchical'        => false
	
	);
register_taxonomy( 'neko_pricing_tables_groups', array( 'neko_pricing_table' ), $args );
}




add_action( 'admin_menu', 'neko_pricing_tables_remove_meta_box');  
function neko_pricing_tables_remove_meta_box(){  
	remove_meta_box( 'tagsdiv-neko_pricing_tables_groups', 'neko_pricing_tables', 'side' ); 
}


add_action( 'add_meta_boxes', 'neko_pricing_tables_addmeta_boxes' );


function neko_pricing_tables_addmeta_boxes( ) {

	add_meta_box( 'tagsdiv-neko_pricing_tables_groups', 'Pricing tables', 'neko_pricing_tables_selector', 'neko_pricing_table', 'side' );
}

function neko_pricing_tables_selector ( $post, $meta_box ) {

	$taxonomy = 'neko_pricing_tables_groups';
	$tax      = get_taxonomy( $taxonomy );
	$name = 'tax_input[' . $taxonomy . '][]'; 

	$terms = get_terms($taxonomy,array('hide_empty' => 0)); 

	$postterms = get_the_terms( $post->ID,$taxonomy );  


	$current = array();

	if(!empty($postterms)){
		foreach ($postterms as $checkedKey => $checkedValue) {
			array_push($current, $checkedValue->slug);
		}
	}

	$popular = get_terms( $taxonomy, array( 'orderby' => 'count', 'order' => 'DESC', 'number' => 10, 'hierarchical' => false ) );


	?>

	<div id="taxonomy-<?php echo esc_attr($taxonomy); ?>" class="categorydiv">

		<!-- Display tabs-->  
		<ul id="<?php echo esc_attr($taxonomy); ?>-tabs" class="category-tabs">  
			<li class="tabs">
				<a href="#<?php echo esc_attr($taxonomy); ?>-all" tabindex="3"><?php echo $tax->labels->all_items; ?></a>
			</li>  
			<li class="hide-if-no-js">
				<a href="#<?php echo esc_attr($taxonomy); ?>-pop" tabindex="3"><?php esc_html_e( 'Most Used', 'neko-pricing-tables' ); ?></a>
			</li>  
		</ul>


		<!-- Display taxonomy terms -->  
		<div id="<?php echo esc_attr($taxonomy); ?>-all" class="tabs-panel">  
			<ul id="<?php echo esc_attr($taxonomy); ?>checklist" class="list:<?php echo $taxonomy?> categorychecklist form-no-clear">  
				<?php   foreach($terms as $term){  
					$checked = in_array( $term->slug, $current ) ? ' checked="checked" ' : ''; 
					$id = $taxonomy.'-'.$term->term_id;  
					echo "<li id='$id'><label class='selectit'>";  
					echo "<input type='checkbox' id='in-$id' name='{$name}' ".$checked." value='$term->slug' />&nbsp;$term->name<br />";  
					echo "</label></li>";  
				}?>  
			</ul>  
		</div>  		


		<!-- Display popular taxonomy terms -->  
		<div id="<?php echo esc_attr($taxonomy); ?>-pop" class="tabs-panel" style="display: none;">  
			<ul id="<?php echo esc_attr($taxonomy); ?>checklist-pop" class="categorychecklist form-no-clear" >  
				<?php   foreach($popular as $term){ 
					$checked = in_array( $term->slug, $current ) ? ' checked="checked" ' : '';  
					$id = 'popular-'.$taxonomy.'-'.$term->term_id;  
					echo "<li id='$id'><label class='selectit'>";  
					echo "<input type='checkbox' id='in-$id' ".$checked." value='$term->slug' />&nbsp;$term->name<br />";  
					echo "</label></li>";  
				}?>  
			</ul>  
		</div>  
	</div>
	<?php

}

?>