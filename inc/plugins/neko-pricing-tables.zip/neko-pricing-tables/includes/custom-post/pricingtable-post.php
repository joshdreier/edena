<?php
/**
 * Represents the view for the administration dashboard.
 *
 * This includes the header, options, and other information that should provide
 * The User Interface to the end user.
 *
 * @package   Neko_Pricing_Tables
 * @author    Little Neko <little@little-neko.com>
 * @license   GPL-2.0+
 * @link      http://www.little-neko.com
 * @copyright 2014 Little Neko
 */

add_action( 'init', 'neko_pricing_tables_register_cpt' );

function neko_pricing_tables_register_cpt() {

	$labels = array( 
		'name'               => esc_html__( 'Pricing Tables', 'neko-pricing-tables' ),
		'singular_name'      => esc_html__( 'neko_pricing_table', 'neko-pricing-tables' ),
		'all_items'          => esc_html__( 'Pricing Tables', 'neko-pricing-tables' ),
		'add_new'            => esc_html__( 'Add Pricing Table', 'neko-pricing-tables' ),
		'add_new_item'       => esc_html__( 'Add Pricing Table', 'neko-pricing-tables' ),
		'edit_item'          => esc_html__( 'Edit Pricing Table', 'neko-pricing-tables' ),
		'new_item'           => esc_html__( 'New Pricing Table', 'neko-pricing-tables' ),
		'view_item'          => esc_html__( 'View Pricing Table', 'neko-pricing-tables' ),
		'search_items'       => esc_html__( 'Search Pricing Table', 'neko-pricing-tables' ),
		'not_found'          => esc_html__( 'No Pricing Tables found', 'neko-pricing-tables' ),
		'not_found_in_trash' => esc_html__( 'No Pricing Table found in Trash', 'neko-pricing-tables' ),
		'parent_item_colon'  => esc_html__( 'Parent Pricing Table:', 'neko-pricing-tables' ),
		'menu_name'          => esc_html__( 'Neko Pricing', 'neko-pricing-tables' )
		);

	$args = array( 
		'labels' => $labels,
		'menu_icon' => 'dashicons-awards',
		'hierarchical' => false,  
		'supports' => array( 'title', 'editor' ),
		'public' => false,
		'show_ui' => true,
		'show_in_menu' => true,
		'menu_position' => 29,
		'show_in_nav_menus' => false,
		'publicly_queriable' => false,
		'exclude_from_search' => true,
		'has_archive' => false,
		'query_var' => true,
		'can_export' => true,
		'capability_type' => 'post',
		'rewrite' => array('slug' => 'neko-pricing-tables-item')
		);

	register_post_type( 'neko_pricing_table', $args );
}




?>