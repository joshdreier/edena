(function ( $ ) {
    "use strict";

    /*
    |--------------------------------------------------------------------------
    | OWL CAROUSEL
    |--------------------------------------------------------------------------
    */ 

        jQuery( '.neko-pricing-tablesData' ).each(function( index ) {
               /* var navText = new Array();
                navText[0] = $(this).data('neko-pricing-tables-navigationTextPrev');
                navText[1] = $(this).data('neko-pricing-tables-navigationTextNext');*/

            $(this).owlCarousel(
            {
                items:$(this).data('neko-pricing-tables-items'),
                navigation:$(this).data('neko-pricing-tables-navigation'),
                singleItem:$(this).data('neko-pricing-tables-singleitem'),
                autoPlay:$(this).data('neko-pricing-tables-autoplay'),
                slideSpeed:$(this).data('neko-pricing-tables-slidespeed'),
                itemsScaleUp:$(this).data('neko-pricing-tables-itemsscaleup'),

               
               /* navigationText: navText, */

                pagination:$(this).data('neko-pricing-tables-pagination'),
                paginationNumbers:$(this).data('neko-pricing-tables-paginationnumbers'),
                autoHeight:$(this).data('neko-pricing-tables-autoheight'),
                mouseDrag:$(this).data('neko-pricing-tables-mousedrag'),
                transitionStyle:$(this).data('neko-pricing-tables-transitionstyle'),

                /*addClassActive:true,*/
                
                afterInit: function(){
                    if ($('.owlCaption-over').length) {
                            $('.owlCaption-over').delay( 300 ).slideDown('slow');
                         }
                },
                
               beforeMove: function(){
                     if ($('.owlCaption-over').length) {
                        $('.owlCaption-over').delay( 300 ).fadeOut('slow');
                     }
                 }, 
                afterMove: function(){
                    if ($('.owlCaption-over').length) {
                            $('.owlCaption-over').delay( 300 ).fadeIn('slow');
                         }
                }

            });

        });



}(jQuery));