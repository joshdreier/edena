<?php
/**
 * Represents the view for the administration dashboard.
 *
 * This includes the header, options, and other information that should provide
 * The User Interface to the end user.
 *
 * @package   Neko_Pricing_Tables
 * @author    Little Neko <little@little-neko.com>
 * @license   GPL-2.0+
 * @link      http://www.little-neko.com
 * @copyright 2014 Little Neko
 */
?>
<?php


	/* INIT VARS */
	$post_type = 'neko_pricing_table';
	$neko_pricing_tables_taxonomy = 'neko_pricing_tables_groups';

	$neko_pricing_tables_theme = get_tax_meta($neko_pricing_tables_id,'neko_pricing_table_group_theme');



	$args=array(
			'post_type' => $post_type,
			'tax_query' => array(
				array(
					'taxonomy' => $neko_pricing_tables_taxonomy,
					'terms' => function_exists('icl_object_id')?icl_object_id($neko_pricing_tables_id,$neko_pricing_tables_taxonomy,false):$neko_pricing_tables_id,
					'field' => 'term_id'
					)
			),
			'post_status' => 'publish',
			'orderby' => 'title',
			'order' => 'ASC'
	);

	$loop = new WP_Query( $args );

	/* get total elements */
	$neko_pricing_tables_total = $loop->post_count;


	if ($neko_pricing_tables_total==1){
		$span="";
	} else if ($neko_pricing_tables_total==2){
		$span="neko_pt_one_half";
	} else if ($neko_pricing_tables_total==3){
		$span="neko_pt_one_third";
	} else if ($neko_pricing_tables_total==4){
		$span="neko_pt_one_fourth";
	}else if ($neko_pricing_tables_total==5){
		$span="neko_pt_one_fifth";
	}else if ($neko_pricing_tables_total==6){
		$span="neko_pt_one_sixth";
	}


	
		

		// no grid for style 4
		$neko_grid = ('neko_pt_style_4'==$neko_pricing_tables_theme || 'neko_pt_style_6'==$neko_pricing_tables_theme || 'neko_pt_style_7'==$neko_pricing_tables_theme)?' neko_grid_no_margin':'';

		echo '<div class="nk-pricing-tables-container clearfix'.$neko_grid.' '.$neko_pricing_tables_theme.'">';

		$count = 0;

		while ( $loop->have_posts() ) : $loop->the_post();
		$count++;

		$post = get_post();

		/* echo 'table layout:'.$neko_pricing_tables_layout; */
		
		$customField = get_post_meta($post->ID);

		/* metas */
		$focus_plan       = (!empty($customField['neko_pricing_table_focus_plan'][0]))?$customField['neko_pricing_table_focus_plan'][0]:'';
		$plan_name        = (!empty($customField['neko_pricing_table_plan_name'][0]))?$customField['neko_pricing_table_plan_name'][0]:'';
		$plan_pricing     = (!empty($customField['neko_pricing_table_plan_pricing'][0]))?$customField['neko_pricing_table_plan_pricing'][0]:'';
		$plan_period      = (!empty($customField['neko_pricing_table_plan_period'][0]))?$customField['neko_pricing_table_plan_period'][0]:'';
		$plan_button_text = (!empty($customField['neko_pricing_table_button_text'][0]))?$customField['neko_pricing_table_button_text'][0]:'';
		$plan_button_url  = (!empty($customField['neko_pricing_table_button_url'][0]))?$customField['neko_pricing_table_button_url'][0]:'';


		
		echo '<div class="nk-pricing-table';

		if ($focus_plan==true){
			echo ' nk-focus-plan';
		}
		if ($span!=''){
			echo ' '.$span;
		}

		
		if ($count==$neko_pricing_tables_total){
			echo ' neko_pt_last';
		}

		echo '">';

		echo '<div class="nk-offer"><h2>'.$plan_name.'</h2></div><div class="nk-price">
		<h3>'.$plan_pricing.'<span>'.$plan_period.'</span></h3></div>
		<div class="pricing-table-content">
		'.get_the_content().'
		</div>
		<p class="nk-sign">
		<a class="btn" href="'.esc_url($plan_button_url).'">'.$plan_button_text.'</a>
		</p>
		</div>';

		endwhile;
		echo '</div>';
		


	?>