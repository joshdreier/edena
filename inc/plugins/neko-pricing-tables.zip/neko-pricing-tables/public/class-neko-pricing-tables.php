<?php
/**
 * Represents the view for the administration dashboard.
 *
 * This includes the header, options, and other information that should provide
 * The User Interface to the end user.
 *
 * @package   Neko_Pricing_Tables
 * @author    Little Neko <little@little-neko.com>
 * @license   GPL-2.0+
 * @link      http://www.little-neko.com
 * @copyright 2014 Little Neko
 */

class Neko_Pricing_Tables {

	/**
	 * Plugin version, used for cache-busting of style and script file references.
	 *
	 * @since   1.0.0
	 *
	 * @var     string
	 */
	const VERSION = '1.1.0';

	/**
	 *
	 * The variable name is used as the text domain when internationalizing strings
	 * of text. Its value should match the Text Domain file header in the main
	 * plugin file.
	 *
	 * @since    1.0.0
	 *
	 * @var      string
	 */
	protected $plugin_slug = 'neko-pricing-tables';

	/**
	 * Instance of this class.
	 *
	 * @since    1.0.0
	 *
	 * @var      object
	 */
	protected static $instance = null;

	/**
	 * Initialize the plugin by setting localization and loading public scripts
	 * and styles.
	 *
	 * @since     1.0.0
	 */
	private function __construct() {

		// Load plugin text domain
		add_action( 'init', array( $this, 'load_plugin_textdomain' ), 1 );

		// Activate plugin when new blog is added
		add_action( 'wpmu_new_blog', array( $this, 'activate_new_site' ) );

		// Load public-facing style sheet and JavaScript.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );


		/* 
		 * Custom functionality.
		 */
		
		/**
		 * If visual compser is installed add team to it
		 */
		if ( defined( 'WPB_VC_VERSION' ) ) {
			add_action( 'init', array( $this, 'neko_add_shortcode_to_vc'), 11);
		}else{
			add_shortcode('NEKO_PRICING_TABLES', array( $this, 'neko_pricing_tables_shortcode'));
		}
		

		add_action( 'init', array( $this, 'neko_init'), 2);

	}

	/**
	 * Return the plugin slug.
	 *
	 * @since    1.0.0
	 *
	 *@return    Plugin slug variable.
	 */
	public function get_plugin_slug() {
		return $this->plugin_slug;
	}

	/**
	 * Return an instance of this class.
	 *
	 * @since     1.0.0
	 *
	 * @return    object    A single instance of this class.
	 */
	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	/**
	 * Fired when the plugin is activated.
	 *
	 * @since    1.0.0
	 *
	 * @param    boolean    $network_wide    True if WPMU superadmin uses
	 *                                       "Network Activate" action, false if
	 *                                       WPMU is disabled or plugin is
	 *                                       activated on an individual blog.
	 */
	public static function activate( $network_wide ) {

		if ( function_exists( 'is_multisite' ) && is_multisite() ) {

			if ( $network_wide  ) {

				// Get all blog ids
				$blog_ids = self::get_blog_ids();

				foreach ( $blog_ids as $blog_id ) {

					switch_to_blog( $blog_id );
					self::single_activate();
				}

				restore_current_blog();

			} else {
				self::single_activate();
			}

		} else {
			self::single_activate();
		}

	}

	/**
	 * Fired when the plugin is deactivated.
	 *
	 * @since    1.0.0
	 *
	 * @param    boolean    $network_wide    True if WPMU superadmin uses
	 *                                       "Network Deactivate" action, false if
	 *                                       WPMU is disabled or plugin is
	 *                                       deactivated on an individual blog.
	 */
	public static function deactivate( $network_wide ) {

		if ( function_exists( 'is_multisite' ) && is_multisite() ) {

			if ( $network_wide ) {

				// Get all blog ids
				$blog_ids = self::get_blog_ids();

				foreach ( $blog_ids as $blog_id ) {

					switch_to_blog( $blog_id );
					self::single_deactivate();

				}

				restore_current_blog();

			} else {
				self::single_deactivate();
			}

		} else {
			self::single_deactivate();
		}

	}

	/**
	 * Fired when a new site is activated with a WPMU environment.
	 *
	 * @since    1.0.0
	 *
	 * @param    int    $blog_id    ID of the new blog.
	 */
	public function activate_new_site( $blog_id ) {

		if ( 1 !== did_action( 'wpmu_new_blog' ) ) {
			return;
		}

		switch_to_blog( $blog_id );
		self::single_activate();
		restore_current_blog();

	}

	/**
	 * Get all blog ids of blogs in the current network that are:
	 * - not archived
	 * - not spam
	 * - not deleted
	 *
	 * @since    1.0.0
	 *
	 * @return   array|false    The blog ids, false if no matches.
	 */
	private static function get_blog_ids() {

		global $wpdb;

		// get an array of blog ids
		$sql = "SELECT blog_id FROM $wpdb->blogs
		WHERE archived = '0' AND spam = '0'
		AND deleted = '0'";

		return $wpdb->get_col( $sql );

	}



	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		$domain = $this->plugin_slug;
		$locale = apply_filters( 'plugin_locale', get_locale(), $domain );
		load_plugin_textdomain( $domain, false, dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/' );

	}


	/**
	 * Register and enqueue public-facing style sheet.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		wp_enqueue_style( $this->plugin_slug . '-plugin-styles', plugins_url( 'assets/css/public.css', __FILE__ ), array(), self::VERSION );
	}


	/**
	 * Register and enqueues public-facing JavaScript files.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		wp_enqueue_script( $this->plugin_slug . '-plugin-script', plugins_url( 'assets/js/public.js', __FILE__ ), array( 'jquery' ), self::VERSION, true );
	}


	/**
	 * Shortcode Activation
	 * @since    1.0.0
	 */
	public function neko_pricing_tables_shortcode( $atts, $content = null ) {
		
    	if ( defined( 'WPB_VC_VERSION' ) ) {
	    	$atts = vc_map_get_attributes( 'NEKO_PRICING_TABLES', $atts );
	    	extract($atts);
	    }else{
	    	extract(
	    		shortcode_atts(
	    			array(
	    				'slug' => '',
	    				), $atts
	    			)
	    		);
	    }


		$terms = get_term_by('slug', $slug, 'neko_pricing_tables_groups');
		$neko_pricing_tables_id = $terms->term_id;

		ob_start();

		include(plugin_dir_path( __FILE__ ) . 'views/public.php');

		$content = ob_get_clean();

		return $content;

	}

	public function neko_pricing_tables_custom_template($single) {
		global $wp_query, $post, $neko_pricing_tables_id;
		/* Checks for single template by post type */
		if ($post->post_type == "neko_pricing_table"){
			if(file_exists(plugin_dir_path( __FILE__ ) . 'views/public.php')){
				return plugin_dir_path( __FILE__ ) . 'views/public.php';

			}
	

		}

		return $single;
	}


    /**
	 * Fired for each blog when the plugin is activated.
	 *
	 * @since    1.0.0
	 */

	private static function single_activate() {
			// @TODO: Define activation functionality here
	}

	/**
	 * Fired for each blog when the plugin is deactivated.
	 *
	 * @since    1.0.0
	 */

	private static function single_deactivate() {
		// @TODO: Define deactivation functionality here
	}




	/**
	 * After theme setup hook
	 * Add all actions that needs to be executed within the after theme setup hook
	 * @since    1.0.0
	 */

	public function neko_init(){
		require_once( plugin_dir_path( dirname(__FILE__) ) . 'includes/tools/neko-metabox-generator/engine/my-meta-box-custom-class.php' );
		require_once( plugin_dir_path( dirname(__FILE__) ) . 'includes/tools/neko-metabox-tax-generator/neko-meta-box-class.php' );
		require_once( plugin_dir_path( dirname(__FILE__) ) . 'includes/custom-post/pricingtable-post.php' );
		require_once( plugin_dir_path( dirname(__FILE__) ) . 'includes/custom-taxonomy/pricingtable-taxonomy.php' );
	}


		/**
	 * Get team category
	 */
	public function neko_add_shortcode_to_vc() {

		$output = array(); 
		$terms = get_terms('neko_pricing_tables_groups', array('hide_empty' => 1) );
		//echo '<pre>'; print_r($terms); echo '</pre>';
		$count = count($terms);

		if ( $count > 0 ){
			foreach ( $terms as $term ){
				$output[$term->name] = $term->slug;
			}
		}

		vc_map( 
			array(
				"name" => esc_html__( "Neko pricing table", "neko-pricing-tables" ),
				"base" => "NEKO_PRICING_TABLES",
				"class" => "",
				"category" => esc_html__( "Neko shortcodes", "neko"),
				"icon" => plugins_url( '/assets/image/icon-neko-pricingtable.png', __FILE__ ),
				"params" => array(

				/**
				 * TITLE
				 */		    	
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => esc_html__( "Select your pricing table", "neko-pricing-tables" ),
					"param_name" => "slug",
					"value" => $output,
					"description" => esc_html__( "Select the pricing table group you wan to show here", "neko-pricing-tables" )
					)

				)
				)
			);

		add_shortcode('NEKO_PRICING_TABLES', array( $this, 'neko_pricing_tables_shortcode'));

	}

//END OF CLASS
}

?>
