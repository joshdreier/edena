<?php
/**
 * Represents the view for the administration dashboard.
 *
 * This includes the header, options, and other information that should provide
 * The User Interface to the end user.
 *
 * @package   Neko_Pricing_Tables
 * @author    Little Neko <little@little-neko.com>
 * @license   GPL-2.0+
 * @link      http://www.little-neko.com
 * @copyright 2014 Little Neko
 */

class Neko_Pricing_Tables_Admin {

	/**
	 * Instance of this class.
	 *
	 * @since    1.0.0
	 * @var      object
	 */
	protected static $instance     = null;
	const NP_INCLUDES = 'includes/';

	/**
	 * Slug of the plugin screen.
	 *
	 * @since    1.0.0
	 * @var      string
	 */
	protected $plugin_screen_hook_suffix = null;


	/**
	 * Initialize the plugin by loading admin scripts & styles and adding a
	 * settings page and menu.
	 *
	 * @since     1.0.0
	 */
	private function __construct() {

		/*
		 * - Uncomment following lines if the admin class should only be available for super admins
		 */
		/* if( ! is_super_admin() ) {
			return;
		} */

		/*
		 * Call $plugin_slug from public plugin class.
		 */
		$plugin = Neko_Pricing_Tables::get_instance();
		$this->plugin_slug = $plugin->get_plugin_slug();

		/* Load admin style sheet and JavaScript. */
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_styles' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );

		/* register setting */
		add_action( 'admin_init', array( $this, 'neko_register_setting'));


		/* Add the options page and menu item. */
		//add_action( 'admin_menu', array( $this, 'add_plugin_admin_menu' ) );

		/* Add an action link pointing to the options page. */
		//$plugin_basename = plugin_basename( $this->plugin_slug.'/' . $this->plugin_slug . '.php' );
		//add_filter( 'plugin_action_links_' . $plugin_basename, array( $this, 'add_action_links' ) );


		/*
		 * Define custom functionality.
		 * Read more about actions and filters:
		 * http://codex.wordpress.org/Plugin_API#Hooks.2C_Actions_and_Filters
		 */
		
		add_action( 'init', array( $this, 'neko_init' ), 2 );


		//clean on delete
		add_action('delete_neko_pricing_tables_groups', array( $this, 'neko_delete_tax'));

	}




	/**
	 * Return an instance of this class.
	 *
	 * @since     1.0.0
	 * @return    object    A single instance of this class.
	 */
	public static function get_instance() {

		/*
		 * - Uncomment following lines if the admin class should only be available for super admins
		 */

		/* if( ! is_super_admin() ) {
			return;
		} */

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	/**
	 * Register and enqueue admin-specific style sheet.
	 * @since     1.0.0
	 * @return    null    Return early if no settings page is registered.
	 */
	public function enqueue_admin_styles() {

		if ( ! isset( $this->plugin_screen_hook_suffix ) ) {
			return;
		}

		$screen = get_current_screen();
		if ( $this->plugin_screen_hook_suffix == $screen->id ) {
			wp_enqueue_style( $this->plugin_slug .'-admin-styles', plugins_url( 'assets/css/admin.css', __FILE__ ), array(), Neko_Pricing_Tables::VERSION );
		}

	}

	/**
	 * Register and enqueue admin-specific JavaScript.
	 * @since     1.0.0
	 * @return    null    Return early if no settings page is registered.
	 */
	public function enqueue_admin_scripts() {

		// if ( ! isset( $this->plugin_screen_hook_suffix ) ) {
		// 	return;
		// }

		$screen = get_current_screen();
		if ( $this->plugin_screen_hook_suffix == $screen->id || 'edit-neko_pricing_tables_groups' ===  $screen->id) {
			wp_enqueue_script( $this->plugin_slug . '-admin-script', plugins_url( 'assets/js/admin.js', __FILE__ ), array( 'jquery' ), Neko_Pricing_Tables::VERSION );
		}

	}

	/**
	 * Register the administration menu for this plugin into the WordPress Dashboard menu.
	 *
	 * @since    1.0.0
	 */
	public function add_plugin_admin_menu() {

		/*
		 * Add a settings page for this plugin to the Settings menu.
		 *
		 * NOTE:  Alternative menu locations are available via WordPress administration menu functions.
		 *        Administration Menus: http://codex.wordpress.org/Administration_Menus.
		 */

		//add_options_page
		$this->plugin_screen_hook_suffix = add_submenu_page(
			'edit.php?post_type=neko-pricing-tables',
			esc_html__( 'Neko Pricing Table Setting Page', 'neko-pricing-tables' ),
			esc_html__( 'Settings', 'neko-pricing-tables' ),
			'manage_options',
			$this->plugin_slug,
			array( $this, 'display_plugin_admin_page' )
		);



	}

	public function neko_register_setting() {
		register_setting( 'neko_pricing_tables_group', 'neko_pricing_tables_opt'); 
	}

	/**
	 * Render the settings page for this plugin.
	 *
	 * @since    1.0.0
	 */	

	public function display_plugin_admin_page() {
		include_once( 'views/admin.php' );	
	}

	/**
	 * Add settings action link to the plugins page.
	 *
	 * @since    1.0.0
	 */
	public function add_action_links( $links ) {

		return array_merge(
			array(
				'settings' => '<a href="' . admin_url( 'options-general.php?page=' . $this->plugin_slug ) . '">' . esc_html__( 'Settings', 'neko-pricing-tables' ) . '</a>'
			),
			$links
		);

	}


	/**
	 * After theme setup hook
	 * Add all actions that needs to be executed within the after theme setup hook
	 * @since    1.0.0
	 */

	public function neko_init(){

		require_once( self::NP_INCLUDES . 'metabox-taxonomy/neko-pricing-tables.php');
		require_once( self::NP_INCLUDES . 'metabox-post/neko-pricing-table_item.php');

	}

	/**
	 * After custom taxonomy delete hook
	 * Add all actions that needs to be executed within the after theme setup hook
	 * @since    1.0.0
	 */
	public function neko_delete_tax($tax_id){
		delete_option('tax_meta_'.$tax_id);
	}


//END OF CLASS	
}
