<?php


if (is_admin()){

    /* 
   * prefix of meta keys, optional
   * use underscore (_) at the beginning to make keys hidden, for example $prefix = '_ba_';
   *  you also can make prefix empty to disable it
   * 
   */
    $prefix = 'neko_pricing_table_group_';
    $pluginUri = plugins_url();
  /* 
   * configure your meta box
   */
  $config = array(
    'id'             => 'neko_pricing_tables_meta_box',      				// meta box id, unique per meta box
    'title'          => 'Pricing Table settings',      				// meta box title
    'pages'          => array('neko_pricing_tables_groups'),       // post types, accept custom post types as well, default is array('post'); optional
    'context'        => 'normal',                       		// where the meta box appear: normal (default), advanced, side; optional
    'priority'       => 'high',                         		// order of meta box: high (default), low; optional
    'fields'         => array(),                        		// list of meta fields (can be added by field arrays)
    'local_images'   => false,                          		// Use local or hosted images (meta box images for add/remove)                      		
    'use_with_theme' => $pluginUri . '/neko-portfolio/includes/tools/neko-metabox-tax-generator/engine' //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
    );


  /*
   * Initiate your meta box
   */
  $my_meta =  new Neko_Pricing_Tax_Meta_extends_Class($config);
  
  /*
   * Add fields to your meta box
   */
  

  //layout
  $title_theme = esc_html__('Pricing table theme', 'neko-pricing-tables');
  $desc_theme = esc_html__('This variable allows you choose a layout for this pricing tables group', 'neko-pricing-tables');
  
  $my_meta->addSelect(
    $prefix.'theme',
    array(
      'neko_pt_style_1'=>esc_html__('Default', 'neko-pricing-tables'),
      'neko_pt_style_2'=>esc_html__('Theme 2', 'neko-pricing-tables'),
      'neko_pt_style_3'=>esc_html__('Theme 3', 'neko-pricing-tables'),
      'neko_pt_style_4'=>esc_html__('Theme 4', 'neko-pricing-tables'),
      'neko_pt_style_5'=>esc_html__('Theme 5', 'neko-pricing-tables'),
      'neko_pt_style_6'=>esc_html__('Theme 6', 'neko-pricing-tables'),
      'neko_pt_style_7'=>esc_html__('Theme 7', 'neko-pricing-tables')
      
      ),
    array(
      'name'=> $title_theme,
      'std'=> array('neko_pt_style_1'),
      'desc' => $desc_theme
      )
    );

  // SHORTCODE TEXT

  if(!empty($_GET['tag_ID'])){
    $title_pricing_table_group_shortcode = esc_html__('Pricing table group shortcode', 'neko-pricing-tables');
    $my_meta->addShortcodeTxt('shortcode_field_id',array('taxonomy'=> 'neko_pricing_tables_groups', 'shortcodename' => 'NEKO_PRICING_TABLES', 'class' => 'nekoInfoParag'));
  }  

  //Finish Meta Box Declaration 
  $my_meta->Finish();


}