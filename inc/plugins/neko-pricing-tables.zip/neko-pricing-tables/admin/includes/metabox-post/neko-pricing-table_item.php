<?php

if (is_admin()){

    /* 
   * prefix of meta keys, optional
   * use underscore (_) at the beginning to make keys hidden, for example $prefix = '_ba_';
   *  you also can make prefix empty to disable it
   * 
   */
    $prefix = 'neko_pricing_table_';
    $pluginUri = plugins_url();
  /* 
   * configure your meta box
   */
  $config = array(
    'id'             => 'neko_pricing_table_item_meta_box',      // meta box id, unique per meta box
    'title'          => 'Pricing Table settings',      // meta box title
    'pages'          => array('neko_pricing_table'),        // post types, accept custom post types as well, default is array('post'); optional
    'context'        => 'normal',                       // where the meta box appear: normal (default), advanced, side; optional
    'priority'       => 'high',                         // order of meta box: high (default), low; optional
    'fields'         => array(),                        // list of meta fields (can be added by field arrays)
    'local_images'   => false,                          // Use local or hosted images (meta box images for add/remove)                         
    'use_with_theme' => $pluginUri . '/neko-portfolio/includes/tools/neko-metabox-generator/engine' //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
    );


  /*
   * Initiate your meta box
   */
  $my_meta =  new Neko_Pricing_AT_Meta_Box($config);
  
  /*
   * Add fields to your meta box
   */
  
  //Focus plan
  $title_focus_plan = esc_html__('Focus plan', 'neko-pricing-tables');
  $desc_focus_plan = esc_html__('Add a focus on this item', 'neko-pricing-tables');
  $my_meta->addCheckbox(
    $prefix.'focus_plan',

    array(
      'name'=> $title_focus_plan,
      'std'=> '',
      'desc' => $desc_focus_plan
      )
    );

  //Plan name
  $title_plan_name = esc_html__('Plan name', 'neko-pricing-tables');
  $desc_plan_name = esc_html__('Name of plan, i.e. "Premium"', 'neko-pricing-tables');
  $my_meta->addtext(
    $prefix.'plan_name',
    array(
      'name'=> $title_plan_name,
      'std'=> '',
      'desc' => $desc_plan_name
      )
    );

  //Plan pricing
  $title_plan_pricing = esc_html__('Plan pricing', 'neko-pricing-tables');
  $desc_plan_pricing = esc_html__('i.e. "$25"', 'neko-pricing-tables');
  $my_meta->addtext(
    $prefix.'plan_pricing',
    array(
      'name'=> $title_plan_pricing,
      'std'=> '',
      'desc' => $desc_plan_pricing
      )
    );

  //Plan period
  $title_plan_period = esc_html__('Plan period', 'neko-pricing-tables');
  $desc_plan_period= esc_html__('i.e. "/month"', 'neko-pricing-tables');
  $my_meta->addtext(
    $prefix.'plan_period',
    array(
      'name'=> $title_plan_period,
      'std'=> '',
      'desc' => $desc_plan_period
      )
    );

  //Button text
  $title_button_text = esc_html__('Button text', 'neko-pricing-tables');
  $desc_button_text = esc_html__('i.e. "suscribe"', 'neko-pricing-tables');
  $my_meta->addtext(
    $prefix.'button_text',
    array(
      'name'=> $title_button_text,
      'std'=> '',
      'desc' => $desc_button_text
      )
    );

  //Button url
  $title_button_url = esc_html__('Button url', 'neko_pricing_tables');
  $desc_button_url = esc_html__('i.e. "http://www.little-neko.com"', 'neko_pricing_tables');
  $my_meta->addtext(
    $prefix.'button_url',
    array(
      'name'=> $title_button_url,
      'std'=> '',
      'desc' => $desc_button_url
      )
    );




  //Finish Meta Box Declaration 
  $my_meta->Finish();



  }